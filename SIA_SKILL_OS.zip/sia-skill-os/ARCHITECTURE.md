# SIA SKILL OS — Architecture Notes

## Product layers

1. **Master layer**: immutable skill definitions from `eeje.txt`.
2. **User layer**: progress, sessions, planning, projects, evidence, career and preferences.
3. **Domain layer**: formulas and rule-based reasoning.
4. **Persistence layer**: IndexedDB for data and separate backup snapshots.
5. **Presentation layer**: route pages + reusable UI primitives.

## Key invariants

- A Master Skill ID is stable and never re-numbered.
- Master rows cannot be created from UI actions.
- Personal skills use string IDs with a separate `personalSkills` collection.
- #218 is absent because it is absent from the source; it is not synthesized.
- Session duration is never inferred from a planned item.
- A plan item only affects planning statistics; a session affects actual time.
- Progress percentage is clamped to 0–100.
- Numeric Realistic Hours are required for time-progress calculations; ranges/open-ended values remain non-calculable.
- Mastery does not collapse into hours. Missing evidence yields an unassessed component.

## Focus Engine

`rankFocus()` scores only skills with a user signal: priority, explicit target, planned hours, active project, active goal or due maintenance. It then adds explainable modifiers for deadlines, active projects, remaining hours, maintenance and career value. With no meaningful signal it returns no recommendation rather than a fake recommendation.

## Persistence

The application snapshot uses one IndexedDB key. Backups use a dedicated `backups` object store. Save is debounced after state changes to avoid write amplification while preserving data across refreshes.

## PWA

The service worker uses a cache-first shell for previously visited resources and network fallback when available. All core application data remains local in IndexedDB.

## Accessibility

The UI uses semantic buttons/links, visible keyboard focus, dialog semantics, form labels, RTL layout and keyboard shortcuts. The visual system intentionally avoids dense admin-table presentation on mobile.
