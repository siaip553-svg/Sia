# SIA SKILL OS

SIA SKILL OS is a local-first Personal Skill Operating System for long-horizon skill development. The application separates **Master Data** from the user's live progress and keeps the latter inside IndexedDB.

## Stack

React + TypeScript + Vite, React Router, IndexedDB via `idb`, Lucide icons, PWA service worker. The chart layer is intentionally dependency-light and renders with SVG/CSS so the core app stays fast and offline-capable.

## Verified source snapshot

The bundled Master snapshot preserves **191 source entries** covering **285 numeric IDs**, including 8 bundled/range rows. **#218 is intentionally absent** because it is absent from `eeje.txt`; no placeholder skill is generated for it.

## Run

```bash
npm install
npm run dev
```

Production build:

```bash
npm run build
npm run preview
```

Source audit:

```bash
npm run audit:source
```

Tests / source audit / domain smoke:

```bash
npm test
```

For the exact implementation checks performed in this delivery, see `PROJECT_AUDIT.md`.

## Architecture

- `src/data` — immutable Master Skill snapshot derived from `eeje.txt`.
- `src/domain` — formulas, maintenance logic, Focus Engine, selectors and domain types.
- `src/store` — application state and persistence orchestration.
- `src/lib` — IndexedDB, validation, IDs and formatting.
- `src/pages` — route-level UI modules.
- `src/components` — reusable UI and navigation.
- `public` — PWA manifest, service worker and icons.

## Data model

`AppData` has schema version `1` and splits user state from Master Skill data. The live user layer contains progress, sessions, plans, relations, projects, evidence, portfolio, career profiles, goals, reviews and timer state. Master rows carry source metadata (`sourceFile`, `sourceLines`, `sourceRaw`) so the UI can show what came from the reference file.

`Time Progress` and `Skill Mastery` are independent. Time progress is based on the stored completed/logged-hours value and a numeric Realistic target. Mastery uses configurable evidence-weighted components: practice, projects, tests, self-assessment, performance and consistency. Missing assessment inputs are not filled with synthetic values.

## Source-of-truth policy

The generated snapshot is parsed from `eeje.txt`, not from the previous HTML. Aggregate/range rows are not expanded into individual skills. The source currently contains individually parseable IDs `1..286` except **#218**, which is absent; the app deliberately leaves that gap empty instead of inventing a record.

Some source rows are intentionally non-numeric (for example open-ended/range targets). These remain raw strings and are surfaced as `Undefined / Not Specified`, range text, or `Open-ended` where appropriate instead of being converted into fabricated numeric targets.

## Backup and safety

- JSON Export downloads the full user layer.
- Local backups are stored in a separate IndexedDB object store.
- Import and reset require confirmation.
- Master data is bundled into the application and is not modified by reset/import.
- No telemetry, analytics beacon or required external API exists in the current build.

## Future extension points

The data layer is designed so cloud sync, AI coaching, calendar integrations and external portfolio/dev integrations can be added without replacing the domain model. None of those features are represented as live functionality in the current version.
