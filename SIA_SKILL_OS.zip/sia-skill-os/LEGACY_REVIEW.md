# Legacy HTML review

`SiaSkills_SkillOS_v1.html` was treated as a legacy artifact only.

Useful ideas retained: RTL dark/light visual language, skill cards/table views, source-note display, quick filtering, local export/backup affordances and the compact focus surface.

Structural issues intentionally replaced: one-file architecture, LocalStorage-centric persistence, implicit user state, limited relational model, no explicit schema migration layer, no IndexedDB backup store, no real planner/project/evidence/career domain separation, no global command palette, and the presence of a synthetic `#218` undefined placeholder.

The new application does not use the HTML file as the source of skill truth.
