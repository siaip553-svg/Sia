import fs from 'node:fs'
import path from 'node:path'
import ts from 'typescript'

const root = path.resolve('src')
const files=[]
function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const f=path.join(dir,e.name);if(e.isDirectory())walk(f);else if(/\.(ts|tsx)$/.test(e.name) && !e.name.endsWith('.d.ts'))files.push(f)}}
walk(root)
let bad=0
for(const file of files){
  const code=fs.readFileSync(file,'utf8')
  const result=ts.transpileModule(code,{compilerOptions:{jsx:ts.JsxEmit.ReactJSX,target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext},fileName:file,reportDiagnostics:true})
  const diags=(result.diagnostics||[])
  if(diags.length){bad+=diags.length;console.error(file);for(const d of diags)console.error(ts.flattenDiagnosticMessageText(d.messageText,'\n'))}
}
console.log(`Syntax/transpile check: ${files.length} files, ${bad} diagnostics.`)
process.exitCode=bad?1:0
