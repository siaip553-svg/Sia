import { MASTER_MISSING_IDS, MASTER_SKILL_COUNT, MASTER_SOURCE_COVERAGE_COUNT, MASTER_BUNDLE_COUNT, MASTER_SKILLS } from '../src/data/masterSkills.ts'
import { defaultSkillProgress, type Session } from '../src/domain/types.ts'
import { masteryScore, remainingHours, timeProgress } from '../src/domain/formulas.ts'
import { maintenanceStatus } from '../src/domain/maintenance.ts'
import { sameSkillId } from '../src/domain/skills.ts'

const s1 = MASTER_SKILLS.find(s => s.id === 1)!
const p = defaultSkillProgress()
p.completedHours = 31
p.maintenanceIntervalDays = 30
p.lastPractice = '2026-08-01'
const session: Session = { id:'smoke', skillId:1, date:'2026-09-01', durationMinutes:60, sessionType:'Practice', source:'manual', createdAt:'2026-09-01T00:00:00.000Z' }

const tp = timeProgress(s1,p)
const rem = remainingHours(s1,p)
const mastery = masteryScore({skill:s1,progress:p,sessions:[session],projects:[],evidence:[]})
const maint = maintenanceStatus(s1,p,new Date('2026-09-28T12:00:00Z'))

function assert(ok: boolean, msg: string){ if(!ok) throw new Error(msg) }
assert(MASTER_SKILL_COUNT===191,'Master entry count changed')
assert(MASTER_SOURCE_COVERAGE_COUNT===285,'Source numeric coverage changed')
assert(MASTER_BUNDLE_COUNT===8,'Bundle count changed')
assert(MASTER_MISSING_IDS.length===1 && MASTER_MISSING_IDS[0]===218,'Source gap must be #218')
assert(!MASTER_SKILLS.some(s=>String(s.id)==='218'),'#218 must not be invented')
assert(Math.abs((tp ?? 0) - 50) < 1e-9,'Time progress formula incorrect for skill #1')
assert(Math.abs((rem ?? 0) - 31) < 1e-9,'Remaining hours formula incorrect for skill #1')
assert(mastery.score !== null && mastery.score >= 0 && mastery.score <= 100,'Mastery score must be bounded')
assert(maint.state==='Due','Maintenance status should be due in smoke date')
assert(sameSkillId('1',1),'Numeric/string ID normalization broken')
const bundle = MASTER_SKILLS.find(s=>String(s.id)==='66-73,72')!
assert(bundle && bundle.realHours===null && bundle.realHoursRaw==='~873 (جمع)','Bundle/raw target must remain as source-backed data')
const open = MASTER_SKILLS.find(s=>s.id===219)!
assert(open.realHours===null && open.realHoursRaw==='باز','Open-ended source target must remain unmodified')
console.log(JSON.stringify({ok:true,masterEntries:MASTER_SKILL_COUNT,numericCoverage:MASTER_SOURCE_COVERAGE_COUNT,bundles:MASTER_BUNDLE_COUNT,missing:MASTER_MISSING_IDS,timeProgress:tp,remaining:rem,mastery:mastery.score,maintenance:maint.state}))
