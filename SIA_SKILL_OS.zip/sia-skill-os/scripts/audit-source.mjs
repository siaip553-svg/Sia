import fs from 'node:fs'
import path from 'node:path'

const project = path.resolve(new URL('..', import.meta.url).pathname)
const sourceCandidates = [
  process.env.EEJE_SOURCE,
  path.resolve(project, '..', 'eeje.txt'),
  path.resolve(project, '../..', 'eeje.txt'),
].filter(Boolean)
const sourcePath = sourceCandidates.find((candidate) => fs.existsSync(candidate))
const masterPath = path.resolve(project, 'src/data/masterSkills.ts')
const masterText = fs.readFileSync(masterPath, 'utf8')
const match = masterText.match(/export const MASTER_SKILLS = (\[[\s\S]*?\]) as const/)
if (!match) throw new Error('Could not parse generated master snapshot.')
const master = JSON.parse(match[1])

let expected = []
let verifiedAgainst = 'eeje.txt'
let bundledAudit = null

if (sourcePath) {
  const lines = fs.readFileSync(sourcePath, 'utf8').split(/\r?\n/)
  const seen = new Set()
  let category = 'Unspecified'
  for (const i of [...Array(8956 - 8696 + 1).keys()].map((n) => n + 8696 - 1).concat([...Array(10122 - 10085 + 1).keys()].map((n) => n + 10085 - 1))) {
    const line = lines[i]
    if (line.startsWith('## ')) category = line.slice(3).trim()
    if (!line.startsWith('|') || line.startsWith('| # |') || line.startsWith('|---')) continue
    const cells = line.replace(/^\||\|$/g, '').split('|').map((x) => x.trim())
    if (cells.length < 5 || !/^\d/.test(cells[0])) continue
    const id = cells[0].replace(/\s*[🔧🥊💻✏️🆕]+.*$/u, '').trim()
    const name = cells[1].replace(/\s*[🔧🥊💻✏️🆕]+\s*/gu, ' ').trim()
    const desc = cells[2]
    const isNewCategory = /^258$|^259$|^26[0-9]$|^27[0-9]$|^28[0-6]$/.test(id)
    let initHoursRaw = 'Undefined / Not Specified'
    let initHours = null
    let realHoursRaw = 'Undefined / Not Specified'
    let realHours = null
    let sourceStatus = null
    if (isNewCategory) {
      realHoursRaw = cells[3] || 'Undefined / Not Specified'
      realHours = /^\d+(?:\.\d+)?$/.test(realHoursRaw) ? Number(realHoursRaw) : null
      sourceStatus = cells[4] || null
    } else {
      initHoursRaw = cells[3] || 'Undefined / Not Specified'
      initHours = /^\d+(?:\.\d+)?$/.test(initHoursRaw) ? Number(initHoursRaw) : null
      realHoursRaw = cells[4] || 'Undefined / Not Specified'
      realHours = /^\d+(?:\.\d+)?$/.test(realHoursRaw) ? Number(realHoursRaw) : null
      sourceStatus = cells[5] || null
    }
    if (seen.has(id)) continue
    seen.add(id)
    expected.push({ id: /^\d+$/.test(id) ? Number(id) : id, name, category, desc, initHoursRaw, initHours, realHoursRaw, realHours, sourceStatus, sourceLines: [i + 1], sourceRaw: [line], sourceFile: 'eeje.txt', undefined: realHours === null })
  }
  const proseLineNo = 8845
  if (!seen.has('139-158')) {
    expected.push({
      id: '139-158', name: 'علوم پایه و مهندسی — بسته ۲۰ موردی',
      category: '🔬 دسته ۱۳: علوم پایه و مهندسی (۲۰ مورد) — ⏳ هنوز شروع نشده (هم‌پوشانی طبیعی با دندانپزشکی)',
      desc: lines[proseLineNo - 1].trim(), initHoursRaw: '~۳۴۳۰', initHours: null,
      realHoursRaw: '~۳۵۲۹', realHours: null,
      sourceStatus: '⏳ هنوز شروع نشده (هم‌پوشانی طبیعی با دندانپزشکی)', sourceLines: [proseLineNo], sourceRaw: [lines[proseLineNo - 1]], sourceFile: 'eeje.txt', undefined: true,
    })
  }
} else {
  verifiedAgainst = 'bundled source-audit.json snapshot'
  const auditPath = path.resolve(project, 'source-audit.json')
  if (!fs.existsSync(auditPath)) throw new Error('Neither eeje.txt nor source-audit.json is available for source audit.')
  bundledAudit = JSON.parse(fs.readFileSync(auditPath, 'utf8'))
}

const normalize = (v) => JSON.stringify(v)
const masterById = new Map(master.map((x) => [String(x.id), x]))
const mismatches = []

if (sourcePath) {
  const expectedById = new Map(expected.map((x) => [String(x.id), x]))
  for (const [id, exp] of expectedById) {
    const got = masterById.get(id)
    if (!got) { mismatches.push({ id, kind: 'missing-from-snapshot' }); continue }
    for (const key of ['name', 'category', 'desc', 'initHoursRaw', 'initHours', 'realHoursRaw', 'realHours', 'sourceStatus', 'undefined']) {
      if (normalize(got[key]) !== normalize(exp[key])) {
        mismatches.push({ id, key, expected: exp[key], actual: got[key] })
        break
      }
    }
  }
  for (const [id] of masterById) if (!expectedById.has(id)) mismatches.push({ id, kind: 'extra-in-snapshot' })
}

function expandToken(token) {
  const ids = []
  for (const part of String(token).split(',')) {
    const clean = part.trim()
    if (/^\d+$/.test(clean)) ids.push(Number(clean))
    else {
      const m = clean.match(/^(\d+)\s*-\s*(\d+)$/)
      if (m) for (let n = Number(m[1]); n <= Number(m[2]); n += 1) ids.push(n)
    }
  }
  return ids
}

const expanded = master.flatMap((r) => typeof r.id === 'number' ? [r.id] : expandToken(r.id))
const covered = new Set(expanded)
const missingNumericIds = Array.from({ length: 286 }, (_, i) => i + 1).filter((id) => !covered.has(id))
const duplicateCoveredIds = [...covered].filter((id) => expanded.filter((x) => x === id).length > 1)

const expectedEntries = sourcePath ? expected.length : bundledAudit.sourceFinalEntries
const expectedCoverage = sourcePath ? 285 : bundledAudit.sourceNumericCoverage
const expectedMissing = sourcePath ? [218] : bundledAudit.sourceMissingIds

const report = {
  verifiedAgainst,
  sourceFinalEntries: expectedEntries,
  masterEntries: master.length,
  sourceNumericCoverage: expectedCoverage,
  masterNumericCoverage: covered.size,
  sourceMissingIds: expectedMissing,
  masterMissingIds: missingNumericIds,
  bundleEntries: master.filter((r) => typeof r.id === 'string').map((r) => r.id),
  mismatches: mismatches.slice(0, 50),
  duplicateCoveredIds,
}
console.log(JSON.stringify(report, null, 2))

if (
  master.length !== expectedEntries ||
  mismatches.length ||
  covered.size !== expectedCoverage ||
  JSON.stringify(missingNumericIds) !== JSON.stringify(expectedMissing)
) process.exitCode = 1
