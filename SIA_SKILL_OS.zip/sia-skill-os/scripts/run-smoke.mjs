import fs from 'node:fs'
import path from 'node:path'
import { execFileSync } from 'node:child_process'
import ts from '/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript/lib/typescript.js'

const out=path.resolve('.smoke-runtime')
fs.rmSync(out,{recursive:true,force:true});fs.mkdirSync(out,{recursive:true})
const files=['src/domain/types.ts','src/domain/skills.ts','src/domain/formulas.ts','src/domain/maintenance.ts','src/data/masterSkills.ts','scripts/smoke-domain.ts']
try {
for(const f of files){
  const code=fs.readFileSync(f,'utf8')
  let js=ts.transpileModule(code,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext},fileName:f}).outputText
  js=js.replaceAll("from './skills'", "from './skills.js'").replaceAll("from './types'", "from './types.js'").replaceAll("from '../src/domain/types.ts'", "from './domain/types.js'").replaceAll("from '../src/domain/skills.ts'", "from './domain/skills.js'").replaceAll("from '../src/domain/formulas.ts'", "from './domain/formulas.js'").replaceAll("from '../src/domain/maintenance.ts'", "from './domain/maintenance.js'").replaceAll("from '../src/domain/types.js'", "from './domain/types.js'").replaceAll("from '../src/domain/skills.js'", "from './domain/skills.js'").replaceAll("from '../src/domain/formulas.js'", "from './domain/formulas.js'").replaceAll("from '../src/domain/maintenance.js'", "from './domain/maintenance.js'").replaceAll("from '../src/data/masterSkills.ts'", "from './data/masterSkills.js'")
  const dest=f.startsWith('src/')?path.join(out,f.slice(4).replace(/\.ts$/,'.js')):path.join(out,'smoke-domain.js')
  fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,js)
}
execFileSync(process.execPath,[path.join(out,'smoke-domain.js')],{stdio:'inherit'})

} finally { fs.rmSync(out,{recursive:true,force:true}) }
