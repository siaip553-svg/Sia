import { useEffect, useMemo, useRef, useState } from 'react'
import { Download, HardDrive, RefreshCw, ShieldCheck, Trash2, Upload, Plus, Minus, Eye, EyeOff } from 'lucide-react'
import { Button, Card, SectionHeader, Badge, Modal, EmptyState } from '../components/ui'
import { useApp } from '../store/AppStore'
import { createBackupFileName, getBackup, listBackups, saveBackup, deleteBackup } from '../lib/db'
import { MASTER_MISSING_IDS, MASTER_SKILL_COUNT, MASTER_SOURCE_COVERAGE_COUNT, MASTER_BUNDLE_COUNT } from '../data/masterSkills'
import { validateImport } from '../lib/validation'
import { uid } from '../lib/id'
import type { AppData, BackupSnapshot, MasteryWeights } from '../domain/types'
import { nowISO } from '../domain/types'

const accentOptions = [
  {id:'teal',label:'Teal'},
  {id:'blue',label:'Blue'},
  {id:'purple',label:'Purple'},
  {id:'amber',label:'Amber'},
] as const

export default function SettingsPage(){
  const {data,setPreferences,patch,resetAll}=useApp()
  const fileRef=useRef<HTMLInputElement>(null)
  const [backups,setBackups]=useState<BackupSnapshot[]>([])
  const [confirm,setConfirm]=useState<'reset'|'import'|null>(null)
  const [pendingImport,setPendingImport]=useState<AppData|null>(null)
  const [backupLabel,setBackupLabel]=useState('Manual backup')
  const [stagedLifeStages,setStagedLifeStages]=useState(data.preferences.lifeStages)
  const [notice,setNotice]=useState('')
  const [busy,setBusy]=useState(false)

  const refreshBackups=()=>listBackups().then(xs=>setBackups([...xs].sort((a,b)=>b.createdAt.localeCompare(a.createdAt)))).catch(()=>setBackups([]))
  useEffect(()=>{refreshBackups()},[])
  useEffect(()=>setStagedLifeStages(data.preferences.lifeStages),[data.preferences.lifeStages.join('|')])

  const widgetLabels:Record<string,string>={focus:'Focus Now',stats:'Core Stats',today:'Today',weekly:'Weekly Load',maintenance:'Maintenance',distribution:'Skill Distribution'}
  const widgets=data.preferences.dashboardWidgets

  function exportJson(label='SIA SKILL OS export'){
    const payload={...data, exportedAt:nowISO(), exportLabel:label}
    const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'})
    const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=createBackupFileName(label); a.click(); URL.revokeObjectURL(a.href)
    setNotice('JSON export created.')
  }

  async function createBackup(){
    setBusy(true)
    try{
      await saveBackup({id:uid('backup'),createdAt:nowISO(),label:backupLabel.trim()||'Manual backup',appVersion:data.meta.appVersion,schemaVersion:data.meta.schemaVersion,data:structuredClone(data)})
      await refreshBackups(); setNotice('Backup saved locally in IndexedDB.')
    }finally{setBusy(false)}
  }

  async function handleImport(file:File){
    const text=await file.text()
    let parsed:any
    try{parsed=JSON.parse(text)}catch{setNotice('Import failed: invalid JSON.');return}
    const result=validateImport(parsed)
    if(!result.valid){setNotice(`Import rejected: ${result.errors.slice(0,2).join(' ')}`);return}
    setPendingImport(result.data);setConfirm('import')
  }

  function applyImport(){
    if(!pendingImport)return
    patch(()=>structuredClone(pendingImport))
    setPendingImport(null);setConfirm(null);setNotice('Data imported and queued for local persistence.')
  }

  async function restoreBackup(id:string){
    const b=await getBackup(id)
    if(!b)return
    const v=validateImport(b.data)
    if(!v.valid){setNotice('Backup rejected because its payload is invalid.');return}
    patch(()=>structuredClone(v.data)); setNotice(`Restored: ${b.label}`)
  }

  const missing218=useMemo(()=>MASTER_MISSING_IDS.includes(218),[])

  return <div className="content">
    <div className="page-head"><div><h1>Settings</h1><p>Preferences, data safety, dashboard composition and source-integrity controls.</p></div><div className="head-actions"><Badge tone="teal">schema v{data.meta.schemaVersion}</Badge><Badge>offline-first</Badge></div></div>

    <div className="grid grid-2">
      <Card><SectionHeader title="Appearance"/><div className="field-grid">
        <div className="field"><label>Theme</label><select className="select" value={data.preferences.theme} onChange={e=>setPreferences({theme:e.target.value as any})}><option value="dark">Dark</option><option value="light">Light</option></select></div>
        <div className="field"><label>Accent</label><select className="select" value={data.preferences.accent} onChange={e=>setPreferences({accent:e.target.value as any})}>{accentOptions.map(x=><option key={x.id} value={x.id}>{x.label}</option>)}</select></div>
        <div className="field"><label>Week starts</label><select className="select" value={String(data.preferences.weekStart)} onChange={e=>setPreferences({weekStart:Number(e.target.value) as any})}><option value="6">Saturday</option><option value="0">Sunday</option><option value="1">Monday</option></select></div>
        <div className="field"><label>Daily learning goal (hours)</label><input className="input" type="number" min="0" step="0.25" value={data.preferences.dailyGoalHours} onChange={e=>setPreferences({dailyGoalHours:Math.max(0,Number(e.target.value)||0)})}/></div>
        <div className="field"><label>Default session duration (minutes)</label><input className="input" type="number" min="5" step="5" value={data.preferences.defaultSessionMinutes} onChange={e=>setPreferences({defaultSessionMinutes:Math.max(5,Number(e.target.value)||60)})}/></div>
        <div className="field"><label>Skills default view</label><select className="select" value={data.preferences.skillsView} onChange={e=>setPreferences({skillsView:e.target.value as any})}><option value="cards">Cards</option><option value="table">Table</option></select></div>
      </div></Card>

      <Card><SectionHeader title="Mastery model" hint="Weights are user-configurable and normalized to a 100% total. Missing inputs are still excluded from the score."/><div className="field-grid">{Object.entries(data.preferences.masteryWeights).map(([key,value])=><div className="field" key={key}><label>{key} weight</label><input className="input" type="number" min="0" max="100" step="1" value={Math.round(value*100)} onChange={e=>{const n=Math.max(0,Math.min(100,Number(e.target.value)||0))/100;{const k=key as keyof MasteryWeights;setPreferences({masteryWeights:{...data.preferences.masteryWeights,[k]:n}})}}}/></div>)}</div><p className="small-muted" style={{marginTop:8}}>Current total: {Math.round(Object.values(data.preferences.masteryWeights).reduce((a,b)=>a+b,0)*100)}%. If the total differs from 100%, the engine normalizes it during scoring.</p></Card>

      <Card><SectionHeader title="Behavior"/><div className="settings-list">
        <label className="toggle-row"><span><strong>In-app notifications</strong><small>Maintenance due, deadlines, inactivity signals.</small></span><input type="checkbox" checked={data.preferences.notifications} onChange={e=>setPreferences({notifications:e.target.checked})}/></label>
        <label className="toggle-row"><span><strong>Keyboard shortcuts</strong><small>/ search · F focus · N session · P planner · S skills · G goals.</small></span><input type="checkbox" checked={data.preferences.shortcutsEnabled} onChange={e=>setPreferences({shortcutsEnabled:e.target.checked})}/></label>
      </div><div className="alert" style={{marginTop:12}}><ShieldCheck size={16}/><span>No telemetry or network sync is required by the current architecture. Your progress lives locally.</span></div></Card>
    </div>

    <Card style={{marginTop:14}}><SectionHeader title="Dashboard widgets" hint="Hide or reorder what appears on Command Center."/><div className="widget-settings">{['focus','stats','today','weekly','maintenance','distribution'].map(id=><div className="widget-setting" key={id}><div><strong>{widgetLabels[id]}</strong><div className="small-muted">{widgets.indexOf(id)+1} · {widgets.includes(id)?'Visible':'Hidden'}</div></div><div className="head-actions"><Button size="sm" onClick={()=>setPreferences({dashboardWidgets:widgets.includes(id)?widgets.filter(x=>x!==id):[...widgets,id]})}>{widgets.includes(id)?<EyeOff size={13}/>:<Eye size={13}/>} {widgets.includes(id)?'Hide':'Show'}</Button><Button size="sm" disabled={!widgets.includes(id)||widgets.indexOf(id)===0} onClick={()=>{const xs=[...widgets];const i=xs.indexOf(id);[xs[i-1],xs[i]]=[xs[i],xs[i-1]];setPreferences({dashboardWidgets:xs})}}>↑</Button><Button size="sm" disabled={!widgets.includes(id)||widgets.indexOf(id)===widgets.length-1} onClick={()=>{const xs=[...widgets];const i=xs.indexOf(id);[xs[i],xs[i+1]]=[xs[i+1],xs[i]];setPreferences({dashboardWidgets:xs})}}>↓</Button></div></div>)}</div></Card>

    <Card style={{marginTop:14}}><SectionHeader title="Life stage taxonomy" hint="Used only by the user layer; changing it does not modify Master Data."/><div className="life-stage-editor">{stagedLifeStages.map((stage,i)=><div className="control-row" key={`${stage}-${i}`}><input className="input" value={stage} onChange={e=>setStagedLifeStages(xs=>xs.map((x,j)=>j===i?e.target.value:x))}/><Button size="sm" variant="danger" disabled={stagedLifeStages.length<=1} onClick={()=>setStagedLifeStages(xs=>xs.filter((_,j)=>j!==i))}><Minus size={13}/></Button></div>)}<div className="head-actions"><Button size="sm" onClick={()=>setStagedLifeStages(xs=>[...xs,'New Stage'])}><Plus size={13}/> Add stage</Button><Button size="sm" variant="primary" onClick={()=>setPreferences({lifeStages:stagedLifeStages.filter(Boolean)})}>Save taxonomy</Button></div></div></Card>

    <div className="grid grid-2" style={{marginTop:14}}>
      <Card><SectionHeader title="Export / import"/><p className="small-muted">Export includes Master-independent user data: sessions, plans, goals, projects, evidence, mastery inputs, career, portfolio, reviews, relations, preferences and timer state.</p><div className="head-actions" style={{justifyContent:'flex-start',marginTop:10}}><Button variant="primary" onClick={()=>exportJson()}><Download size={15}/> Export JSON</Button><Button onClick={()=>fileRef.current?.click()}><Upload size={15}/> Import JSON</Button><input ref={fileRef} type="file" accept="application/json,.json" hidden onChange={e=>{const f=e.target.files?.[0];if(f)handleImport(f);e.currentTarget.value=''}}/></div><div className="alert warning-alert" style={{marginTop:12}}><strong>Safety:</strong> import replaces the current user dataset only after confirmation.</div></Card>
      <Card><SectionHeader title="Local backups" hint="Stored in IndexedDB, separate from the live app snapshot."/><div className="control-row"><input className="input" value={backupLabel} onChange={e=>setBackupLabel(e.target.value)} placeholder="Backup label"/><Button variant="primary" disabled={busy} onClick={createBackup}><HardDrive size={15}/> Create backup</Button></div><div className="list" style={{marginTop:12}}>{backups.length?backups.map(b=><div className="list-row" key={b.id}><div><div className="row-title">{b.label}</div><div className="row-meta"><Badge>{new Date(b.createdAt).toLocaleString('fa-IR')}</Badge><Badge>v{b.appVersion}</Badge></div></div><div className="head-actions"><Button size="sm" onClick={()=>restoreBackup(b.id)}>Restore</Button><Button size="sm" variant="danger" onClick={async()=>{await deleteBackup(b.id);refreshBackups()}}><Trash2 size={13}/></Button></div></div>):<EmptyState title="No local backups yet." description="Create one before large imports, resets or manual cleanup."/>}</div></Card>
    </div>

    <Card style={{marginTop:14}}><SectionHeader title="Master Data integrity"/><div className="grid grid-2"><div><div className="small-muted">Source-defined master records</div><div className="stat-value">{MASTER_SOURCE_COVERAGE_COUNT}</div><p className="small-muted">{MASTER_SKILL_COUNT} source entries cover {MASTER_SOURCE_COVERAGE_COUNT} numeric IDs; {MASTER_BUNDLE_COUNT} entries remain bundled exactly as written. The source gap is #{MASTER_MISSING_IDS.join(', #')} and is not invented.</p></div><div><div className="small-muted">User Progress for #218</div><div className="stat-value">{missing218?'Undefined':'Configured'}</div><p className="small-muted">Master Data and User Progress remain separate.</p></div></div></Card>

    <Card style={{marginTop:14}}><SectionHeader title="Danger zone"/><div className="alert danger-alert"><strong>Reset all user data.</strong> Master Data is bundled with the app and is not edited by reset. All sessions, projects, plans, goals, career data and progress will be removed.</div><Button variant="danger" style={{marginTop:12}} onClick={()=>setConfirm('reset')}><RefreshCw size={15}/> Reset user dataset</Button></Card>

    {confirm==='import'&&<Modal title="Replace current data?" onClose={()=>setConfirm(null)} footer={<><Button onClick={()=>setConfirm(null)}>Cancel</Button><Button variant="danger" onClick={applyImport}>Replace</Button></>}><p className="small-muted">This will replace the entire current user layer. A local backup is recommended first.</p></Modal>}
    {confirm==='reset'&&<Modal title="Reset user dataset?" onClose={()=>setConfirm(null)} footer={<><Button onClick={()=>setConfirm(null)}>Cancel</Button><Button variant="danger" onClick={async()=>{await resetAll();setConfirm(null);setNotice('User dataset reset.')}}>Reset everything</Button></>}><p className="small-muted">This action removes all local progress data. The Master Skill Checklist remains part of the application.</p></Modal>}
    {notice&&<div className="toast-inline" role="status" onClick={()=>setNotice('')}>{notice}</div>}
  </div>
}
