import { Link, useSearchParams } from 'react-router-dom'
import type { ReactNode } from 'react'
import { Search, FolderKanban, FileText, Target, BriefcaseBusiness } from 'lucide-react'
import { MASTER_SKILLS } from '../data/masterSkills'
import { useApp } from '../store/AppStore'
import { Card, SectionHeader, EmptyState, Badge } from '../components/ui'

export default function SearchPage(){
  const [params]=useSearchParams(); const q=(params.get('q')||'').trim().toLowerCase(); const {data}=useApp()
  const nameOfSkill=(skillId:string|number)=>MASTER_SKILLS.find(s=>String(s.id)===String(skillId))?.name ?? data.personalSkills.find(s=>s.id===String(skillId))?.name ?? 'Unknown skill'
  const master=MASTER_SKILLS.filter(s=>!q || [String(s.id),s.name,s.category,s.desc||'',...(s.sourceRaw||[])].some(v=>v.toLowerCase().includes(q))).slice(0,30)
  const personal=data.personalSkills.filter(s=>!q || [s.id,s.name,s.category||'',s.description||'',...s.tags].some(v=>v.toLowerCase().includes(q))).slice(0,30)
  const projects=data.projects.filter(p=>!q || [p.id,p.title,p.description,p.notes,...p.deliverables].some(v=>v.toLowerCase().includes(q))).slice(0,20)
  const notes=data.sessions.filter(s=>!q || [s.note||'',s.reflection?.learned||'',s.reflection?.difficult||'',s.reflection?.improved||'',s.reflection?.next||'',nameOfSkill(s.skillId)].some(v=>v.toLowerCase().includes(q))).slice(0,20)
  const goals=data.goals.filter(g=>!q || [g.title,g.notes,nameOfSkill(g.skillId||'')].some(v=>v.toLowerCase().includes(q))).slice(0,20)
  const portfolio=data.portfolio.filter(p=>!q || [p.title,p.description,p.result,...p.skillIds.map(nameOfSkill)].some(v=>v.toLowerCase().includes(q))).slice(0,20)
  const total=master.length+personal.length+projects.length+notes.length+goals.length+portfolio.length
  return <div className="content"><div className="page-head"><div><h1>Search</h1><p>Fast local search across Master Data and your user layer. {q?`Query: “${params.get('q')}”`:'Type into the global search to begin.'}</p></div><div className="stat"><div className="stat-top">Matches</div><div className="stat-value">{q?total:'—'}</div></div></div>
  {!q?<Card><EmptyState icon={<Search size={22}/>} title="Search is ready." description="Search skills, IDs, categories, project notes, session reflections, goals and portfolio items."/></Card>:<div className="grid grid-2">
    <SearchSection title="Master Skills" count={master.length}>{master.map(s=><Link key={s.id} className="search-result" to={`/skills?skill=${s.id}`}><span className="mono">#{s.id}</span><span><strong>{s.name}</strong><small>{s.category} · {targetLabel(s.realHoursRaw,s.realHours)}</small></span></Link>)}</SearchSection>
    <SearchSection title="Personal Skills" count={personal.length}>{personal.map(s=><div className="search-result" key={s.id}><span className="mono">PS</span><span><strong>{s.name}</strong><small>{s.category||'Personal'}</small></span></div>)}</SearchSection>
    <SearchSection title="Projects" count={projects.length}>{projects.map(p=><Link className="search-result" to="/projects" key={p.id}><span className="mono">PRJ</span><span><strong>{p.title}</strong><small>{p.status} · {p.skillIds.length} linked skills</small></span></Link>)}</SearchSection>
    <SearchSection title="Session notes & reflections" count={notes.length}>{notes.map(s=><Link className="search-result" to={`/skills?skill=${s.skillId}`} key={s.id}><span className="mono">{s.durationMinutes}m</span><span><strong>{nameOfSkill(s.skillId)}</strong><small>{s.note||s.reflection?.learned||s.reflection?.next||'Session'}</small></span></Link>)}</SearchSection>
    <SearchSection title="Goals" count={goals.length}>{goals.map(g=><Link className="search-result" to="/planner?tab=goals" key={g.id}><span className="mono">GOAL</span><span><strong>{g.title}</strong><small>{g.level} · {g.status}</small></span></Link>)}</SearchSection>
    <SearchSection title="Portfolio" count={portfolio.length}>{portfolio.map(p=><Link className="search-result" to="/career" key={p.id}><span className="mono">PORT</span><span><strong>{p.title}</strong><small>{p.clientType} · {p.result||'No result recorded'}</small></span></Link>)}</SearchSection>
  </div>}</div>
}

function targetLabel(raw:string|null|undefined, hours:number|null|undefined){if(raw?.includes('باز'))return 'Open-ended';if(raw?.startsWith('Undefined'))return 'Undefined / Not Specified';return hours===null?(raw||'Undefined / Not Specified'):`${hours}h realistic target`}

function SearchSection({title,count,children}:{title:string;count:number;children:ReactNode}){return <Card><SectionHeader title={title} action={<Badge>{count}</Badge>}/>{count?<div className="search-results">{children}</div>:<div className="small-muted">No matches in this collection.</div>}</Card>}
