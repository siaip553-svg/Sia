import { useMemo, useState } from 'react'
import { CalendarCheck2, ChevronLeft, ChevronRight, Flag, Play, Plus, Trash2 } from 'lucide-react'
import { useSearchParams, useNavigate } from 'react-router-dom'
import { SkillSelect } from '../components/SkillSelect'
import { Button, Card, EmptyState, Modal, SectionHeader, Badge } from '../components/ui'
import { useApp } from '../store/AppStore'
import { isoToday, minutesToText, dateFa, faNumber } from '../lib/format'
import type { GoalLevel, SkillId } from '../domain/types'
import { MASTER_SKILLS } from '../data/masterSkills'

function skillName(id: SkillId) { return MASTER_SKILLS.find(s => String(s.id) === String(id))?.name || `Personal ${id}` }
function asSkillId(value: string): SkillId { return /^\d+$/.test(value) ? Number(value) : value }
function addDays(iso: string, n: number) { const d = new Date(iso); d.setDate(d.getDate() + n); return d.toISOString().slice(0,10) }
function rangeStart(date: string, view: 'Day'|'Week'|'Month') {
  const d = new Date(date)
  if (view === 'Day') return date
  if (view === 'Month') return new Date(d.getFullYear(), d.getMonth(), 1).toISOString().slice(0,10)
  const dow = d.getDay(); d.setDate(d.getDate() - ((dow - 6 + 7) % 7)); return d.toISOString().slice(0,10)
}

export default function PlannerPage() {
  const { data, addPlanItem, updatePlanItem, deletePlanItem, addGoal, updateGoal } = useApp()
  const [params, setParams] = useSearchParams()
  const [view, setView] = useState<'Day'|'Week'|'Month'>((params.get('view') as 'Day'|'Week'|'Month') || 'Week')
  const [anchor, setAnchor] = useState(params.get('date') || isoToday())
  const [tab, setTab] = useState<'plan'|'goals'>((params.get('tab') as 'plan'|'goals') || 'plan')
  const [showPlan, setShowPlan] = useState(params.get('action') === 'session')
  const [showGoal, setShowGoal] = useState(false)
  const navigate = useNavigate()

  const start = rangeStart(anchor, view)
  const dayCount = view === 'Day' ? 1 : view === 'Week' ? 7 : new Date(new Date(start).getFullYear(), new Date(start).getMonth() + 1, 0).getDate()
  const dayKeys = useMemo(() => Array.from({ length: dayCount }, (_, i) => addDays(start, i)), [dayCount, start])
  const visiblePlan = useMemo(() => data.planItems.filter(p => dayKeys.includes(p.date)).slice().sort((a,b) => a.date.localeCompare(b.date)), [data.planItems, dayKeys])
  const goals = useMemo(() => data.goals.filter(g => g.status !== 'Archived').slice().sort((a,b) => a.dueDate.localeCompare(b.dueDate)), [data.goals])
  const plannedMinutes = visiblePlan.reduce((s,p) => s + p.durationMinutes, 0)
  const actualMinutes = data.sessions.filter(s => dayKeys.includes(s.date)).reduce((s,x) => s + x.durationMinutes, 0)

  const nav = (delta: number) => { const d = new Date(anchor); d.setDate(d.getDate() + delta * (view === 'Month' ? 30 : view === 'Week' ? 7 : 1)); const next = d.toISOString().slice(0,10); setAnchor(next); setParams(p => { p.set('date', next); return p }, { replace: true }) }

  return <div className="content">
    <div className="page-head"><div><h1>Planner</h1><p>Plans are intentions; Sessions are reality. The two are intentionally separate.</p></div><div className="head-actions"><Button variant="primary" onClick={() => setShowPlan(true)}><Plus size={15}/> Plan session</Button><Button onClick={() => setShowGoal(true)}><Flag size={15}/> New goal</Button></div></div>
    <Card><div className="skills-top"><div className="filter-chips">{(['plan','goals'] as const).map(x => <button key={x} className={`chip ${tab === x ? 'active' : ''}`} onClick={() => { setTab(x); setParams(p => { p.set('tab',x); return p }, {replace:true}) }}>{x === 'plan' ? 'Planning' : 'Goals'}</button>)}</div>{tab === 'plan' && <div className="filter-chips">{(['Day','Week','Month'] as const).map(x => <button key={x} className={`chip ${view === x ? 'active' : ''}`} onClick={() => { setView(x); setParams(p => { p.set('view',x); return p }, {replace:true}) }}>{x}</button>)}</div>}</div></Card>

    {tab === 'plan' ? <>
      <Card><SectionHeader title={`${view} view`} hint={`${dateFa(start)} · ${faNumber(plannedMinutes / 60, 1)}h planned`} action={<div className="control-row"><Button size="sm" onClick={() => nav(-1)}><ChevronRight size={14}/></Button><Button size="sm" onClick={() => { setAnchor(isoToday()); setParams(p => { p.set('date',isoToday()); return p }, {replace:true}) }}>Today</Button><Button size="sm" onClick={() => nav(1)}><ChevronLeft size={14}/></Button></div>}/>
        {visiblePlan.length ? <div className="timeline">{dayKeys.map(day => { const items = visiblePlan.filter(p => p.date === day); return <div key={day} className="timeline-day"><div className="time">{dateFa(day)}</div><div className="task">{items.length ? <div className="list">{items.map(p => <div className={`task-card ${p.status === 'Done' ? 'done' : ''}`} key={p.id}><div><div className="task-title">{p.title}</div><div className="task-meta">{skillName(p.skillId)} · {minutesToText(p.durationMinutes)} · {p.status}</div></div><div className="row-actions"><Button size="sm" onClick={() => navigate(`/focus?skill=${encodeURIComponent(String(p.skillId))}`)}><Play size={12}/> Focus</Button>{p.status !== 'Done' && <Button size="sm" onClick={() => updatePlanItem(p.id,{status:'Done'})}>Done</Button>}<Button size="sm" variant="danger" onClick={() => { if(window.confirm('Delete this plan item?')) deletePlanItem(p.id) }}><Trash2 size={12}/></Button></div></div>)}</div> : <span className="small-muted">No plan</span>}</div></div> })}</div> : <EmptyState title="Nothing planned in this view." description="Plan a concrete session linked to a real Skill, then let the Focus mode turn that intention into a logged Session." action={<Button size="sm" variant="primary" onClick={() => setShowPlan(true)}><CalendarCheck2 size={14}/> Plan first session</Button>}/>} 
      </Card>
      <Card><SectionHeader title="Actual vs planned" hint="Only logged sessions count toward actual."/><div className="grid grid-3"><div className="stat"><div className="stat-top">Planned in view</div><div className="stat-value">{minutesToText(plannedMinutes)}</div></div><div className="stat"><div className="stat-top">Actual in view</div><div className="stat-value">{minutesToText(actualMinutes)}</div></div><div className="stat"><div className="stat-top">Plan items</div><div className="stat-value">{faNumber(visiblePlan.length)}</div></div></div></Card>
    </> : <Card><SectionHeader title="Goals" hint="Long-term → Year → Month → Week → Session"/>{goals.length ? <div className="list">{goals.map(g => <div className="list-row" key={g.id}><div><div className="row-title">{g.title}</div><div className="row-meta"><Badge tone="teal">{g.level}</Badge>{g.skillId !== undefined && <Badge>{skillName(g.skillId)}</Badge>}<Badge>{dateFa(g.dueDate)}</Badge>{g.targetHours !== undefined && <Badge>{g.targetHours}h</Badge>}</div></div><div className="row-actions">{g.status === 'Active' && <Button size="sm" onClick={() => updateGoal(g.id,{status:'Completed'})}>Complete</Button>}{g.status === 'Completed' && <Badge tone="green">Completed</Badge>}</div></div>)}</div> : <EmptyState title="No goals yet." description="Create a Week Goal first; keep it small enough to execute, then roll it upward into Month and Year goals." action={<Button size="sm" variant="primary" onClick={() => setShowGoal(true)}>Create goal</Button>}/>}</Card>}

    {showPlan && <PlanModal onClose={() => setShowPlan(false)} onCreate={addPlanItem} projects={data.projects} personalSkills={data.personalSkills} defaultDate={anchor}/>} 
    {showGoal && <GoalModal onClose={() => setShowGoal(false)} onCreate={addGoal} projects={data.projects} personalSkills={data.personalSkills}/>} 
  </div>
}

function PlanModal({onClose,onCreate,projects,personalSkills,defaultDate}:{onClose:()=>void;onCreate:(x:any)=>string;projects:any[];personalSkills:any[];defaultDate:string}){
  const [f,setF]=useState({title:'',skillId:'',projectId:'',date:defaultDate,duration:'60',note:''})
  return <Modal title="Plan a session" onClose={onClose} footer={<><Button onClick={onClose}>Cancel</Button><Button variant="primary" disabled={!f.title.trim()||!f.skillId} onClick={() => { onCreate({title:f.title.trim(),skillId:asSkillId(f.skillId),projectId:f.projectId||undefined,date:f.date,durationMinutes:Math.max(1,Number(f.duration)||1),status:'Planned',note:f.note||undefined}); onClose() }}>Add to planner</Button></>}>
    <div className="field-grid"><div className="field full"><label>Task</label><input className="input" autoFocus value={f.title} onChange={e=>setF({...f,title:e.target.value})} placeholder="e.g. Practice color correction"/></div><div className="field"><label>Skill</label><SkillSelect value={f.skillId} onChange={v=>setF({...f,skillId:String(v)})} personalSkills={personalSkills}/></div><div className="field"><label>Project</label><select className="select" value={f.projectId} onChange={e=>setF({...f,projectId:e.target.value})}><option value="">No project</option>{projects.map(p=><option key={p.id} value={p.id}>{p.title}</option>)}</select></div><div className="field"><label>Date</label><input className="input" type="date" value={f.date} onChange={e=>setF({...f,date:e.target.value})}/></div><div className="field"><label>Duration (minutes)</label><input className="input" type="number" min="1" value={f.duration} onChange={e=>setF({...f,duration:e.target.value})}/></div><div className="field full"><label>Note</label><textarea className="textarea" value={f.note} onChange={e=>setF({...f,note:e.target.value})}/></div></div>
  </Modal>
}

function GoalModal({onClose,onCreate,projects,personalSkills}:{onClose:()=>void;onCreate:(x:any)=>string;projects:any[];personalSkills:any[]}){
  const [f,setF]=useState({level:'Week' as GoalLevel,title:'',skillId:'',projectId:'',start:isoToday(),due:addDays(isoToday(),7),hours:''})
  return <Modal title="New goal" onClose={onClose} footer={<><Button onClick={onClose}>Cancel</Button><Button variant="primary" disabled={!f.title.trim()} onClick={() => { onCreate({level:f.level,title:f.title.trim(),skillId:f.skillId?asSkillId(f.skillId):undefined,projectId:f.projectId||undefined,targetHours:f.hours===''?undefined:Math.max(0,Number(f.hours)||0),startDate:f.start,dueDate:f.due,status:'Active',notes:''}); onClose() }}>Create goal</Button></>}>
    <div className="field-grid"><div className="field"><label>Level</label><select className="select" value={f.level} onChange={e=>setF({...f,level:e.target.value as GoalLevel})}><option>Long-Term</option><option>Year</option><option>Month</option><option>Week</option><option>Session</option></select></div><div className="field"><label>Target hours</label><input className="input" type="number" min="0" value={f.hours} onChange={e=>setF({...f,hours:e.target.value})}/></div><div className="field full"><label>Title</label><input className="input" value={f.title} onChange={e=>setF({...f,title:e.target.value})}/></div><div className="field"><label>Skill</label><SkillSelect value={f.skillId} onChange={v=>setF({...f,skillId:String(v)})} personalSkills={personalSkills}/></div><div className="field"><label>Project</label><select className="select" value={f.projectId} onChange={e=>setF({...f,projectId:e.target.value})}><option value="">No project</option>{projects.map(p=><option key={p.id} value={p.id}>{p.title}</option>)}</select></div><div className="field"><label>Start</label><input className="input" type="date" value={f.start} onChange={e=>setF({...f,start:e.target.value})}/></div><div className="field"><label>Due</label><input className="input" type="date" value={f.due} onChange={e=>setF({...f,due:e.target.value})}/></div></div>
  </Modal>
}
