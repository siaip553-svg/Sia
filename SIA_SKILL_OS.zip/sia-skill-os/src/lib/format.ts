export function faNumber(value: number, fractionDigits = 0) {
  return Number(value).toLocaleString('fa-IR', { maximumFractionDigits: fractionDigits, minimumFractionDigits: fractionDigits })
}
export function hours(value: number | null | undefined) {
  return value === null || value === undefined || !Number.isFinite(value) ? 'Not Specified' : `${faNumber(value, 1)}h`
}
export function pct(value: number | null | undefined) {
  return value === null || value === undefined || !Number.isFinite(value) ? 'Not Assessed' : `${faNumber(value, 0)}٪`
}
export function dateFa(date?: string) {
  if (!date) return '—'
  const d = new Date(date)
  return Number.isNaN(d.getTime()) ? 'Invalid date' : d.toLocaleDateString('fa-IR')
}
export function minutesToText(minutes: number) {
  const m = Math.max(0, Math.round(minutes))
  const h = Math.floor(m / 60); const min = m % 60
  if (!h) return `${min}m`
  return min ? `${h}h ${min}m` : `${h}h`
}
export function isoToday() { return new Date().toISOString().slice(0, 10) }
export function startDay(date = new Date()) { const d = new Date(date); d.setHours(0,0,0,0); return d }
