import { openDB, type DBSchema, type IDBPDatabase } from 'idb'
import type { AppData, BackupSnapshot } from '../domain/types'

interface SiaDb extends DBSchema {
  app: {
    key: string
    value: AppData
  }
  backups: {
    key: string
    value: BackupSnapshot
    indexes: { 'createdAt': string }
  }
}

const DB_NAME = 'sia-skill-os'
const DB_VERSION = 2
const DATA_KEY = 'app-data'

let dbPromise: Promise<IDBPDatabase<SiaDb>> | null = null

function getDb() {
  if (!dbPromise) {
    dbPromise = openDB<SiaDb>(DB_NAME, DB_VERSION, {
      upgrade(db) {
        if (!db.objectStoreNames.contains('app')) db.createObjectStore('app')
        if (!db.objectStoreNames.contains('backups')) {
          const store = db.createObjectStore('backups', { keyPath: 'id' })
          store.createIndex('createdAt', 'createdAt')
        }
      },
    })
  }
  return dbPromise
}

export async function loadAppData() {
  return (await getDb()).get('app', DATA_KEY)
}

export async function saveAppData(data: AppData) {
  await (await getDb()).put('app', data, DATA_KEY)
}

export async function clearAppData() {
  await (await getDb()).delete('app', DATA_KEY)
}

export function supportsIndexedDB() {
  return typeof indexedDB !== 'undefined'
}

export async function saveBackup(snapshot: BackupSnapshot) {
  await (await getDb()).put('backups', snapshot)
}

export async function listBackups() {
  return (await getDb()).getAllFromIndex('backups', 'createdAt')
}

export async function getBackup(id: string) {
  return (await getDb()).get('backups', id)
}

export async function deleteBackup(id: string) {
  await (await getDb()).delete('backups', id)
}

export async function clearBackups() {
  await (await getDb()).clear('backups')
}

export function createBackupFileName(label: string) {
  const safe = label.trim().replace(/[^a-zA-Z0-9._-]+/g, '-').replace(/^-+|-+$/g, '') || 'backup'
  return `${safe}-${new Date().toISOString().slice(0,10)}.json`
}
