import type { AppData, Goal, Project, Session } from '../domain/types'
import { MASTER_SKILLS } from '../data/masterSkills'

const masterIds = new Set(MASTER_SKILLS.map(s => String(s.id)))

export interface ValidationIssue { path: string; message: string }

export function validateAppData(data: unknown): { ok: true; data: AppData } | { ok: false; issues: ValidationIssue[] } {
  const issues: ValidationIssue[] = []
  const seen = (values: string[], path: string) => { const set = new Set<string>(); values.forEach((v,i)=>{ if (set.has(v)) issues.push({path:`${path}[${i}]`,message:`Duplicate ID: ${v}`}); else set.add(v) }) }
  if (!data || typeof data !== 'object') return { ok: false, issues: [{ path: '', message: 'JSON root must be an object.' }] }
  const d = data as Partial<AppData>
  if (d.meta?.schemaVersion !== 1) issues.push({ path: 'meta.schemaVersion', message: 'Unsupported or missing schemaVersion.' })
  if (!Array.isArray(d.sessions)) issues.push({ path: 'sessions', message: 'sessions must be an array.' })
  if (!Array.isArray(d.planItems)) issues.push({ path: 'planItems', message: 'planItems must be an array.' })
  if (!Array.isArray(d.relations)) issues.push({ path: 'relations', message: 'relations must be an array.' })
  if (!Array.isArray(d.projects)) issues.push({ path: 'projects', message: 'projects must be an array.' })
  if (!Array.isArray(d.evidence)) issues.push({ path: 'evidence', message: 'evidence must be an array.' })
  if (!Array.isArray(d.goals)) issues.push({ path: 'goals', message: 'goals must be an array.' })
  if (!Array.isArray(d.personalSkills)) issues.push({ path: 'personalSkills', message: 'personalSkills must be an array.' })
  if (issues.length) return { ok: false, issues }

  const sessions = d.sessions as Session[]
  sessions.forEach((s, i) => {
    if (!s.id) issues.push({ path: `sessions[${i}].id`, message: 'Session ID is required.' })
    if (s.skillId === '' || s.skillId === undefined || s.skillId === null || (!masterIds.has(String(s.skillId)) && !(d.personalSkills || []).some(p => p.id === String(s.skillId)))) issues.push({ path: `sessions[${i}].skillId`, message: 'Session references an unknown skill.' })
    if (!Number.isFinite(s.durationMinutes) || s.durationMinutes < 0) issues.push({ path: `sessions[${i}].durationMinutes`, message: 'Duration cannot be negative.' })
    if (s.startedAt && s.endedAt && new Date(s.endedAt) < new Date(s.startedAt)) issues.push({ path: `sessions[${i}]`, message: 'Session end cannot be before start.' })
  })

  seen((d.sessions as Session[]).map(s=>s.id), 'sessions')
  seen((d.projects as Project[]).map(p=>p.id), 'projects')
  seen((d.evidence as {id:string}[]).map(e=>e.id), 'evidence')
  seen((d.goals as Goal[]).map(g=>g.id), 'goals')
  ;(d.projects as Project[]).forEach((p, i) => {
    if (p.deadline && p.startDate && new Date(p.deadline) < new Date(p.startDate)) issues.push({ path: `projects[${i}].deadline`, message: 'Project deadline cannot be before start.' })
  })
  ;(d.goals as Goal[]).forEach((g, i) => {
    if (new Date(g.dueDate) < new Date(g.startDate)) issues.push({ path: `goals[${i}]`, message: 'Goal due date cannot be before start.' })
  })
  Object.entries(d.progress || {}).forEach(([id, p]) => {
    if (!masterIds.has(String(id)) && !(d.personalSkills || []).some(ps => ps.id === String(id))) issues.push({ path: `progress.${id}`, message: 'Progress references an unknown skill; #218 is not source-defined.' })
    if (typeof p.completedHours !== 'number' || p.completedHours < 0) issues.push({ path: `progress.${id}.completedHours`, message: 'Completed hours cannot be negative.' })
    if (typeof p.plannedHours !== 'number' || p.plannedHours < 0) issues.push({ path: `progress.${id}.plannedHours`, message: 'Planned hours cannot be negative.' })
    for (const [key,value] of [['selfAssessment',p.selfAssessment],['testScore',p.testScore],['performanceScore',p.performanceScore] as const]) {
      if (value !== null && (typeof value !== 'number' || value < 0 || value > 100)) issues.push({ path: `progress.${id}.${key}`, message: `${key} must be 0–100.` })
    }
    if (p.maintenanceHours < 0) issues.push({ path: `progress.${id}.maintenanceHours`, message: 'Maintenance hours cannot be negative.' })
    if (p.startDate && p.targetDate && new Date(p.targetDate) < new Date(p.startDate)) issues.push({ path: `progress.${id}`, message: 'Target date cannot be before start date.' })
    if (p.nextReview && p.lastPractice && new Date(p.nextReview) < new Date(p.lastPractice)) issues.push({ path: `progress.${id}`, message: 'Next review cannot be before last practice.' })
  })

  return issues.length ? { ok: false, issues } : { ok: true, data: data as AppData }
}
