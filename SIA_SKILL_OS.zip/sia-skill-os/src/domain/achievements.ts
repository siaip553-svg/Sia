import type { AppData } from './types'

export interface Achievement {
  id: string
  title: string
  description: string
  unlocked: boolean
  metric: string
}

export function getAchievements(data: AppData): Achievement[] {
  const loggedMinutes = data.sessions.reduce((sum, s) => sum + Math.max(0, s.durationMinutes), 0)
  const completedProjects = data.projects.filter(p => p.status === 'Completed').length
  const ratedProjects = data.projects.filter(p => p.rating !== null).length
  const portfolioCount = data.portfolio.length
  const dailyDates = new Set(data.sessions.filter(s => s.durationMinutes > 0).map(s => s.date))
  const maintenanceDates = new Set(data.sessions.filter(s => s.durationMinutes > 0 && s.sessionType === 'Maintenance').map(s => s.date))
  const streak = (dates: Set<string>) => {
    let n = 0
    const d = new Date()
    while (dates.has(d.toISOString().slice(0,10))) { n += 1; d.setDate(d.getDate() - 1) }
    return n
  }
  const dailyStreak = streak(dailyDates)
  const maintenanceStreak = streak(maintenanceDates)
  const items: Achievement[] = [
    { id:'first-deep-work', title:'First Deep Work Session', description:'A real Deep Work session has been logged.', unlocked:data.sessions.some(s=>s.sessionType==='Deep Work'&&s.durationMinutes>0), metric:`${data.sessions.filter(s=>s.sessionType==='Deep Work').length} sessions` },
    { id:'100-hours', title:'100 Hours Logged', description:'At least 100 real learning hours have been logged.', unlocked:loggedMinutes>=6000, metric:`${(loggedMinutes/60).toFixed(1)}h` },
    { id:'500-hours', title:'500 Hours Logged', description:'At least 500 real learning hours have been logged.', unlocked:loggedMinutes>=30000, metric:`${(loggedMinutes/60).toFixed(1)}h` },
    { id:'first-project', title:'First Portfolio Project', description:'A project has been completed and added to the portfolio.', unlocked:completedProjects>0 && portfolioCount>0, metric:`${completedProjects} completed · ${portfolioCount} portfolio` },
    { id:'10-projects', title:'10 Projects Completed', description:'Ten projects have been marked completed.', unlocked:completedProjects>=10, metric:`${completedProjects} completed` },
    { id:'rated-evidence', title:'Evidence Assessed', description:'At least one project/evidence record has a rating or score.', unlocked:ratedProjects>0 || data.evidence.some(e=>e.score!==null), metric:`${ratedProjects} rated projects · ${data.evidence.filter(e=>e.score!==null).length} scored evidence` },
    { id:'learning-streak-7', title:'7-Day Learning Streak', description:'Real learning has been logged on seven consecutive days ending today.', unlocked:dailyStreak>=7, metric:`${dailyStreak} days` },
    { id:'maintenance-streak-7', title:'7-Day Maintenance Streak', description:'Maintenance practice has been logged on seven consecutive days ending today.', unlocked:maintenanceStreak>=7, metric:`${maintenanceStreak} days` },
  ]
  return items
}
