import type { MasterSkillRecord, Session, SkillId } from './types'

export function todayKey(d = new Date()) { return d.toISOString().slice(0, 10) }
export function startOfWeek(date = new Date(), weekStart: 0 | 1 | 6 = 6) {
  const d = new Date(date); const day = d.getDay(); const diff = (day - weekStart + 7) % 7; d.setDate(d.getDate() - diff); d.setHours(0,0,0,0); return d
}
export function startOfMonth(date = new Date()) { const d = new Date(date.getFullYear(), date.getMonth(), 1); d.setHours(0,0,0,0); return d }
export function sessionsMinutes(sessions: Session[], from?: Date, to?: Date) {
  return sessions.filter(s => {
    const d = new Date(s.date)
    return (!from || d >= from) && (!to || d <= to)
  }).reduce((sum, s) => sum + Math.max(0, s.durationMinutes), 0)
}
export function skillLabel(skill: MasterSkillRecord | undefined, personal?: { id: string; name: string }) {
  return skill?.name ?? personal?.name ?? 'Unknown skill'
}
export function groupMinutesBySkill(sessions: Session[]) {
  return sessions.reduce<Record<string, number>>((acc, s) => { const k = String(s.skillId); acc[k] = (acc[k] || 0) + Math.max(0, s.durationMinutes); return acc }, {})
}
export function dateRangeLabel(from: Date, to: Date) { return `${from.toLocaleDateString('fa-IR')} – ${to.toLocaleDateString('fa-IR')}` }
