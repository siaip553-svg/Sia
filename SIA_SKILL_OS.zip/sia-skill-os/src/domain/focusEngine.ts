import type { CareerProfile, Evidence, FocusSuggestion, Goal, MasterSkillRecord, MasteryWeights, Project, Session, SkillId, SkillProgress } from './types'
import { masteryScore, remainingHours } from './formulas'
import { maintenanceStatus } from './maintenance'
import { sameSkillId } from './skills'

const priorityScore: Record<SkillProgress['priority'], number> = { P0: 100, P1: 82, P2: 62, P3: 42, P4: 24 }

function daysUntil(date?: string) {
  if (!date) return null
  const t = new Date(date).getTime()
  if (!Number.isFinite(t)) return null
  return Math.ceil((t - Date.now()) / 86400000)
}

export function rankFocus(args: {
  skills: readonly MasterSkillRecord[]
  progress: Record<string, SkillProgress>
  projects: Project[]
  sessions: Session[]
  evidence: Evidence[]
  goals: Goal[]
  career: Record<string, CareerProfile>
  weights?: MasteryWeights
}): FocusSuggestion[] {
  const { skills, progress, projects, sessions, evidence, goals, career } = args
  const candidates: FocusSuggestion[] = []
  for (const skill of skills) {
    const p = progress[String(skill.id)]
    if (!p || p.status === 'Completed') continue
    const hasUserSignal = p.priority !== 'P3' || p.targetDate || p.plannedHours > 0 || projects.some((x) => x.skillIds.some((id) => sameSkillId(id, skill.id)) && x.status === 'Active') || goals.some((x) => sameSkillId(x.skillId, skill.id) && x.status === 'Active') || maintenanceStatus(skill, p).state === 'Due'
    if (!hasUserSignal) continue
    let score = priorityScore[p.priority]
    const reasons: string[] = []
    if (p.priority === 'P0' || p.priority === 'P1') reasons.push(p.priority)
    const days = daysUntil(p.targetDate)
    if (days !== null) {
      if (days < 0) { score += 30; reasons.push('Target date overdue') }
      else if (days <= 7) { score += 24; reasons.push(`${days}d to target`) }
      else if (days <= 30) { score += 12; reasons.push(`${days}d to target`) }
    }
    const activeProject = projects.find((x) => x.skillIds.some((id) => sameSkillId(id, skill.id)) && x.status === 'Active')
    if (activeProject) { score += 20; reasons.push('Active project') }
    const target = remainingHours(skill, p)
    if (target !== null && target > 0) {
      if (target >= 100) { score += 8; reasons.push(`${Math.round(target)}h remaining`) }
      else if (target >= 30) { score += 5; reasons.push(`${Math.round(target)}h remaining`) }
    }
    const due = maintenanceStatus(skill, p).state
    if (due === 'Due') { score += 25; reasons.push('Maintenance due') }
    if (due === 'Upcoming') { score += 8; reasons.push('Maintenance upcoming') }
    const cv = career[String(skill.id)]?.careerValue
    if (typeof cv === 'number' && cv >= 70) { score += 12; reasons.push(`Career value ${cv}/100`) }
    const activeGoals = goals.filter((g) => sameSkillId(g.skillId, skill.id) && g.status === 'Active')
    if (activeGoals.length) { score += 15; reasons.push('Active goal') }
    const m = masteryScore({ skill, progress: p, sessions, projects, evidence, weights: args.weights })
    if (m.score !== null && m.score >= 85) score -= 10
    candidates.push({ skillId: skill.id, score: Math.max(0, Math.min(160, score)), reasons: reasons.slice(0, 4), action: activeProject ? `Continue: ${activeProject.title}` : `Start a focused ${p.plannedHours ? 'planned' : 'practice'} session` })
  }
  return candidates.sort((a, b) => b.score - a.score).slice(0, 8)
}
