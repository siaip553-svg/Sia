import type { SkillId } from './types'

export function skillKey(id: SkillId | null | undefined) {
  return id === null || id === undefined ? '' : String(id)
}

export function sameSkillId(a: SkillId | null | undefined, b: SkillId | null | undefined) {
  return skillKey(a) !== '' && skillKey(a) === skillKey(b)
}
