export type ID = number | string
export type SkillId = number | string

export type SkillStatus = 'Not Started' | 'Learning' | 'Practicing' | 'Functional' | 'Completed' | 'Maintenance'
export type SkillLevel = 'Beginner' | 'Elementary' | 'Intermediate' | 'Advanced' | 'Maintenance'
export type Priority = 'P0' | 'P1' | 'P2' | 'P3' | 'P4'
export type SessionType = 'Deep Work' | 'Practice' | 'Review' | 'Project' | 'Assessment' | 'Maintenance' | 'Other'
export type Lifecycle = 'active' | 'paused' | 'deleted' | 'undefined'
export type GoalLevel = 'Long-Term' | 'Year' | 'Month' | 'Week' | 'Session'
export type EvidenceType = 'Project' | 'Test' | 'Performance' | 'Competition' | 'Certificate' | 'Client Work' | 'Portfolio' | 'Practical Demonstration'

export interface MasterSkillRecord {
  id: SkillId
  name: string
  category: string
  desc?: string | null
  initHoursRaw?: string | null
  initHours?: number | null
  realHoursRaw?: string | null
  realHours?: number | null
  sourceStatus?: string | null
  flags?: readonly string[]
  sourceLines?: readonly number[]
  sourceRaw?: readonly string[]
  sourceFile?: string
  undefined?: boolean
}

export interface PersonalSkill {
  id: string
  name: string
  category?: string
  description?: string
  targetHours?: number | null
  targetHoursType?: 'fixed' | 'open-ended' | 'undefined'
  createdAt: string
  archived?: boolean
  tags: string[]
}

export interface SkillProgress {
  status: SkillStatus
  level: SkillLevel
  priority: Priority
  lifeStage?: string
  plannedHours: number
  completedHours: number
  maintenanceHours: number
  careerValue: number | null
  personalValue: number | null
  difficulty: number | null
  startDate?: string
  targetDate?: string
  lastPractice?: string
  nextReview?: string
  maintenanceIntervalDays: number | null
  notes: string
  tags: string[]
  selfAssessment: number | null
  testScore: number | null
  performanceScore: number | null
  customMetrics: Record<string, number | string | boolean | null>
  customAttributes: Record<string, string | number | boolean | null>
  updatedAt: string
}

export interface PlanItem {
  id: string
  skillId: SkillId
  projectId?: string
  title: string
  date: string
  durationMinutes: number
  status: 'Planned' | 'Done' | 'Skipped'
  note?: string
  createdAt: string
}

export interface SkillRelation {
  id: string
  fromSkillId: SkillId
  toSkillId: SkillId
  type: 'dependency' | 'synergy'
  strength: number
  label?: string
  createdAt: string
}

export interface Session {
  id: string
  skillId: SkillId
  projectId?: string
  date: string
  startedAt?: string
  endedAt?: string
  durationMinutes: number
  sessionType: SessionType
  note?: string
  reflection?: Reflection
  source: 'timer' | 'manual'
  createdAt: string
}

export interface ActiveTimer {
  skillId: SkillId
  projectId?: string
  sessionType: SessionType
  startedAt: string
  accumulatedMinutes: number
  pausedAt?: string
  goal?: string
  task?: string
}

export interface Project {
  id: string
  title: string
  description: string
  skillIds: SkillId[]
  difficulty: number | null
  startDate?: string
  deadline?: string
  status: 'Planned' | 'Active' | 'Completed' | 'Paused' | 'Archived'
  deliverables: string[]
  evidenceIds: string[]
  notes: string
  rating: number | null
  reflection?: Reflection
  createdAt: string
  updatedAt: string
}

export interface Evidence {
  id: string
  title: string
  type: EvidenceType
  skillIds: SkillId[]
  projectId?: string
  score: number | null
  url?: string
  description: string
  date?: string
  createdAt: string
}

export interface PortfolioItem {
  id: string
  title: string
  url?: string
  screenshotDataUrl?: string
  description: string
  skillIds: SkillId[]
  result: string
  clientType: 'Client' | 'Personal' | 'Team' | 'Unknown'
  date?: string
  createdAt: string
}

export interface CareerProfile {
  skillId: SkillId
  careerValue: number | null
  marketRelevance: number | null
  portfolioStatus: 'None' | 'Draft' | 'Published'
  clientReadiness: number | null
  incomePotential: number | null
  offer: string
  outreachStatus: 'None' | 'Preparing' | 'Active' | 'Paused' | 'Closed'
  notes: string
  updatedAt: string
}

export interface Goal {
  id: string
  level: GoalLevel
  title: string
  skillId?: SkillId
  projectId?: string
  targetHours?: number
  targetSessions?: number
  startDate: string
  dueDate: string
  status: 'Active' | 'Completed' | 'Missed' | 'Archived'
  notes: string
  createdAt: string
  updatedAt: string
}

export interface Reflection {
  learned: string
  difficult: string
  improved: string
  next: string
}

export interface Review {
  id: string
  period: 'Month' | 'Year'
  key: string
  strengths: string
  weaknesses: string
  missedGoals: string
  maintenance: string
  nextPeriod: string
  notes: string
  updatedAt: string
}

export interface MasteryWeights {
  practice: number
  projects: number
  tests: number
  selfAssessment: number
  performance: number
  consistency: number
}

export interface Preferences {
  theme: 'dark' | 'light'
  accent: 'teal' | 'blue' | 'purple' | 'amber'
  weekStart: 0 | 1 | 6
  dailyGoalHours: number
  defaultSessionMinutes: number
  notifications: boolean
  shortcutsEnabled: boolean
  dashboardWidgets: string[]
  skillsView: 'cards' | 'table'
  lifeStages: string[]
  masteryWeights: MasteryWeights
}

export interface BackupSnapshot {
  id: string
  createdAt: string
  label: string
  appVersion: string
  schemaVersion: number
  data: AppData
}

export interface SchemaMeta {
  schemaVersion: 1
  appVersion: string
  createdAt: string
  updatedAt: string
}

export interface AppData {
  meta: SchemaMeta
  preferences: Preferences
  progress: Record<string, SkillProgress>
  personalSkills: PersonalSkill[]
  sessions: Session[]
  planItems: PlanItem[]
  relations: SkillRelation[]
  projects: Project[]
  evidence: Evidence[]
  portfolio: PortfolioItem[]
  career: Record<string, CareerProfile>
  goals: Goal[]
  reviews: Review[]
  activeTimer: ActiveTimer | null
}

export interface FocusSuggestion {
  skillId: SkillId
  score: number
  reasons: string[]
  action: string
}

export const DEFAULT_PREFERENCES: Preferences = {
  theme: 'dark',
  accent: 'teal',
  weekStart: 6,
  dailyGoalHours: 3,
  defaultSessionMinutes: 60,
  notifications: true,
  shortcutsEnabled: true,
  dashboardWidgets: ['focus', 'stats', 'today', 'weekly', 'maintenance', 'distribution'],
  skillsView: 'cards',
  lifeStages: ['17–22', '22–28', '28–35', '35–43', 'Lifelong'],
  masteryWeights: { practice: 0.20, projects: 0.25, tests: 0.20, selfAssessment: 0.10, performance: 0.20, consistency: 0.05 },
}

export function nowISO() {
  return new Date().toISOString()
}

export function defaultSkillProgress(): SkillProgress {
  return {
    status: 'Not Started',
    level: 'Beginner',
    priority: 'P3',
    plannedHours: 0,
    completedHours: 0,
    maintenanceHours: 0,
    careerValue: null,
    personalValue: null,
    difficulty: null,
    maintenanceIntervalDays: null,
    notes: '',
    tags: [],
    selfAssessment: null,
    testScore: null,
    performanceScore: null,
    customMetrics: {},
    customAttributes: {},
    updatedAt: nowISO(),
  }
}

export function createInitialData(appVersion = '1.0.0'): AppData {
  const now = nowISO()
  return {
    meta: { schemaVersion: 1, appVersion, createdAt: now, updatedAt: now },
    preferences: { ...DEFAULT_PREFERENCES },
    progress: {},
    personalSkills: [],
    sessions: [],
    planItems: [],
    relations: [],
    projects: [],
    evidence: [],
    portfolio: [],
    career: {},
    goals: [],
    reviews: [],
    activeTimer: null,
  }
}
