import type { MasterSkillRecord, SkillProgress } from './types'

export function maintenanceStatus(skill: MasterSkillRecord, progress: SkillProgress, today = new Date()) {
  const interval = progress.maintenanceIntervalDays
  if (!interval || interval <= 0 || !progress.lastPractice) return { state: 'Not configured' as const, daysSince: null }
  const last = new Date(progress.lastPractice)
  if (Number.isNaN(last.getTime())) return { state: 'Invalid date' as const, daysSince: null }
  const daysSince = Math.floor((today.getTime() - last.getTime()) / 86400000)
  if (daysSince >= interval) return { state: 'Due' as const, daysSince }
  if (daysSince >= interval * 0.8) return { state: 'Upcoming' as const, daysSince }
  return { state: 'Current' as const, daysSince }
}

export function nextReviewDate(lastPractice: string | undefined, intervalDays: number | null) {
  if (!lastPractice || !intervalDays || intervalDays <= 0) return undefined
  const d = new Date(lastPractice)
  if (Number.isNaN(d.getTime())) return undefined
  d.setDate(d.getDate() + intervalDays)
  return d.toISOString().slice(0, 10)
}
