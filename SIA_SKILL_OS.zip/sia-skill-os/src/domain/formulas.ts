import type { Evidence, MasterSkillRecord, MasteryWeights, Project, Session, SkillId, SkillProgress } from './types'
import { sameSkillId } from './skills'

export const DEFAULT_MASTERY_WEIGHTS = {
  practice: 0.2,
  projects: 0.25,
  tests: 0.2,
  selfAssessment: 0.1,
  performance: 0.2,
  consistency: 0.05,
} as const

export function clamp(value: number, min = 0, max = 100) {
  return Math.min(max, Math.max(min, value))
}

export function getTargetHours(skill: MasterSkillRecord) {
  return typeof skill.realHours === 'number' && Number.isFinite(skill.realHours) ? skill.realHours : null
}

export function timeProgress(skill: MasterSkillRecord, progress: SkillProgress) {
  const target = getTargetHours(skill)
  if (target === null || target <= 0) return null
  return clamp((Math.max(0, progress.completedHours) / target) * 100)
}

export function remainingHours(skill: MasterSkillRecord, progress: SkillProgress) {
  const target = getTargetHours(skill)
  if (target === null) return null
  return Math.max(0, target - Math.max(0, progress.completedHours))
}

function recentConsistency(sessions: Session[], skillId: SkillId, days = 30) {
  const cutoff = new Date()
  cutoff.setDate(cutoff.getDate() - days + 1)
  const dates = new Set<string>()
  sessions.forEach((session) => {
    if (!sameSkillId(session.skillId, skillId)) return
    const when = new Date(session.date)
    if (when >= cutoff && session.durationMinutes > 0) dates.add(session.date)
  })
  return clamp((dates.size / days) * 100)
}

function average(nums: number[]) {
  const valid = nums.filter(Number.isFinite)
  return valid.length ? valid.reduce((a, b) => a + b, 0) / valid.length : null
}

export function masteryScore(args: {
  skill: MasterSkillRecord
  progress: SkillProgress
  sessions: Session[]
  projects: Project[]
  evidence: Evidence[]
  weights?: MasteryWeights
}) {
  const { skill, progress, sessions, projects, evidence } = args
  const raw = args.weights ?? DEFAULT_MASTERY_WEIGHTS
  const weightTotalRaw = Object.values(raw).reduce((sum, value) => sum + Math.max(0, Number(value) || 0), 0) || 1
  const W = Object.fromEntries(Object.entries(raw).map(([key,value]) => [key, Math.max(0, Number(value) || 0) / weightTotalRaw])) as unknown as MasteryWeights
  const target = getTargetHours(skill)
  const practice = target ? clamp((Math.max(0, progress.completedHours) / target) * 100) : null
  const skillProjects = projects.filter((p) => p.skillIds.some((id) => sameSkillId(id, skill.id)))
  const projectScores = skillProjects.map((p) => p.rating).filter((v): v is number => typeof v === 'number')
  const projectEvidenceScores = evidence
    .filter((e) => e.skillIds.some((id) => sameSkillId(id, skill.id)) && e.type === 'Project')
    .map((e) => e.score)
    .filter((v): v is number => typeof v === 'number')
  const projectsComponent = average([...projectScores, ...projectEvidenceScores])
  const skillTests = evidence
    .filter((e) => e.skillIds.some((id) => sameSkillId(id, skill.id)) && e.type === 'Test')
    .map((e) => e.score)
    .filter((v): v is number => typeof v === 'number')
  const testsComponent = average([progress.testScore ?? NaN, ...skillTests])
  const selfComponent = progress.selfAssessment
  const performanceEvidence = evidence
    .filter((e) => e.skillIds.some((id) => sameSkillId(id, skill.id)) && (e.type === 'Performance' || e.type === 'Competition' || e.type === 'Client Work' || e.type === 'Practical Demonstration'))
    .map((e) => e.score)
    .filter((v): v is number => typeof v === 'number')
  const performanceComponent = average([progress.performanceScore ?? NaN, ...performanceEvidence])
  const consistencyComponent = recentConsistency(sessions, skill.id)

  const components = [
    [W.practice, practice],
    [W.projects, projectsComponent],
    [W.tests, testsComponent],
    [W.selfAssessment, selfComponent],
    [W.performance, performanceComponent],
    [W.consistency, consistencyComponent],
  ] as const

  // Only score on evidence actually available; do not invent missing assessments.
  let weighted = 0
  let weightTotal = 0
  for (const [weight, value] of components) {
    if (value === null || !Number.isFinite(value)) continue
    weighted += weight * clamp(value)
    weightTotal += weight
  }
  if (weightTotal === 0) return { score: null, components: { practice, projects: projectsComponent, tests: testsComponent, selfAssessment: selfComponent, performance: performanceComponent, consistency: consistencyComponent } }
  return {
    score: clamp(weighted / weightTotal),
    components: {
      practice,
      projects: projectsComponent,
      tests: testsComponent,
      selfAssessment: selfComponent,
      performance: performanceComponent,
      consistency: consistencyComponent,
    },
  }
}

export function formatMastery(score: number | null) {
  if (score === null) return 'Not Assessed'
  if (score < 25) return 'Emerging'
  if (score < 50) return 'Developing'
  if (score < 70) return 'Functional'
  if (score < 85) return 'Strong'
  return 'Advanced'
}
