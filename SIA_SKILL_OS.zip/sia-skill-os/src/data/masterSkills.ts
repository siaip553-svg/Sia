/*
 * Source-of-truth snapshot generated from the final detailed sections of eeje.txt.
 * Bundled/range rows remain bundles; they are NOT expanded into invented child records.
 * #218 is absent from the source and therefore absent here.
 */
export const MASTER_SKILLS = [
  {
    "id": 1,
    "name": "قصر حافظه",
    "category": "🧠 دسته ۱: حافظه و ذهن (۱۱ مورد) — ✅ همه کامل",
    "desc": "تکنیک لوکای برای ذخیره اطلاعات در مکان‌های ذهنی",
    "initHoursRaw": "50",
    "initHours": 50.0,
    "realHoursRaw": "62",
    "realHours": 62.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8699
    ],
    "sourceRaw": [
      "| 1 | قصر حافظه | تکنیک لوکای برای ذخیره اطلاعات در مکان‌های ذهنی | 50 | 62 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 2,
    "name": "سیستم PAO",
    "category": "🧠 دسته ۱: حافظه و ذهن (۱۱ مورد) — ✅ همه کامل",
    "desc": "تبدیل اعداد به شخص-عمل-شیء",
    "initHoursRaw": "50",
    "initHours": 50.0,
    "realHoursRaw": "62",
    "realHours": 62.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8700
    ],
    "sourceRaw": [
      "| 2 | سیستم PAO | تبدیل اعداد به شخص-عمل-شیء | 50 | 62 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 3,
    "name": "حفظ ترتیب کارت",
    "category": "🧠 دسته ۱: حافظه و ذهن (۱۱ مورد) — ✅ همه کامل",
    "desc": "حفظ کل دست کارت با PAO",
    "initHoursRaw": "30",
    "initHours": 30.0,
    "realHoursRaw": "37",
    "realHours": 37.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8701
    ],
    "sourceRaw": [
      "| 3 | حفظ ترتیب کارت | حفظ کل دست کارت با PAO | 30 | 37 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 4,
    "name": "تندخوانی",
    "category": "🧠 دسته ۱: حافظه و ذهن (۱۱ مورد) — ✅ همه کامل",
    "desc": "خواندن سریع با حفظ درک مطلب",
    "initHoursRaw": "50",
    "initHours": 50.0,
    "realHoursRaw": "62",
    "realHours": 62.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8702
    ],
    "sourceRaw": [
      "| 4 | تندخوانی | خواندن سریع با حفظ درک مطلب | 50 | 62 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 5,
    "name": "محاسبات ذهنی",
    "category": "🧠 دسته ۱: حافظه و ذهن (۱۱ مورد) — ✅ همه کامل",
    "desc": "ضرب، تقسیم، درصد، جذر بدون کاغذ",
    "initHoursRaw": "40",
    "initHours": 40.0,
    "realHoursRaw": "50",
    "realHours": 50.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8703
    ],
    "sourceRaw": [
      "| 5 | محاسبات ذهنی | ضرب، تقسیم، درصد، جذر بدون کاغذ | 40 | 50 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 6,
    "name": "رؤیای شفاف",
    "category": "🧠 دسته ۱: حافظه و ذهن (۱۱ مورد) — ✅ همه کامل",
    "desc": "کنترل آگاهانه‌ی خواب و رویا",
    "initHoursRaw": "100",
    "initHours": 100.0,
    "realHoursRaw": "124",
    "realHours": 124.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8704
    ],
    "sourceRaw": [
      "| 6 | رؤیای شفاف | کنترل آگاهانه‌ی خواب و رویا | 100 | 124 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 7,
    "name": "تمرکز عمیق",
    "category": "🧠 دسته ۱: حافظه و ذهن (۱۱ مورد) — ✅ همه کامل",
    "desc": "کار بدون حواس‌پرتی برای بازه‌های طولانی",
    "initHoursRaw": "30",
    "initHours": 30.0,
    "realHoursRaw": "37",
    "realHours": 37.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8705
    ],
    "sourceRaw": [
      "| 7 | تمرکز عمیق | کار بدون حواس‌پرتی برای بازه‌های طولانی | 30 | 37 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 8,
    "name": "بازی کیم",
    "category": "🧠 دسته ۱: حافظه و ذهن (۱۱ مورد) — ✅ همه کامل",
    "desc": "تقویت مشاهده و دقت به جزئیات",
    "initHoursRaw": "20",
    "initHours": 20.0,
    "realHoursRaw": "25",
    "realHours": 25.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8706
    ],
    "sourceRaw": [
      "| 8 | بازی کیم | تقویت مشاهده و دقت به جزئیات | 20 | 25 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 9,
    "name": "حفظ لغات",
    "category": "🧠 دسته ۱: حافظه و ذهن (۱۱ مورد) — ✅ همه کامل",
    "desc": "تصویرسازی برای یادگیری سریع واژگان",
    "initHoursRaw": "20",
    "initHours": 20.0,
    "realHoursRaw": "25",
    "realHours": 25.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8707
    ],
    "sourceRaw": [
      "| 9 | حفظ لغات | تصویرسازی برای یادگیری سریع واژگان | 20 | 25 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 10,
    "name": "تندنویسی گرگ",
    "category": "🧠 دسته ۱: حافظه و ذهن (۱۱ مورد) — ✅ همه کامل",
    "desc": "نوشتن سریع با علائم اختصاری",
    "initHoursRaw": "100",
    "initHours": 100.0,
    "realHoursRaw": "124",
    "realHours": 124.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8708
    ],
    "sourceRaw": [
      "| 10 | تندنویسی گرگ | نوشتن سریع با علائم اختصاری | 100 | 124 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 11,
    "name": "زبان بدن",
    "category": "🗣️ دسته ۲: ارتباط و نفوذ (۱۱ مورد) — ✅ همه کامل",
    "desc": "خواندن و کنترل آگاهانه‌ی حرکات بدن",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "85",
    "realHours": 85.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8714
    ],
    "sourceRaw": [
      "| 11 | زبان بدن | خواندن و کنترل آگاهانه‌ی حرکات بدن | 60 | 85 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 12,
    "name": "خواندن سرد",
    "category": "🗣️ دسته ۲: ارتباط و نفوذ (۱۱ مورد) — ✅ همه کامل",
    "desc": "ایجاد حس شناخت عمیق با غریبه‌ها",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "85",
    "realHours": 85.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8715
    ],
    "sourceRaw": [
      "| 12 | خواندن سرد | ایجاد حس شناخت عمیق با غریبه‌ها | 60 | 85 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 13,
    "name": "تحلیل اظهارات",
    "category": "🗣️ دسته ۲: ارتباط و نفوذ (۱۱ مورد) — ✅ همه کامل",
    "desc": "تحلیل کلام برای کشف حقیقت",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "85",
    "realHours": 85.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8716
    ],
    "sourceRaw": [
      "| 13 | تحلیل اظهارات | تحلیل کلام برای کشف حقیقت | 60 | 85 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 14,
    "name": "متقاعدسازی",
    "category": "🗣️ دسته ۲: ارتباط و نفوذ (۱۱ مورد) — ✅ همه کامل",
    "desc": "۶ اصل نفوذ سیالدینی",
    "initHoursRaw": "40",
    "initHours": 40.0,
    "realHoursRaw": "57",
    "realHours": 57.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8717
    ],
    "sourceRaw": [
      "| 14 | متقاعدسازی | ۶ اصل نفوذ سیالدینی | 40 | 57 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 15,
    "name": "مذاکره FBI",
    "category": "🗣️ دسته ۲: ارتباط و نفوذ (۱۱ مورد) — ✅ همه کامل",
    "desc": "تکنیک‌های مذاکره‌ی کریس واس",
    "initHoursRaw": "50",
    "initHours": 50.0,
    "realHoursRaw": "71",
    "realHours": 71.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8718
    ],
    "sourceRaw": [
      "| 15 | مذاکره FBI | تکنیک‌های مذاکره‌ی کریس واس | 50 | 71 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 16,
    "name": "داستان‌سرایی",
    "category": "🗣️ دسته ۲: ارتباط و نفوذ (۱۱ مورد) — ✅ همه کامل",
    "desc": "ساختار روایت سه‌پرده‌ای",
    "initHoursRaw": "50",
    "initHours": 50.0,
    "realHoursRaw": "71",
    "realHours": 71.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8719
    ],
    "sourceRaw": [
      "| 16 | داستان‌سرایی | ساختار روایت سه‌پرده‌ای | 50 | 71 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 17,
    "name": "بداهه‌پردازی",
    "category": "🗣️ دسته ۲: ارتباط و نفوذ (۱۱ مورد) — ✅ همه کامل",
    "desc": "پاسخ سریع و خلاق در لحظه",
    "initHoursRaw": "50",
    "initHours": 50.0,
    "realHoursRaw": "71",
    "realHours": 71.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8720
    ],
    "sourceRaw": [
      "| 17 | بداهه‌پردازی | پاسخ سریع و خلاق در لحظه | 50 | 71 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 18,
    "name": "رپورت",
    "category": "🗣️ دسته ۲: ارتباط و نفوذ (۱۱ مورد) — ✅ همه کامل",
    "desc": "ایجاد اعتماد و ارتباط فوری",
    "initHoursRaw": "20",
    "initHours": 20.0,
    "realHoursRaw": "28",
    "realHours": 28.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8721
    ],
    "sourceRaw": [
      "| 18 | رپورت | ایجاد اعتماد و ارتباط فوری | 20 | 28 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 19,
    "name": "هیپنوتیزم اریکسونی",
    "category": "🗣️ دسته ۲: ارتباط و نفوذ (۱۱ مورد) — ✅ همه کامل",
    "desc": "الگوهای زبانی نفوذی و ظریف",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "85",
    "realHours": 85.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8722
    ],
    "sourceRaw": [
      "| 19 | هیپنوتیزم اریکسونی | الگوهای زبانی نفوذی و ظریف | 60 | 85 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 20,
    "name": "کاریکاتور چهره",
    "category": "🗣️ دسته ۲: ارتباط و نفوذ (۱۱ مورد) — ✅ همه کامل",
    "desc": "طراحی سریع و اغراق‌شده‌ی چهره",
    "initHoursRaw": "50",
    "initHours": 50.0,
    "realHoursRaw": "71",
    "realHours": 71.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8723
    ],
    "sourceRaw": [
      "| 20 | کاریکاتور چهره | طراحی سریع و اغراق‌شده‌ی چهره | 50 | 71 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 21,
    "name": "تفکر نقادانه",
    "category": "🧩 دسته ۳: تحلیل، تفکر و برنامه‌نویسی پایه (۱۲ مورد) — ✅ ۱۰/۱۰ عمومی کامل",
    "desc": "تشخیص مغالطه و استدلال درست",
    "initHoursRaw": "30",
    "initHours": 30.0,
    "realHoursRaw": "36",
    "realHours": 36.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8729
    ],
    "sourceRaw": [
      "| 21 | تفکر نقادانه | تشخیص مغالطه و استدلال درست | 30 | 36 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 22,
    "name": "حل مسئله خلاق (TRIZ)",
    "category": "🧩 دسته ۳: تحلیل، تفکر و برنامه‌نویسی پایه (۱۲ مورد) — ✅ ۱۰/۱۰ عمومی کامل",
    "desc": "حل مسائل پیچیده با اصول تناقض",
    "initHoursRaw": "40",
    "initHours": 40.0,
    "realHoursRaw": "49",
    "realHours": 49.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8730
    ],
    "sourceRaw": [
      "| 22 | حل مسئله خلاق (TRIZ) | حل مسائل پیچیده با اصول تناقض | 40 | 49 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 23,
    "name": "تصمیم‌گیری",
    "category": "🧩 دسته ۳: تحلیل، تفکر و برنامه‌نویسی پایه (۱۲ مورد) — ✅ ۱۰/۱۰ عمومی کامل",
    "desc": "ماتریس تصمیم و تحلیل ریسک",
    "initHoursRaw": "30",
    "initHours": 30.0,
    "realHoursRaw": "36",
    "realHours": 36.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8731
    ],
    "sourceRaw": [
      "| 23 | تصمیم‌گیری | ماتریس تصمیم و تحلیل ریسک | 30 | 36 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 24,
    "name": "آمار شهودی",
    "category": "🧩 دسته ۳: تحلیل، تفکر و برنامه‌نویسی پایه (۱۲ مورد) — ✅ ۱۰/۱۰ عمومی کامل",
    "desc": "درک احتمال و داده در زندگی روزمره",
    "initHoursRaw": "40",
    "initHours": 40.0,
    "realHoursRaw": "49",
    "realHours": 49.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8732
    ],
    "sourceRaw": [
      "| 24 | آمار شهودی | درک احتمال و داده در زندگی روزمره | 40 | 49 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 25,
    "name": "پایتون پایه",
    "category": "🧩 دسته ۳: تحلیل، تفکر و برنامه‌نویسی پایه (۱۲ مورد) — ✅ ۱۰/۱۰ عمومی کامل",
    "desc": "زبان برنامه‌نویسی عمومی برای خودکارسازی",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "73",
    "realHours": 73.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8733
    ],
    "sourceRaw": [
      "| 25 | پایتون پایه | زبان برنامه‌نویسی عمومی برای خودکارسازی | 60 | 73 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 26,
    "name": "تحلیل داده (Excel/Pandas)",
    "category": "🧩 دسته ۳: تحلیل، تفکر و برنامه‌نویسی پایه (۱۲ مورد) — ✅ ۱۰/۱۰ عمومی کامل",
    "desc": "استخراج بینش از داده‌های مالی/کاری",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "73",
    "realHours": 73.0,
    "sourceStatus": "✅ (مسیر شغل)",
    "sourceLines": [
      8734
    ],
    "sourceRaw": [
      "| 26 🔧 | تحلیل داده (Excel/Pandas) | استخراج بینش از داده‌های مالی/کاری | 60 | 73 | ✅ (مسیر شغل) |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 27,
    "name": "تفکر سیستمی",
    "category": "🧩 دسته ۳: تحلیل، تفکر و برنامه‌نویسی پایه (۱۲ مورد) — ✅ ۱۰/۱۰ عمومی کامل",
    "desc": "دیدن کل و روابط بین اجزا",
    "initHoursRaw": "40",
    "initHours": 40.0,
    "realHoursRaw": "49",
    "realHours": 49.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8735
    ],
    "sourceRaw": [
      "| 27 | تفکر سیستمی | دیدن کل و روابط بین اجزا | 40 | 49 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 28,
    "name": "نقشه ذهنی",
    "category": "🧩 دسته ۳: تحلیل، تفکر و برنامه‌نویسی پایه (۱۲ مورد) — ✅ ۱۰/۱۰ عمومی کامل",
    "desc": "سازماندهی بصری اطلاعات",
    "initHoursRaw": "20",
    "initHours": 20.0,
    "realHoursRaw": "24",
    "realHours": 24.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8736
    ],
    "sourceRaw": [
      "| 28 | نقشه ذهنی | سازماندهی بصری اطلاعات | 20 | 24 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 29,
    "name": "یادگیری ماشین مقدماتی",
    "category": "🧩 دسته ۳: تحلیل، تفکر و برنامه‌نویسی پایه (۱۲ مورد) — ✅ ۱۰/۱۰ عمومی کامل",
    "desc": "مبانی ساخت مدل‌های پیش‌بینی",
    "initHoursRaw": "80",
    "initHours": 80.0,
    "realHoursRaw": "97",
    "realHours": 97.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8737
    ],
    "sourceRaw": [
      "| 29 | یادگیری ماشین مقدماتی | مبانی ساخت مدل‌های پیش‌بینی | 80 | 97 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 30,
    "name": "اقتصاد رفتاری",
    "category": "🧩 دسته ۳: تحلیل، تفکر و برنامه‌نویسی پایه (۱۲ مورد) — ✅ ۱۰/۱۰ عمومی کامل",
    "desc": "سوگیری‌های شناختی در تصمیم‌گیری",
    "initHoursRaw": "30",
    "initHours": 30.0,
    "realHoursRaw": "36",
    "realHours": 36.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8738
    ],
    "sourceRaw": [
      "| 30 | اقتصاد رفتاری | سوگیری‌های شناختی در تصمیم‌گیری | 30 | 36 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 31,
    "name": "کمک‌های اولیه",
    "category": "🏕️ دسته ۴: عملی و بقا (۱۰ مورد) — ✅ همه کامل",
    "desc": "CPR، شکستگی، خونریزی (با گواهی رسمی)",
    "initHoursRaw": "16",
    "initHours": 16.0,
    "realHoursRaw": "19",
    "realHours": 19.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8745
    ],
    "sourceRaw": [
      "| 31 | کمک‌های اولیه | CPR، شکستگی، خونریزی (با گواهی رسمی) | 16 | 19 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 32,
    "name": "کمک‌های اولیه طبیعت",
    "category": "🏕️ دسته ۴: عملی و بقا (۱۰ مورد) — ✅ همه کامل",
    "desc": "مدیریت بحران دور از دسترس پزشکی",
    "initHoursRaw": "40",
    "initHours": 40.0,
    "realHoursRaw": "48",
    "realHours": 48.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8746
    ],
    "sourceRaw": [
      "| 32 | کمک‌های اولیه طبیعت | مدیریت بحران دور از دسترس پزشکی | 40 | 48 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 33,
    "name": "جهت‌یابی نقشه",
    "category": "🏕️ دسته ۴: عملی و بقا (۱۰ مورد) — ✅ همه کامل",
    "desc": "نقشه‌ی توپوگرافی + قطب‌نما",
    "initHoursRaw": "30",
    "initHours": 30.0,
    "realHoursRaw": "36",
    "realHours": 36.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8747
    ],
    "sourceRaw": [
      "| 33 | جهت‌یابی نقشه | نقشه‌ی توپوگرافی + قطب‌نما | 30 | 36 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 34,
    "name": "جهت‌یابی ستارگان",
    "category": "🏕️ دسته ۴: عملی و بقا (۱۰ مورد) — ✅ همه کامل",
    "desc": "ناوبری سماوی شبانه",
    "initHoursRaw": "20",
    "initHours": 20.0,
    "realHoursRaw": "24",
    "realHours": 24.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8748
    ],
    "sourceRaw": [
      "| 34 | جهت‌یابی ستارگان | ناوبری سماوی شبانه | 20 | 24 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 35,
    "name": "ساخت آتش",
    "category": "🏕️ دسته ۴: عملی و بقا (۱۰ مورد) — ✅ همه کامل",
    "desc": "روش‌های اصطکاکی، شیمیایی، عدسی",
    "initHoursRaw": "30",
    "initHours": 30.0,
    "realHoursRaw": "36",
    "realHours": 36.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8749
    ],
    "sourceRaw": [
      "| 35 | ساخت آتش | روش‌های اصطکاکی، شیمیایی، عدسی | 30 | 36 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 36,
    "name": "سرپناه اضطراری",
    "category": "🏕️ دسته ۴: عملی و بقا (۱۰ مورد) — ✅ همه کامل",
    "desc": "Tarp و Debris Shelter",
    "initHoursRaw": "20",
    "initHours": 20.0,
    "realHoursRaw": "24",
    "realHours": 24.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8750
    ],
    "sourceRaw": [
      "| 36 | سرپناه اضطراری | Tarp و Debris Shelter | 20 | 24 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 37,
    "name": "گره‌های کوهنوردی",
    "category": "🏕️ دسته ۴: عملی و بقا (۱۰ مورد) — ✅ همه کامل",
    "desc": "Prusik، هشت، بولاین، کلمهیچ",
    "initHoursRaw": "20",
    "initHours": 20.0,
    "realHoursRaw": "24",
    "realHours": 24.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8751
    ],
    "sourceRaw": [
      "| 37 | گره‌های کوهنوردی | Prusik، هشت، بولاین، کلمهیچ | 20 | 24 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 38,
    "name": "گیاهان خوراکی",
    "category": "🏕️ دسته ۴: عملی و بقا (۱۰ مورد) — ✅ همه کامل",
    "desc": "تشخیص گیاهان وحشی خوراکی از سمی",
    "initHoursRaw": "50",
    "initHours": 50.0,
    "realHoursRaw": "60",
    "realHours": 60.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8752
    ],
    "sourceRaw": [
      "| 38 | گیاهان خوراکی | تشخیص گیاهان وحشی خوراکی از سمی | 50 | 60 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 39,
    "name": "قفل‌بازی",
    "category": "🏕️ دسته ۴: عملی و بقا (۱۰ مورد) — ✅ همه کامل",
    "desc": "باز کردن قفل استوانه‌ای پایه",
    "initHoursRaw": "50",
    "initHours": 50.0,
    "realHoursRaw": "60",
    "realHours": 60.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8753
    ],
    "sourceRaw": [
      "| 39 | قفل‌بازی | باز کردن قفل استوانه‌ای پایه | 50 | 60 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 40,
    "name": "الکترونیک پایه",
    "category": "🏕️ دسته ۴: عملی و بقا (۱۰ مورد) — ✅ همه کامل",
    "desc": "مدار، لحیم‌کاری، پروژه‌ی سنسور ساده",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "73",
    "realHours": 73.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8754
    ],
    "sourceRaw": [
      "| 40 | الکترونیک پایه | مدار، لحیم‌کاری، پروژه‌ی سنسور ساده | 60 | 73 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 41,
    "name": "تعمیرات خودرو",
    "category": "💻 دسته ۵: فنی و دیجیتال (۱۰ مورد) — 🔄 ۴/۱۰",
    "desc": "پنچرگیری، باتری، تعویض روغن",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "118",
    "realHours": 118.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8759
    ],
    "sourceRaw": [
      "| 41 | تعمیرات خودرو | پنچرگیری، باتری، تعویض روغن | 60 | 118 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 42,
    "name": "تعمیر دوچرخه",
    "category": "💻 دسته ۵: فنی و دیجیتال (۱۰ مورد) — 🔄 ۴/۱۰",
    "desc": "پنچری، ترمز، دنده",
    "initHoursRaw": "20",
    "initHours": 20.0,
    "realHoursRaw": "39",
    "realHours": 39.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8760
    ],
    "sourceRaw": [
      "| 42 | تعمیر دوچرخه | پنچری، ترمز، دنده | 20 | 39 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 43,
    "name": "عکاسی با موبایل",
    "category": "💻 دسته ۵: فنی و دیجیتال (۱۰ مورد) — 🔄 ۴/۱۰",
    "desc": "ترکیب‌بندی و نور با گوشی",
    "initHoursRaw": "40",
    "initHours": 40.0,
    "realHoursRaw": "79",
    "realHours": 79.0,
    "sourceStatus": "⏳",
    "sourceLines": [
      8761
    ],
    "sourceRaw": [
      "| 43 | عکاسی با موبایل | ترکیب‌بندی و نور با گوشی | 40 | 79 | ⏳ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 44,
    "name": "تدوین فیلم و سریال",
    "category": "💻 دسته ۵: فنی و دیجیتال (۱۰ مورد) — 🔄 ۴/۱۰",
    "desc": "Premiere/DaVinci — ستون شغل اصلی",
    "initHoursRaw": "100",
    "initHours": 100.0,
    "realHoursRaw": "197",
    "realHours": 197.0,
    "sourceStatus": "✅ (مسیر شغل)",
    "sourceLines": [
      8762
    ],
    "sourceRaw": [
      "| 44 🔧 | تدوین فیلم و سریال | Premiere/DaVinci — ستون شغل اصلی | 100 | 197 | ✅ (مسیر شغل) |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 45,
    "name": "ساخت وب‌سایت",
    "category": "💻 دسته ۵: فنی و دیجیتال (۱۰ مورد) — 🔄 ۴/۱۰",
    "desc": "HTML، CSS، پلتفرم‌های نوساز",
    "initHoursRaw": "80",
    "initHours": 80.0,
    "realHoursRaw": "157",
    "realHours": 157.0,
    "sourceStatus": "✅ (مسیر شغل)",
    "sourceLines": [
      8763
    ],
    "sourceRaw": [
      "| 45 🔧 | ساخت وب‌سایت | HTML، CSS، پلتفرم‌های نوساز | 80 | 157 | ✅ (مسیر شغل) |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 46,
    "name": "امنیت سایبری پایه",
    "category": "💻 دسته ۵: فنی و دیجیتال (۱۰ مورد) — 🔄 ۴/۱۰",
    "desc": "رمز عبور قوی، VPN، محافظت اولیه",
    "initHoursRaw": "30",
    "initHours": 30.0,
    "realHoursRaw": "59",
    "realHours": 59.0,
    "sourceStatus": "✅ (منتقل و تکمیل، مسیر شغل)",
    "sourceLines": [
      8764
    ],
    "sourceRaw": [
      "| 46 🔧 | امنیت سایبری پایه | رمز عبور قوی، VPN، محافظت اولیه | 30 | 59 | ✅ (منتقل و تکمیل، مسیر شغل) |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 47,
    "name": "رادیو آماتور",
    "category": "💻 دسته ۵: فنی و دیجیتال (۱۰ مورد) — 🔄 ۴/۱۰",
    "desc": "ارتباط رادیویی HAM در بحران",
    "initHoursRaw": "40",
    "initHours": 40.0,
    "realHoursRaw": "79",
    "realHours": 79.0,
    "sourceStatus": "⏳",
    "sourceLines": [
      8765
    ],
    "sourceRaw": [
      "| 47 | رادیو آماتور | ارتباط رادیویی HAM در بحران | 40 | 79 | ⏳ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 48,
    "name": "مدل‌سازی سه‌بعدی",
    "category": "💻 دسته ۵: فنی و دیجیتال (۱۰ مورد) — 🔄 ۴/۱۰",
    "desc": "Blender برای انیمیشن و پرینت",
    "initHoursRaw": "80",
    "initHours": 80.0,
    "realHoursRaw": "157",
    "realHours": 157.0,
    "sourceStatus": "✅ (مسیر شغل)",
    "sourceLines": [
      8766
    ],
    "sourceRaw": [
      "| 48 🔧 | مدل‌سازی سه‌بعدی | Blender برای انیمیشن و پرینت | 80 | 157 | ✅ (مسیر شغل) |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 49,
    "name": "کار با چوب/چرم",
    "category": "💻 دسته ۵: فنی و دیجیتال (۱۰ مورد) — 🔄 ۴/۱۰",
    "desc": "ساخت وسایل دست‌ساز کاربردی",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "118",
    "realHours": 118.0,
    "sourceStatus": "⏳",
    "sourceLines": [
      8767
    ],
    "sourceRaw": [
      "| 49 | کار با چوب/چرم | ساخت وسایل دست‌ساز کاربردی | 60 | 118 | ⏳ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 50,
    "name": "تعمیرات خانه",
    "category": "💻 دسته ۵: فنی و دیجیتال (۱۰ مورد) — 🔄 ۴/۱۰",
    "desc": "برق، لوله‌کشی، دیوار ساده",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "118",
    "realHours": 118.0,
    "sourceStatus": "⏳",
    "sourceLines": [
      8768
    ],
    "sourceRaw": [
      "| 50 | تعمیرات خانه | برق، لوله‌کشی، دیوار ساده | 60 | 118 | ⏳ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 51,
    "name": "پیانو",
    "category": "🎨 دسته ۶: هنری و خلاقیت (۱۲ مورد) — ⏳ عمدتاً باقی",
    "desc": "ساز پایه‌ی جهانی، تئوری موسیقی",
    "initHoursRaw": "150",
    "initHours": 150.0,
    "realHoursRaw": "324",
    "realHours": 324.0,
    "sourceStatus": "⏳",
    "sourceLines": [
      8773
    ],
    "sourceRaw": [
      "| 51 | پیانو | ساز پایه‌ی جهانی، تئوری موسیقی | 150 | 324 | ⏳ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 52,
    "name": "نی (فلوت ایرانی)",
    "category": "🎨 دسته ۶: هنری و خلاقیت (۱۲ مورد) — ⏳ عمدتاً باقی",
    "desc": "ساز عرفانی و نادر ایرانی",
    "initHoursRaw": "80",
    "initHours": 80.0,
    "realHoursRaw": "173",
    "realHours": 173.0,
    "sourceStatus": "⏳",
    "sourceLines": [
      8774
    ],
    "sourceRaw": [
      "| 52 | نی (فلوت ایرانی) | ساز عرفانی و نادر ایرانی | 80 | 173 | ⏳ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 53,
    "name": "طراحی پایه",
    "category": "🎨 دسته ۶: هنری و خلاقیت (۱۲ مورد) — ⏳ عمدتاً باقی",
    "desc": "اسکیس و پرسپکتیو سریع",
    "initHoursRaw": "50",
    "initHours": 50.0,
    "realHoursRaw": "108",
    "realHours": 108.0,
    "sourceStatus": "⏳",
    "sourceLines": [
      8775
    ],
    "sourceRaw": [
      "| 53 | طراحی پایه | اسکیس و پرسپکتیو سریع | 50 | 108 | ⏳ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 54,
    "name": "نویسندگی خلاق",
    "category": "🎨 دسته ۶: هنری و خلاقیت (۱۲ مورد) — ⏳ عمدتاً باقی",
    "desc": "داستان‌نویسی و شخصیت‌پردازی",
    "initHoursRaw": "50",
    "initHours": 50.0,
    "realHoursRaw": "108",
    "realHours": 108.0,
    "sourceStatus": "⏳",
    "sourceLines": [
      8776
    ],
    "sourceRaw": [
      "| 54 | نویسندگی خلاق | داستان‌نویسی و شخصیت‌پردازی | 50 | 108 | ⏳ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 55,
    "name": "شعبده‌بازی",
    "category": "🎨 دسته ۶: هنری و خلاقیت (۱۲ مورد) — ⏳ عمدتاً باقی",
    "desc": "ترفندهای کارتی سرگرم‌کننده",
    "initHoursRaw": "40",
    "initHours": 40.0,
    "realHoursRaw": "86",
    "realHours": 86.0,
    "sourceStatus": "⏳",
    "sourceLines": [
      8777
    ],
    "sourceRaw": [
      "| 55 | شعبده‌بازی | ترفندهای کارتی سرگرم‌کننده | 40 | 86 | ⏳ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 56,
    "name": "منتالیسم نمایشی",
    "category": "🎨 دسته ۶: هنری و خلاقیت (۱۲ مورد) — ⏳ عمدتاً باقی",
    "desc": "نمایش ذهن‌خوانی حرفه‌ای",
    "initHoursRaw": "100",
    "initHours": 100.0,
    "realHoursRaw": "216",
    "realHours": 216.0,
    "sourceStatus": "⏳",
    "sourceLines": [
      8778
    ],
    "sourceRaw": [
      "| 56 | منتالیسم نمایشی | نمایش ذهن‌خوانی حرفه‌ای | 100 | 216 | ⏳ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 57,
    "name": "شکم‌گویی",
    "category": "🎨 دسته ۶: هنری و خلاقیت (۱۲ مورد) — ⏳ عمدتاً باقی",
    "desc": "صحبت‌کردن بدون حرکت لب",
    "initHoursRaw": "100",
    "initHours": 100.0,
    "realHoursRaw": "216",
    "realHours": 216.0,
    "sourceStatus": "⏳",
    "sourceLines": [
      8779
    ],
    "sourceRaw": [
      "| 57 | شکم‌گویی | صحبت‌کردن بدون حرکت لب | 100 | 216 | ⏳ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 58,
    "name": "تاروت/کف‌بینی",
    "category": "🎨 دسته ۶: هنری و خلاقیت (۱۲ مورد) — ⏳ عمدتاً باقی",
    "desc": "نمادشناسی و خواندن سرد سرگرمی",
    "initHoursRaw": "30",
    "initHours": 30.0,
    "realHoursRaw": "65",
    "realHours": 65.0,
    "sourceStatus": "⏳",
    "sourceLines": [
      8780
    ],
    "sourceRaw": [
      "| 58 | تاروت/کف‌بینی | نمادشناسی و خواندن سرد سرگرمی | 30 | 65 | ⏳ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 59,
    "name": "فتوشاپ و گرافیک",
    "category": "🎨 دسته ۶: هنری و خلاقیت (۱۲ مورد) — ⏳ عمدتاً باقی",
    "desc": "طراحی دیجیتال، تامبنیل، برندینگ",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "130",
    "realHours": 130.0,
    "sourceStatus": "✅ (مسیر شغل)",
    "sourceLines": [
      8781
    ],
    "sourceRaw": [
      "| 59 🔧 | فتوشاپ و گرافیک | طراحی دیجیتال، تامبنیل، برندینگ | 60 | 130 | ✅ (مسیر شغل) |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 60,
    "name": "تصویرسازی دیجیتال",
    "category": "🎨 دسته ۶: هنری و خلاقیت (۱۲ مورد) — ⏳ عمدتاً باقی",
    "desc": "نقاشی دیجیتال با Photoshop/Procreate",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "130",
    "realHours": 130.0,
    "sourceStatus": "✅ (مسیر شغل)",
    "sourceLines": [
      8782
    ],
    "sourceRaw": [
      "| 60 🔧 | تصویرسازی دیجیتال | نقاشی دیجیتال با Photoshop/Procreate | 60 | 130 | ✅ (مسیر شغل) |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 61,
    "name": "کراو ماگا",
    "category": "🥊 دسته ۷: بدنی و رزمی — اسکلت نهایی MMA",
    "desc": "—",
    "initHoursRaw": "100",
    "initHours": 100.0,
    "realHoursRaw": "178",
    "realHours": 178.0,
    "sourceStatus": "❌",
    "sourceLines": [
      8795
    ],
    "sourceRaw": [
      "| 61 | کراو ماگا | — | 100 | 178 | ❌ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 62,
    "name": "موی تای",
    "category": "🥊 دسته ۷: بدنی و رزمی — اسکلت نهایی MMA",
    "desc": "پایه گرفته شد، ادامه متوقف",
    "initHoursRaw": "150",
    "initHours": 150.0,
    "realHoursRaw": "266",
    "realHours": 266.0,
    "sourceStatus": "⏸️",
    "sourceLines": [
      8793
    ],
    "sourceRaw": [
      "| 62 🥊 | موی تای | پایه گرفته شد، ادامه متوقف | 150 | 266 | ⏸️ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 63,
    "name": "جودو",
    "category": "🥊 دسته ۷: بدنی و رزمی — اسکلت نهایی MMA",
    "desc": "—",
    "initHoursRaw": "150",
    "initHours": 150.0,
    "realHoursRaw": "266",
    "realHours": 266.0,
    "sourceStatus": "❌",
    "sourceLines": [
      8796
    ],
    "sourceRaw": [
      "| 63 | جودو | — | 150 | 266 | ❌ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 64,
    "name": "BJJ",
    "category": "🥊 دسته ۷: بدنی و رزمی — اسکلت نهایی MMA",
    "desc": "پوزیشن، اسکیپ، ساب‌میشن — ستون پایان‌دهنده",
    "initHoursRaw": "150",
    "initHours": 150.0,
    "realHoursRaw": "266",
    "realHours": 266.0,
    "sourceStatus": "🔄",
    "sourceLines": [
      8792
    ],
    "sourceRaw": [
      "| 64 🥊 | BJJ | پوزیشن، اسکیپ، ساب‌میشن — ستون پایان‌دهنده | 150 | 266 | 🔄 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 65,
    "name": "کالیستنیکس",
    "category": "🥊 دسته ۷: بدنی و رزمی — اسکلت نهایی MMA",
    "desc": "تمرین با وزن بدن، ۲ سال پایه‌ی اول",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "107",
    "realHours": 107.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8789
    ],
    "sourceRaw": [
      "| 65 🥊 | کالیستنیکس | تمرین با وزن بدن، ۲ سال پایه‌ی اول | 60 | 107 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 84,
    "name": "مدیریت مالی شخصی",
    "category": "💰 دسته ۹: کارآفرینی و مالی (۱۰ مورد) — ✅ ۸/۱۰",
    "desc": "بودجه و پس‌انداز شخصی",
    "initHoursRaw": "30",
    "initHours": 30.0,
    "realHoursRaw": "40",
    "realHours": 40.0,
    "sourceStatus": "⏳",
    "sourceLines": [
      8808
    ],
    "sourceRaw": [
      "| 84 | مدیریت مالی شخصی | بودجه و پس‌انداز شخصی | 30 | 40 | ⏳ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 85,
    "name": "سرمایه‌گذاری",
    "category": "💰 دسته ۹: کارآفرینی و مالی (۱۰ مورد) — ✅ ۸/۱۰",
    "desc": "سهام، املاک، تنوع‌بخشی",
    "initHoursRaw": "50",
    "initHours": 50.0,
    "realHoursRaw": "67",
    "realHours": 67.0,
    "sourceStatus": "✅ (مسیر شغل)",
    "sourceLines": [
      8809
    ],
    "sourceRaw": [
      "| 85 🔧 | سرمایه‌گذاری | سهام، املاک، تنوع‌بخشی | 50 | 67 | ✅ (مسیر شغل) |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 86,
    "name": "بودجه‌بندی",
    "category": "💰 دسته ۹: کارآفرینی و مالی (۱۰ مورد) — ✅ ۸/۱۰",
    "desc": "برنامه‌ریزی مالی زندگی",
    "initHoursRaw": "20",
    "initHours": 20.0,
    "realHoursRaw": "27",
    "realHours": 27.0,
    "sourceStatus": "⏳",
    "sourceLines": [
      8810
    ],
    "sourceRaw": [
      "| 86 | بودجه‌بندی | برنامه‌ریزی مالی زندگی | 20 | 27 | ⏳ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 87,
    "name": "مذاکره حقوق",
    "category": "💰 دسته ۹: کارآفرینی و مالی (۱۰ مورد) — ✅ ۸/۱۰",
    "desc": "چانه‌زنی شغلی/قراردادی",
    "initHoursRaw": "20",
    "initHours": 20.0,
    "realHoursRaw": "27",
    "realHours": 27.0,
    "sourceStatus": "⏳",
    "sourceLines": [
      8811
    ],
    "sourceRaw": [
      "| 87 | مذاکره حقوق | چانه‌زنی شغلی/قراردادی | 20 | 27 | ⏳ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 88,
    "name": "بازاریابی دیجیتال",
    "category": "💰 دسته ۹: کارآفرینی و مالی (۱۰ مورد) — ✅ ۸/۱۰",
    "desc": "سئو، قیف بازاریابی",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "81",
    "realHours": 81.0,
    "sourceStatus": "✅ (مسیر شغل)",
    "sourceLines": [
      8812
    ],
    "sourceRaw": [
      "| 88 🔧 | بازاریابی دیجیتال | سئو، قیف بازاریابی | 60 | 81 | ✅ (مسیر شغل) |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 89,
    "name": "فروش",
    "category": "💰 دسته ۹: کارآفرینی و مالی (۱۰ مورد) — ✅ ۸/۱۰",
    "desc": "فروش مشاوره‌ای (SPIN)",
    "initHoursRaw": "50",
    "initHours": 50.0,
    "realHoursRaw": "67",
    "realHours": 67.0,
    "sourceStatus": "✅ (مسیر شغل)",
    "sourceLines": [
      8813
    ],
    "sourceRaw": [
      "| 89 🔧 | فروش | فروش مشاوره‌ای (SPIN) | 50 | 67 | ✅ (مسیر شغل) |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 90,
    "name": "تولید محتوا",
    "category": "💰 دسته ۹: کارآفرینی و مالی (۱۰ مورد) — ✅ ۸/۱۰",
    "desc": "تقویم محتوایی، گردش‌کار تولید",
    "initHoursRaw": "50",
    "initHours": 50.0,
    "realHoursRaw": "67",
    "realHours": 67.0,
    "sourceStatus": "✅ (مسیر شغل)",
    "sourceLines": [
      8814
    ],
    "sourceRaw": [
      "| 90 🔧 | تولید محتوا | تقویم محتوایی، گردش‌کار تولید | 50 | 67 | ✅ (مسیر شغل) |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 91,
    "name": "برندسازی شخصی",
    "category": "💰 دسته ۹: کارآفرینی و مالی (۱۰ مورد) — ✅ ۸/۱۰",
    "desc": "هویت بصری و موقعیت‌یابی حرفه‌ای",
    "initHoursRaw": "40",
    "initHours": 40.0,
    "realHoursRaw": "54",
    "realHours": 54.0,
    "sourceStatus": "✅ (مسیر شغل)",
    "sourceLines": [
      8815
    ],
    "sourceRaw": [
      "| 91 🔧 | برندسازی شخصی | هویت بصری و موقعیت‌یابی حرفه‌ای | 40 | 54 | ✅ (مسیر شغل) |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 92,
    "name": "کارآفرینی",
    "category": "💰 دسته ۹: کارآفرینی و مالی (۱۰ مورد) — ✅ ۸/۱۰",
    "desc": "Lean Startup، مدل کسب‌وکار",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "81",
    "realHours": 81.0,
    "sourceStatus": "✅ (مسیر شغل)",
    "sourceLines": [
      8816
    ],
    "sourceRaw": [
      "| 92 🔧 | کارآفرینی | Lean Startup، مدل کسب‌وکار | 60 | 81 | ✅ (مسیر شغل) |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 93,
    "name": "ترید و معامله‌گری",
    "category": "💰 دسته ۹: کارآفرینی و مالی (۱۰ مورد) — ✅ ۸/۱۰",
    "desc": "ارز، فارکس، بازارهای مالی",
    "initHoursRaw": "80",
    "initHours": 80.0,
    "realHoursRaw": "108",
    "realHours": 108.0,
    "sourceStatus": "⏳ (مسیر شغل)",
    "sourceLines": [
      8817
    ],
    "sourceRaw": [
      "| 93 🔧 | ترید و معامله‌گری | ارز، فارکس، بازارهای مالی | 80 | 108 | ⏳ (مسیر شغل) |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 102,
    "name": "مربیگری",
    "category": "🧘 دسته ۱۰: روان‌شناختی و خودرهبری (۱۲ مورد) — ✅ ۱/۱۲",
    "desc": "هدایت و رهبری تیم آینده",
    "initHoursRaw": "50",
    "initHours": 50.0,
    "realHoursRaw": "69",
    "realHours": 69.0,
    "sourceStatus": "✅ (مسیر شغل)",
    "sourceLines": [
      8823
    ],
    "sourceRaw": [
      "| 102 🔧 | مربیگری | هدایت و رهبری تیم آینده | 50 | 69 | ✅ (مسیر شغل) |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 111,
    "name": "تدریس و طراحی آموزشی",
    "category": "🔥 دسته ۱۱: مهارت‌های نادر و خاص (۲۰ مورد) — ✅ ۳/۲۰",
    "desc": "طراحی محتوای آموزشی اثرگذار",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "104",
    "realHours": 104.0,
    "sourceStatus": "⏳",
    "sourceLines": [
      8831
    ],
    "sourceRaw": [
      "| 111 ✏️ | تدریس و طراحی آموزشی | طراحی محتوای آموزشی اثرگذار | 60 | 104 | ⏳ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 120,
    "name": "توسعه هوش مصنوعی",
    "category": "🔥 دسته ۱۱: مهارت‌های نادر و خاص (۲۰ مورد) — ✅ ۳/۲۰",
    "desc": "کاربرد عملی AI در کار و کسب‌وکار",
    "initHoursRaw": "100",
    "initHours": 100.0,
    "realHoursRaw": "173",
    "realHours": 173.0,
    "sourceStatus": "✅ (مسیر شغل)",
    "sourceLines": [
      8832
    ],
    "sourceRaw": [
      "| 120 🔧 | توسعه هوش مصنوعی | کاربرد عملی AI در کار و کسب‌وکار | 100 | 173 | ✅ (مسیر شغل) |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 121,
    "name": "اتوماسیون",
    "category": "🔥 دسته ۱۱: مهارت‌های نادر و خاص (۲۰ مورد) — ✅ ۳/۲۰",
    "desc": "خودکارسازی گردش‌کار پایه",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "104",
    "realHours": 104.0,
    "sourceStatus": "✅ (مسیر شغل)",
    "sourceLines": [
      8833
    ],
    "sourceRaw": [
      "| 121 🔧 | اتوماسیون | خودکارسازی گردش‌کار پایه | 60 | 104 | ✅ (مسیر شغل) |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 122,
    "name": "انیمیشن‌سازی 2D/3D",
    "category": "🔥 دسته ۱۱: مهارت‌های نادر و خاص (۲۰ مورد) — ✅ ۳/۲۰",
    "desc": "موشن گرافیک با After Effects",
    "initHoursRaw": "100",
    "initHours": 100.0,
    "realHoursRaw": "173",
    "realHours": 173.0,
    "sourceStatus": "✅ (مسیر شغل)",
    "sourceLines": [
      8834
    ],
    "sourceRaw": [
      "| 122 🔧 | انیمیشن‌سازی 2D/3D | موشن گرافیک با After Effects | 100 | 173 | ✅ (مسیر شغل) |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 160,
    "name": "شطرنج",
    "category": "🎬 دسته ۱۴: مهارت‌های الهام‌گرفته از انیمه (۲۲ مورد) — ⏳ هنوز شروع نشده",
    "desc": "هدف اصلاح‌شده: ریتینگ ۱۸۰۰ (از ۱۵۲۰ فعلی، روزانه در حال انجام)",
    "initHoursRaw": "~300",
    "initHours": null,
    "realHoursRaw": "~150-200 باقی‌مانده",
    "realHours": null,
    "sourceStatus": "🔄",
    "sourceLines": [
      8850
    ],
    "sourceRaw": [
      "| 160 ✏️ | شطرنج | هدف اصلاح‌شده: ریتینگ ۱۸۰۰ (از ۱۵۲۰ فعلی، روزانه در حال انجام) | ~300 | ~150-200 باقی‌مانده | 🔄 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": true
  },
  {
    "id": 182,
    "name": "UI/UX",
    "category": "🎥 دسته ۱۵: مهارت‌های نهایی و خلاقیت (۱۲ مورد) — ✅ ۹/۱۲",
    "desc": "طراحی رابط و تجربه‌ی کاربری",
    "initHoursRaw": "100",
    "initHours": 100.0,
    "realHoursRaw": "175",
    "realHours": 175.0,
    "sourceStatus": "✅ (مسیر شغل)",
    "sourceLines": [
      8858
    ],
    "sourceRaw": [
      "| 182 🔧 | UI/UX | طراحی رابط و تجربه‌ی کاربری | 100 | 175 | ✅ (مسیر شغل) |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 183,
    "name": "کپی‌رایتینگ",
    "category": "🎥 دسته ۱۵: مهارت‌های نهایی و خلاقیت (۱۲ مورد) — ✅ ۹/۱۲",
    "desc": "متن متقاعدکننده برای فروش",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "105",
    "realHours": 105.0,
    "sourceStatus": "✅ (مسیر شغل)",
    "sourceLines": [
      8859
    ],
    "sourceRaw": [
      "| 183 🔧 | کپی‌رایتینگ | متن متقاعدکننده برای فروش | 60 | 105 | ✅ (مسیر شغل) |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 184,
    "name": "طراحی صدا",
    "category": "🎥 دسته ۱۵: مهارت‌های نهایی و خلاقیت (۱۲ مورد) — ✅ ۹/۱۲",
    "desc": "میکس و افکت صدا",
    "initHoursRaw": "80",
    "initHours": 80.0,
    "realHoursRaw": "140",
    "realHours": 140.0,
    "sourceStatus": "✅ (مسیر شغل)",
    "sourceLines": [
      8860
    ],
    "sourceRaw": [
      "| 184 🔧 | طراحی صدا | میکس و افکت صدا | 80 | 140 | ✅ (مسیر شغل) |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 185,
    "name": "مدیریت محصول",
    "category": "🎥 دسته ۱۵: مهارت‌های نهایی و خلاقیت (۱۲ مورد) — ✅ ۹/۱۲",
    "desc": "از ایده تا محصول نهایی",
    "initHoursRaw": "80",
    "initHours": 80.0,
    "realHoursRaw": "140",
    "realHours": 140.0,
    "sourceStatus": "🔄 ~۴۰٪ (مسیر شغل)",
    "sourceLines": [
      8861
    ],
    "sourceRaw": [
      "| 185 🔧 | مدیریت محصول | از ایده تا محصول نهایی | 80 | 140 | 🔄 ~۴۰٪ (مسیر شغل) |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 186,
    "name": "صداپیشگی و دوبله",
    "category": "🎥 دسته ۱۵: مهارت‌های نهایی و خلاقیت (۱۲ مورد) — ✅ ۹/۱۲",
    "desc": "جان‌بخشیدن به شخصیت با صدا",
    "initHoursRaw": "80",
    "initHours": 80.0,
    "realHoursRaw": "140",
    "realHours": 140.0,
    "sourceStatus": "✅ (مسیر شغل)",
    "sourceLines": [
      8862
    ],
    "sourceRaw": [
      "| 186 🔧 | صداپیشگی و دوبله | جان‌بخشیدن به شخصیت با صدا | 80 | 140 | ✅ (مسیر شغل) |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 187,
    "name": "کارگردانی",
    "category": "🎥 دسته ۱۵: مهارت‌های نهایی و خلاقیت (۱۲ مورد) — ✅ ۹/۱۲",
    "desc": "هدایت هنری یک پروژه",
    "initHoursRaw": "100",
    "initHours": 100.0,
    "realHoursRaw": "175",
    "realHours": 175.0,
    "sourceStatus": "✅ (مسیر شغل)",
    "sourceLines": [
      8863
    ],
    "sourceRaw": [
      "| 187 🔧 | کارگردانی | هدایت هنری یک پروژه | 100 | 175 | ✅ (مسیر شغل) |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 188,
    "name": "عکاسی حرفه‌ای",
    "category": "🎥 دسته ۱۵: مهارت‌های نهایی و خلاقیت (۱۲ مورد) — ✅ ۹/۱۲",
    "desc": "ثبت حرفه‌ای با دوربین واقعی",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "105",
    "realHours": 105.0,
    "sourceStatus": "✅ (مسیر شغل)",
    "sourceLines": [
      8864
    ],
    "sourceRaw": [
      "| 188 🔧 | عکاسی حرفه‌ای | ثبت حرفه‌ای با دوربین واقعی | 60 | 105 | ✅ (مسیر شغل) |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 189,
    "name": "فیلمنامه‌نویسی و استوری‌بورد",
    "category": "🎥 دسته ۱۵: مهارت‌های نهایی و خلاقیت (۱۲ مورد) — ✅ ۹/۱۲",
    "desc": "پایه‌ی هر انیمیشن",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "105",
    "realHours": 105.0,
    "sourceStatus": "⏳",
    "sourceLines": [
      8857
    ],
    "sourceRaw": [
      "| 189 ✏️ | فیلمنامه‌نویسی و استوری‌بورد | پایه‌ی هر انیمیشن | 60 | 105 | ⏳ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 191,
    "name": "خون‌شناسی و سرولوژی قانونی",
    "category": "🩸 دسته ۱۶: دکستر/فارنزیک (۵ مورد) — ✅ ۵/۵ کامل! 🎉",
    "desc": "شناخت خون و آزمایش‌های آن",
    "initHoursRaw": "80",
    "initHours": 80.0,
    "realHoursRaw": "106",
    "realHours": 106.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8871
    ],
    "sourceRaw": [
      "| 191 | خون‌شناسی و سرولوژی قانونی | شناخت خون و آزمایش‌های آن | 80 | 106 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 192,
    "name": "تحلیل الگوی لکه خون (BPA)",
    "category": "🩸 دسته ۱۶: دکستر/فارنزیک (۵ مورد) — ✅ ۵/۵ کامل! 🎉",
    "desc": "بازسازی صحنه از الگوی پاشش",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "79",
    "realHours": 79.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8872
    ],
    "sourceRaw": [
      "| 192 | تحلیل الگوی لکه خون (BPA) | بازسازی صحنه از الگوی پاشش | 60 | 79 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 193,
    "name": "OPSEC و حریم خصوصی",
    "category": "🩸 دسته ۱۶: دکستر/فارنزیک (۵ مورد) — ✅ ۵/۵ کامل! 🎉",
    "desc": "محافظت از داده‌های شخصی/کسب‌وکار",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "79",
    "realHours": 79.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8873
    ],
    "sourceRaw": [
      "| 193 | OPSEC و حریم خصوصی | محافظت از داده‌های شخصی/کسب‌وکار | 60 | 79 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 194,
    "name": "آناتومی هنری",
    "category": "🎨 دسته ۶: هنری و خلاقیت (۱۲ مورد) — ⏳ عمدتاً باقی",
    "desc": "آناتومی بدن برای طراحی دقیق‌تر",
    "initHoursRaw": "90",
    "initHours": 90.0,
    "realHoursRaw": "135",
    "realHours": 135.0,
    "sourceStatus": "⏳",
    "sourceLines": [
      8783
    ],
    "sourceRaw": [
      "| 194 | آناتومی هنری | آناتومی بدن برای طراحی دقیق‌تر | 90 | 135 | ⏳ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 195,
    "name": "سخنرانی عمومی",
    "category": "🗣️ دسته ۲: ارتباط و نفوذ (۱۱ مورد) — ✅ همه کامل",
    "desc": "حضور و فن بیان روی صحنه",
    "initHoursRaw": "55",
    "initHours": 55.0,
    "realHoursRaw": "78",
    "realHours": 78.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8724
    ],
    "sourceRaw": [
      "| 195 | سخنرانی عمومی | حضور و فن بیان روی صحنه | 55 | 78 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 196,
    "name": "مهندسی پرامپت AI",
    "category": "🧩 دسته ۳: تحلیل، تفکر و برنامه‌نویسی پایه (۱۲ مورد) — ✅ ۱۰/۱۰ عمومی کامل",
    "desc": "نوشتن دستور مؤثر برای مدل‌های زبانی",
    "initHoursRaw": "70",
    "initHours": 70.0,
    "realHoursRaw": "85",
    "realHours": 85.0,
    "sourceStatus": "⏳",
    "sourceLines": [
      8739
    ],
    "sourceRaw": [
      "| 196 | مهندسی پرامپت AI | نوشتن دستور مؤثر برای مدل‌های زبانی | 70 | 85 | ⏳ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 197,
    "name": "علم خواب و بیوهک",
    "category": "🧘 دسته ۱۰: روان‌شناختی و خودرهبری (۱۲ مورد) — ✅ ۱/۱۲",
    "desc": "بهینه‌سازی خواب و انرژی",
    "initHoursRaw": "50",
    "initHours": 50.0,
    "realHoursRaw": "69",
    "realHours": 69.0,
    "sourceStatus": "⏳",
    "sourceLines": [
      8824
    ],
    "sourceRaw": [
      "| 197 | علم خواب و بیوهک | بهینه‌سازی خواب و انرژی | 50 | 69 | ⏳ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 198,
    "name": "زیبایی‌شناسی صورت",
    "category": "🎨 دسته ۶: هنری و خلاقیت (۱۲ مورد) — ⏳ عمدتاً باقی",
    "desc": "تناسب و طراحی لبخند (پل به دندانپزشکی)",
    "initHoursRaw": "65",
    "initHours": 65.0,
    "realHoursRaw": "85",
    "realHours": 85.0,
    "sourceStatus": "⏳",
    "sourceLines": [
      8784
    ],
    "sourceRaw": [
      "| 198 | زیبایی‌شناسی صورت | تناسب و طراحی لبخند (پل به دندانپزشکی) | 65 | 85 | ⏳ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 199,
    "name": "CBT کاربردی",
    "category": "🧘 دسته ۱۰: روان‌شناختی و خودرهبری (۱۲ مورد) — ✅ ۱/۱۲",
    "desc": "رفتاردرمانی شناختی روی خود",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "83",
    "realHours": 83.0,
    "sourceStatus": "⏳",
    "sourceLines": [
      8825
    ],
    "sourceRaw": [
      "| 199 | CBT کاربردی | رفتاردرمانی شناختی روی خود | 60 | 83 | ⏳ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 200,
    "name": "تفکر طراحی",
    "category": "🧩 دسته ۳: تحلیل، تفکر و برنامه‌نویسی پایه (۱۲ مورد) — ✅ ۱۰/۱۰ عمومی کامل",
    "desc": "چارچوب حل مسئله‌ی محصول‌محور",
    "initHoursRaw": "30",
    "initHours": 30.0,
    "realHoursRaw": "52",
    "realHours": 52.0,
    "sourceStatus": "⏳",
    "sourceLines": [
      8740
    ],
    "sourceRaw": [
      "| 200 | تفکر طراحی | چارچوب حل مسئله‌ی محصول‌محور | 30 | 52 | ⏳ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 201,
    "name": "اوریگامی",
    "category": "🎨 مهارت‌های اضافه‌ی هنری/سرگرمی",
    "desc": "تا‌کردن کاغذ به اشکال دقیق",
    "initHoursRaw": "30",
    "initHours": 30.0,
    "realHoursRaw": "65",
    "realHours": 65.0,
    "sourceStatus": null,
    "sourceLines": [
      8880
    ],
    "sourceRaw": [
      "| 201 | اوریگامی | تا‌کردن کاغذ به اشکال دقیق | 30 | 65 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 202,
    "name": "ویالون",
    "category": "🎨 مهارت‌های اضافه‌ی هنری/سرگرمی",
    "desc": "ساز زهی کلاسیک",
    "initHoursRaw": "150",
    "initHours": 150.0,
    "realHoursRaw": "324",
    "realHours": 324.0,
    "sourceStatus": null,
    "sourceLines": [
      8881
    ],
    "sourceRaw": [
      "| 202 | ویالون | ساز زهی کلاسیک | 150 | 324 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 204,
    "name": "اتوماسیون پیشرفته n8n",
    "category": "🖥️ دسته ۱۲: کامپیوتر و برنامه‌نویسی پیشرفته (۱۸ مورد) — ✅ ۵/۱۸",
    "desc": "گردش‌کار خودمیزبان",
    "initHoursRaw": "40",
    "initHours": 40.0,
    "realHoursRaw": "63",
    "realHours": 63.0,
    "sourceStatus": "✅ (مسیر شغل)",
    "sourceLines": [
      8840
    ],
    "sourceRaw": [
      "| 204 🔧 | اتوماسیون پیشرفته n8n | گردش‌کار خودمیزبان | 40 | 63 | ✅ (مسیر شغل) |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 205,
    "name": "امنیت سایبری پیشرفته",
    "category": "🖥️ دسته ۱۲: کامپیوتر و برنامه‌نویسی پیشرفته (۱۸ مورد) — ✅ ۵/۱۸",
    "desc": "محافظت از داده‌های کسب‌وکار",
    "initHoursRaw": "80",
    "initHours": 80.0,
    "realHoursRaw": "127",
    "realHours": 127.0,
    "sourceStatus": "✅ (منتقل و تکمیل، مسیر شغل)",
    "sourceLines": [
      8841
    ],
    "sourceRaw": [
      "| 205 🔧 | امنیت سایبری پیشرفته | محافظت از داده‌های کسب‌وکار | 80 | 127 | ✅ (منتقل و تکمیل، مسیر شغل) |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 206,
    "name": "طراحی سایت پیشرفته",
    "category": "🎥 دسته ۱۵: مهارت‌های نهایی و خلاقیت (۱۲ مورد) — ✅ ۹/۱۲",
    "desc": "UI/UX تخصصی‌تر برای وب",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "105",
    "realHours": 105.0,
    "sourceStatus": "✅ (مسیر شغل)",
    "sourceLines": [
      8865
    ],
    "sourceRaw": [
      "| 206 🔧 | طراحی سایت پیشرفته | UI/UX تخصصی‌تر برای وب | 60 | 105 | ✅ (مسیر شغل) |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 207,
    "name": "دوبله‌ی تخصصی",
    "category": "🎥 دسته ۱۵: مهارت‌های نهایی و خلاقیت (۱۲ مورد) — ✅ ۹/۱۲",
    "desc": "صداپیشگی حرفه‌ای‌تر و تخصصی",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "105",
    "realHours": 105.0,
    "sourceStatus": "✅ (مسیر شغل)",
    "sourceLines": [
      8866
    ],
    "sourceRaw": [
      "| 207 🔧 | دوبله‌ی تخصصی | صداپیشگی حرفه‌ای‌تر و تخصصی | 60 | 105 | ✅ (مسیر شغل) |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 208,
    "name": "AI پیشرفته در زندگی/کار",
    "category": "🖥️ دسته ۱۲: کامپیوتر و برنامه‌نویسی پیشرفته (۱۸ مورد) — ✅ ۵/۱۸",
    "desc": "بهره‌وری روزمره با AI",
    "initHoursRaw": "50",
    "initHours": 50.0,
    "realHoursRaw": "79",
    "realHours": 79.0,
    "sourceStatus": "✅ (مسیر شغل)",
    "sourceLines": [
      8842
    ],
    "sourceRaw": [
      "| 208 🔧 | AI پیشرفته در زندگی/کار | بهره‌وری روزمره با AI | 50 | 79 | ✅ (مسیر شغل) |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 209,
    "name": "بوکس",
    "category": "🥊 دسته ۷: بدنی و رزمی — اسکلت نهایی MMA",
    "desc": "استقرار، فوت‌ورک، ۴ ضربه، دفاع — ستون ایستاده",
    "initHoursRaw": "120",
    "initHours": 120.0,
    "realHoursRaw": "213",
    "realHours": 213.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8790
    ],
    "sourceRaw": [
      "| 209 🥊 | بوکس | استقرار، فوت‌ورک، ۴ ضربه، دفاع — ستون ایستاده | 120 | 213 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 210,
    "name": "جیت‌کان‌دو",
    "category": "🥊 دسته ۷: بدنی و رزمی — اسکلت نهایی MMA",
    "desc": "پایه گرفته شد، ادامه متوقف",
    "initHoursRaw": "100",
    "initHours": 100.0,
    "realHoursRaw": "178",
    "realHours": 178.0,
    "sourceStatus": "⏸️",
    "sourceLines": [
      8794
    ],
    "sourceRaw": [
      "| 210 🥊 | جیت‌کان‌دو | پایه گرفته شد، ادامه متوقف | 100 | 178 | ⏸️ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 211,
    "name": "سلاح سرد و گرم",
    "category": "🥊 دسته ۷: بدنی و رزمی — اسکلت نهایی MMA",
    "desc": "دفاع/تیراندازی مجاز",
    "initHoursRaw": "50",
    "initHours": 50.0,
    "realHoursRaw": "89",
    "realHours": 89.0,
    "sourceStatus": "⏳",
    "sourceLines": [
      8797
    ],
    "sourceRaw": [
      "| 211 | سلاح سرد و گرم | دفاع/تیراندازی مجاز | 50 | 89 | ⏳ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 212,
    "name": "مکعب روبیک",
    "category": "🧠 دسته ۱: حافظه و ذهن (۱۱ مورد) — ✅ همه کامل",
    "desc": "حل مکعب با روش CFOP، استفاده از الگوهای حافظه‌ای",
    "initHoursRaw": "30",
    "initHours": 30.0,
    "realHoursRaw": "37",
    "realHours": 37.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8709
    ],
    "sourceRaw": [
      "| 212 | مکعب روبیک | حل مکعب با روش CFOP، استفاده از الگوهای حافظه‌ای | 30 | 37 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 213,
    "name": "شناخت آتش‌زاها",
    "category": "🩸 دسته ۱۶: دکستر/فارنزیک (۵ مورد) — ✅ ۵/۵ کامل! 🎉",
    "desc": "تشخیص علمی محرک و منشأ آتش‌سوزی",
    "initHoursRaw": "100",
    "initHours": 100.0,
    "realHoursRaw": "132",
    "realHours": 132.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8874
    ],
    "sourceRaw": [
      "| 213 | شناخت آتش‌زاها | تشخیص علمی محرک و منشأ آتش‌سوزی | 100 | 132 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 214,
    "name": "پزشکی قانونی",
    "category": "🩸 دسته ۱۶: دکستر/فارنزیک (۵ مورد) — ✅ ۵/۵ کامل! 🎉",
    "desc": "کالبدشکافی، تخمین زمان مرگ، تحلیل آسیب",
    "initHoursRaw": "100",
    "initHours": 100.0,
    "realHoursRaw": "120",
    "realHours": 120.0,
    "sourceStatus": "✅",
    "sourceLines": [
      8875
    ],
    "sourceRaw": [
      "| 214 | پزشکی قانونی | کالبدشکافی، تخمین زمان مرگ، تحلیل آسیب | 100 | 120 | ✅ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 215,
    "name": "کشتی",
    "category": "🥊 دسته ۷: بدنی و رزمی — اسکلت نهایی MMA",
    "desc": "تیک‌داون، کنترل، اسکرمبل — ستون کنترل",
    "initHoursRaw": "100",
    "initHours": 100.0,
    "realHoursRaw": "178",
    "realHours": 178.0,
    "sourceStatus": "🔄",
    "sourceLines": [
      8791
    ],
    "sourceRaw": [
      "| 215 🥊 | کشتی | تیک‌داون، کنترل، اسکرمبل — ستون کنترل | 100 | 178 | 🔄 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 216,
    "name": "ساخت موزیک و آهنگ",
    "category": "🎵 صف انتظار (بعد از تکمیل دسته‌های در حال انجام وارد چرخه می‌شن)",
    "desc": "آهنگسازی و تولید موسیقی با DAW",
    "initHoursRaw": "100",
    "initHours": 100.0,
    "realHoursRaw": "105",
    "realHours": 105.0,
    "sourceStatus": "صف بعد از فناوری",
    "sourceLines": [
      8954
    ],
    "sourceRaw": [
      "| 216 | ساخت موزیک و آهنگ | آهنگسازی و تولید موسیقی با DAW | 100 | 105 | صف بعد از فناوری |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 217,
    "name": "صداسازی",
    "category": "🎵 صف انتظار (بعد از تکمیل دسته‌های در حال انجام وارد چرخه می‌شن)",
    "desc": "سنتز صدا و طراحی افکت صوتی",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "63",
    "realHours": 63.0,
    "sourceStatus": "صف بعد از فناوری",
    "sourceLines": [
      8955
    ],
    "sourceRaw": [
      "| 217 | صداسازی | سنتز صدا و طراحی افکت صوتی | 60 | 63 | صف بعد از فناوری |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 219,
    "name": "حل پازل (ساده تا سخت‌ترین)",
    "category": "🎵 صف انتظار (بعد از تکمیل دسته‌های در حال انجام وارد چرخه می‌شن)",
    "desc": "از پازل منطقی تا معماهای اینترنتی مثل سیکادا",
    "initHoursRaw": "باز",
    "initHours": null,
    "realHoursRaw": "باز",
    "realHours": null,
    "sourceStatus": "**دقیقاً از سن ۲۵ سالگی (ماه ۶۰)**",
    "sourceLines": [
      8956
    ],
    "sourceRaw": [
      "| 219 | حل پازل (ساده تا سخت‌ترین) | از پازل منطقی تا معماهای اینترنتی مثل سیکادا | باز | باز | **دقیقاً از سن ۲۵ سالگی (ماه ۶۰)** |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": true
  },
  {
    "id": 220,
    "name": "OSINT (اطلاعات متن‌باز)",
    "category": "🕵️ دسته ۱۷: اطلاعاتی و ضدجاسوسی (۹ مورد) — همه ⏳",
    "desc": "جمع‌آوری اطلاعات از منابع عمومی/آنلاین",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "90",
    "realHours": 90.0,
    "sourceStatus": null,
    "sourceLines": [
      8888
    ],
    "sourceRaw": [
      "| 220 | OSINT (اطلاعات متن‌باز) | جمع‌آوری اطلاعات از منابع عمومی/آنلاین | 60 | 90 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 221,
    "name": "SIGINT",
    "category": "🕵️ دسته ۱۷: اطلاعاتی و ضدجاسوسی (۹ مورد) — همه ⏳",
    "desc": "اطلاعات سیگنالی/مخابراتی",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "45",
    "realHours": 45.0,
    "sourceStatus": null,
    "sourceLines": [
      8889
    ],
    "sourceRaw": [
      "| 221 | SIGINT | اطلاعات سیگنالی/مخابراتی | 60 | 45 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 222,
    "name": "HUMINT",
    "category": "🕵️ دسته ۱۷: اطلاعاتی و ضدجاسوسی (۹ مورد) — همه ⏳",
    "desc": "اطلاعات انسانی (مصاحبه، منبع‌یابی)",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "36",
    "realHours": 36.0,
    "sourceStatus": null,
    "sourceLines": [
      8890
    ],
    "sourceRaw": [
      "| 222 | HUMINT | اطلاعات انسانی (مصاحبه، منبع‌یابی) | 60 | 36 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 223,
    "name": "GEOINT",
    "category": "🕵️ دسته ۱۷: اطلاعاتی و ضدجاسوسی (۹ مورد) — همه ⏳",
    "desc": "اطلاعات مکانی/جغرافیایی",
    "initHoursRaw": "50",
    "initHours": 50.0,
    "realHoursRaw": "30",
    "realHours": 30.0,
    "sourceStatus": null,
    "sourceLines": [
      8891
    ],
    "sourceRaw": [
      "| 223 | GEOINT | اطلاعات مکانی/جغرافیایی | 50 | 30 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 224,
    "name": "Counter-Intelligence",
    "category": "🕵️ دسته ۱۷: اطلاعاتی و ضدجاسوسی (۹ مورد) — همه ⏳",
    "desc": "ضدجاسوسی",
    "initHoursRaw": "50",
    "initHours": 50.0,
    "realHoursRaw": "30",
    "realHours": 30.0,
    "sourceStatus": null,
    "sourceLines": [
      8892
    ],
    "sourceRaw": [
      "| 224 | Counter-Intelligence | ضدجاسوسی | 50 | 30 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 225,
    "name": "Social Network Analysis",
    "category": "🕵️ دسته ۱۷: اطلاعاتی و ضدجاسوسی (۹ مورد) — همه ⏳",
    "desc": "تحلیل شبکه‌های اجتماعی/روابط",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "40",
    "realHours": 40.0,
    "sourceStatus": null,
    "sourceLines": [
      8893
    ],
    "sourceRaw": [
      "| 225 | Social Network Analysis | تحلیل شبکه‌های اجتماعی/روابط | 60 | 40 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 226,
    "name": "Cryptanalysis",
    "category": "🕵️ دسته ۱۷: اطلاعاتی و ضدجاسوسی (۹ مورد) — همه ⏳",
    "desc": "شکستن رمز",
    "initHoursRaw": "80",
    "initHours": 80.0,
    "realHoursRaw": "66",
    "realHours": 66.0,
    "sourceStatus": null,
    "sourceLines": [
      8894
    ],
    "sourceRaw": [
      "| 226 | Cryptanalysis | شکستن رمز | 80 | 66 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 227,
    "name": "Steganalysis",
    "category": "🕵️ دسته ۱۷: اطلاعاتی و ضدجاسوسی (۹ مورد) — همه ⏳",
    "desc": "کشف پیام‌های مخفی‌شده",
    "initHoursRaw": "40",
    "initHours": 40.0,
    "realHoursRaw": "28",
    "realHours": 28.0,
    "sourceStatus": null,
    "sourceLines": [
      8895
    ],
    "sourceRaw": [
      "| 227 | Steganalysis | کشف پیام‌های مخفی‌شده | 40 | 28 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 228,
    "name": "استگانوگرافی",
    "category": "🕵️ دسته ۱۷: اطلاعاتی و ضدجاسوسی (۹ مورد) — همه ⏳",
    "desc": "مخفی‌کردن اطلاعات در محتوای عادی",
    "initHoursRaw": "30",
    "initHours": 30.0,
    "realHoursRaw": "45",
    "realHours": 45.0,
    "sourceStatus": null,
    "sourceLines": [
      8896
    ],
    "sourceRaw": [
      "| 228 | استگانوگرافی | مخفی‌کردن اطلاعات در محتوای عادی | 30 | 45 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 229,
    "name": "کریپتوگرافی",
    "category": "🔐 دسته ۱۸: رمزنگاری و امنیت پیشرفته (۴ مورد) — همه ⏳",
    "desc": "مبانی رمزنگاری کلاسیک و مدرن",
    "initHoursRaw": "50",
    "initHours": 50.0,
    "realHoursRaw": "79",
    "realHours": 79.0,
    "sourceStatus": null,
    "sourceLines": [
      8901
    ],
    "sourceRaw": [
      "| 229 | کریپتوگرافی | مبانی رمزنگاری کلاسیک و مدرن | 50 | 79 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 230,
    "name": "Quantum Cryptography",
    "category": "🔐 دسته ۱۸: رمزنگاری و امنیت پیشرفته (۴ مورد) — همه ⏳",
    "desc": "رمزنگاری کوانتومی",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "48",
    "realHours": 48.0,
    "sourceStatus": null,
    "sourceLines": [
      8902
    ],
    "sourceRaw": [
      "| 230 | Quantum Cryptography | رمزنگاری کوانتومی | 60 | 48 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 231,
    "name": "Post-Quantum Cryptography",
    "category": "🔐 دسته ۱۸: رمزنگاری و امنیت پیشرفته (۴ مورد) — همه ⏳",
    "desc": "رمزنگاری مقاوم در برابر کوانتوم",
    "initHoursRaw": "50",
    "initHours": 50.0,
    "realHoursRaw": "39",
    "realHours": 39.0,
    "sourceStatus": null,
    "sourceLines": [
      8903
    ],
    "sourceRaw": [
      "| 231 | Post-Quantum Cryptography | رمزنگاری مقاوم در برابر کوانتوم | 50 | 39 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 232,
    "name": "Biometrics",
    "category": "🔐 دسته ۱۸: رمزنگاری و امنیت پیشرفته (۴ مورد) — همه ⏳",
    "desc": "شناسایی زیستی",
    "initHoursRaw": "50",
    "initHours": 50.0,
    "realHoursRaw": "56",
    "realHours": 56.0,
    "sourceStatus": null,
    "sourceLines": [
      8904
    ],
    "sourceRaw": [
      "| 232 | Biometrics | شناسایی زیستی | 50 | 56 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 233,
    "name": "مهندسی معکوس",
    "category": "🛡️ دسته ۱۹: امنیت سایبری تهاجمی/تدافعی پیشرفته (۳ مورد) — همه ⏳",
    "desc": "تحلیل نرم‌افزار/سخت‌افزار بدون سورس",
    "initHoursRaw": "100",
    "initHours": 100.0,
    "realHoursRaw": "120",
    "realHours": 120.0,
    "sourceStatus": null,
    "sourceLines": [
      8909
    ],
    "sourceRaw": [
      "| 233 | مهندسی معکوس | تحلیل نرم‌افزار/سخت‌افزار بدون سورس | 100 | 120 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 234,
    "name": "تحلیل بدافزار",
    "category": "🛡️ دسته ۱۹: امنیت سایبری تهاجمی/تدافعی پیشرفته (۳ مورد) — همه ⏳",
    "desc": "تحلیل رفتار و ساختار ویروس/تروجان",
    "initHoursRaw": "120",
    "initHours": 120.0,
    "realHoursRaw": "126",
    "realHours": 126.0,
    "sourceStatus": null,
    "sourceLines": [
      8910
    ],
    "sourceRaw": [
      "| 234 | تحلیل بدافزار | تحلیل رفتار و ساختار ویروس/تروجان | 120 | 126 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 235,
    "name": "فارنزیک دیجیتال",
    "category": "🛡️ دسته ۱۹: امنیت سایبری تهاجمی/تدافعی پیشرفته (۳ مورد) — همه ⏳",
    "desc": "بازیابی و تحلیل شواهد دیجیتال",
    "initHoursRaw": "120",
    "initHours": 120.0,
    "realHoursRaw": "126",
    "realHours": 126.0,
    "sourceStatus": null,
    "sourceLines": [
      8911
    ],
    "sourceRaw": [
      "| 235 | فارنزیک دیجیتال | بازیابی و تحلیل شواهد دیجیتال | 120 | 126 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 236,
    "name": "تئوری اعداد",
    "category": "🔢 دسته ۲۰: ریاضیات و نظریه‌های پیشرفته (۶ مورد) — همه ⏳",
    "desc": "خواص اعداد صحیح و اول",
    "initHoursRaw": "100",
    "initHours": 100.0,
    "realHoursRaw": "165",
    "realHours": 165.0,
    "sourceStatus": null,
    "sourceLines": [
      8916
    ],
    "sourceRaw": [
      "| 236 | تئوری اعداد | خواص اعداد صحیح و اول | 100 | 165 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 237,
    "name": "نظریه پیچیدگی",
    "category": "🔢 دسته ۲۰: ریاضیات و نظریه‌های پیشرفته (۶ مورد) — همه ⏳",
    "desc": "کلاس‌های پیچیدگی محاسباتی",
    "initHoursRaw": "80",
    "initHours": 80.0,
    "realHoursRaw": "70",
    "realHours": 70.0,
    "sourceStatus": null,
    "sourceLines": [
      8917
    ],
    "sourceRaw": [
      "| 237 | نظریه پیچیدگی | کلاس‌های پیچیدگی محاسباتی | 80 | 70 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 238,
    "name": "نظریه آشوب",
    "category": "🔢 دسته ۲۰: ریاضیات و نظریه‌های پیشرفته (۶ مورد) — همه ⏳",
    "desc": "سیستم‌های دینامیکی حساس",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "45",
    "realHours": 45.0,
    "sourceStatus": null,
    "sourceLines": [
      8918
    ],
    "sourceRaw": [
      "| 238 | نظریه آشوب | سیستم‌های دینامیکی حساس | 60 | 45 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 239,
    "name": "هندسه فراکتال",
    "category": "🔢 دسته ۲۰: ریاضیات و نظریه‌های پیشرفته (۶ مورد) — همه ⏳",
    "desc": "اشکال خودمتشابه ریاضی",
    "initHoursRaw": "40",
    "initHours": 40.0,
    "realHoursRaw": "25",
    "realHours": 25.0,
    "sourceStatus": null,
    "sourceLines": [
      8919
    ],
    "sourceRaw": [
      "| 239 | هندسه فراکتال | اشکال خودمتشابه ریاضی | 40 | 25 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 240,
    "name": "نظریه رسته‌ها",
    "category": "🔢 دسته ۲۰: ریاضیات و نظریه‌های پیشرفته (۶ مورد) — همه ⏳",
    "desc": "زبان انتزاعی ساختارهای ریاضی",
    "initHoursRaw": "100",
    "initHours": 100.0,
    "realHoursRaw": "91",
    "realHours": 91.0,
    "sourceStatus": null,
    "sourceLines": [
      8920
    ],
    "sourceRaw": [
      "| 240 | نظریه رسته‌ها | زبان انتزاعی ساختارهای ریاضی | 100 | 91 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 241,
    "name": "نظریه گراف",
    "category": "🔢 دسته ۲۰: ریاضیات و نظریه‌های پیشرفته (۶ مورد) — همه ⏳",
    "desc": "شبکه‌ها، گره‌ها، مسیرها",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "45",
    "realHours": 45.0,
    "sourceStatus": null,
    "sourceLines": [
      8921
    ],
    "sourceRaw": [
      "| 241 | نظریه گراف | شبکه‌ها، گره‌ها، مسیرها | 60 | 45 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 242,
    "name": "فلسفه ذهن",
    "category": "🧠 دسته ۲۱: فلسفه و زبان‌شناسی (۵ مورد) — همه ⏳",
    "desc": "ماهیت آگاهی و ذهن",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "80",
    "realHours": 80.0,
    "sourceStatus": null,
    "sourceLines": [
      8926
    ],
    "sourceRaw": [
      "| 242 | فلسفه ذهن | ماهیت آگاهی و ذهن | 60 | 80 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 243,
    "name": "معرفت‌شناسی",
    "category": "🧠 دسته ۲۱: فلسفه و زبان‌شناسی (۵ مورد) — همه ⏳",
    "desc": "ماهیت و حدود دانش",
    "initHoursRaw": "50",
    "initHours": 50.0,
    "realHoursRaw": "39",
    "realHours": 39.0,
    "sourceStatus": null,
    "sourceLines": [
      8927
    ],
    "sourceRaw": [
      "| 243 | معرفت‌شناسی | ماهیت و حدود دانش | 50 | 39 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 244,
    "name": "زبان‌شناسی محاسباتی",
    "category": "🧠 دسته ۲۱: فلسفه و زبان‌شناسی (۵ مورد) — همه ⏳",
    "desc": "پردازش زبان طبیعی",
    "initHoursRaw": "80",
    "initHours": 80.0,
    "realHoursRaw": "77",
    "realHours": 77.0,
    "sourceStatus": null,
    "sourceLines": [
      8928
    ],
    "sourceRaw": [
      "| 244 | زبان‌شناسی محاسباتی | پردازش زبان طبیعی | 80 | 77 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 245,
    "name": "زبان‌شناسی قانونی",
    "category": "🧠 دسته ۲۱: فلسفه و زبان‌شناسی (۵ مورد) — همه ⏳",
    "desc": "تحلیل زبانی حقوقی/جنایی",
    "initHoursRaw": "50",
    "initHours": 50.0,
    "realHoursRaw": "42",
    "realHours": 42.0,
    "sourceStatus": null,
    "sourceLines": [
      8929
    ],
    "sourceRaw": [
      "| 245 | زبان‌شناسی قانونی | تحلیل زبانی حقوقی/جنایی | 50 | 42 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 246,
    "name": "نشانه‌شناسی",
    "category": "🧠 دسته ۲۱: فلسفه و زبان‌شناسی (۵ مورد) — همه ⏳",
    "desc": "مطالعه‌ی نمادها و معنا",
    "initHoursRaw": "40",
    "initHours": 40.0,
    "realHoursRaw": "33",
    "realHours": 33.0,
    "sourceStatus": null,
    "sourceLines": [
      8930
    ],
    "sourceRaw": [
      "| 246 | نشانه‌شناسی | مطالعه‌ی نمادها و معنا | 40 | 33 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 247,
    "name": "مدیریت پروژه (PMP)",
    "category": "💼 دسته ۲۲: مدیریت و کسب‌وکار پیشرفته (۵ مورد) — همه ⏳",
    "desc": "استاندارد بین‌المللی مدیریت پروژه",
    "initHoursRaw": "150",
    "initHours": 150.0,
    "realHoursRaw": "180",
    "realHours": 180.0,
    "sourceStatus": null,
    "sourceLines": [
      8935
    ],
    "sourceRaw": [
      "| 247 | مدیریت پروژه (PMP) | استاندارد بین‌المللی مدیریت پروژه | 150 | 180 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 248,
    "name": "مدیریت بحران",
    "category": "💼 دسته ۲۲: مدیریت و کسب‌وکار پیشرفته (۵ مورد) — همه ⏳",
    "desc": "رهبری در شرایط اضطراری کسب‌وکار",
    "initHoursRaw": "40",
    "initHours": 40.0,
    "realHoursRaw": "39",
    "realHours": 39.0,
    "sourceStatus": null,
    "sourceLines": [
      8936
    ],
    "sourceRaw": [
      "| 248 | مدیریت بحران | رهبری در شرایط اضطراری کسب‌وکار | 40 | 39 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 249,
    "name": "ساخت جامعه (Community Building)",
    "category": "💼 دسته ۲۲: مدیریت و کسب‌وکار پیشرفته (۵ مورد) — همه ⏳",
    "desc": "ساخت و رشد یک اجتماع پیرو",
    "initHoursRaw": "40",
    "initHours": 40.0,
    "realHoursRaw": "39",
    "realHours": 39.0,
    "sourceStatus": null,
    "sourceLines": [
      8937
    ],
    "sourceRaw": [
      "| 249 | ساخت جامعه (Community Building) | ساخت و رشد یک اجتماع پیرو | 40 | 39 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 250,
    "name": "هنر فروشندگی پیشرفته",
    "category": "💼 دسته ۲۲: مدیریت و کسب‌وکار پیشرفته (۵ مورد) — همه ⏳",
    "desc": "تکنیک‌های فروش سطح بالا",
    "initHoursRaw": "40",
    "initHours": 40.0,
    "realHoursRaw": "16",
    "realHours": 16.0,
    "sourceStatus": null,
    "sourceLines": [
      8938
    ],
    "sourceRaw": [
      "| 250 | هنر فروشندگی پیشرفته | تکنیک‌های فروش سطح بالا | 40 | 16 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 251,
    "name": "تفکر جانبی (Lateral Thinking)",
    "category": "💼 دسته ۲۲: مدیریت و کسب‌وکار پیشرفته (۵ مورد) — همه ⏳",
    "desc": "حل خلاقانه‌ی غیرمستقیم",
    "initHoursRaw": "20",
    "initHours": 20.0,
    "realHoursRaw": "8",
    "realHours": 8.0,
    "sourceStatus": null,
    "sourceLines": [
      8939
    ],
    "sourceRaw": [
      "| 251 | تفکر جانبی (Lateral Thinking) | حل خلاقانه‌ی غیرمستقیم | 20 | 8 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 252,
    "name": "زبان باستانی لاتین",
    "category": "🎓 مهارت‌های تخصصی بزرگ و مستقل (۶ مورد) — همه ⏳",
    "desc": "خواندن متون کلاسیک",
    "initHoursRaw": "300",
    "initHours": 300.0,
    "realHoursRaw": "300",
    "realHours": 300.0,
    "sourceStatus": null,
    "sourceLines": [
      8944
    ],
    "sourceRaw": [
      "| 252 | زبان باستانی لاتین | خواندن متون کلاسیک | 300 | 300 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 253,
    "name": "نوروساینس کاربردی",
    "category": "🎓 مهارت‌های تخصصی بزرگ و مستقل (۶ مورد) — همه ⏳",
    "desc": "علوم اعصاب کاربردی",
    "initHoursRaw": "150",
    "initHours": 150.0,
    "realHoursRaw": "180",
    "realHours": 180.0,
    "sourceStatus": null,
    "sourceLines": [
      8945
    ],
    "sourceRaw": [
      "| 253 | نوروساینس کاربردی | علوم اعصاب کاربردی | 150 | 180 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 254,
    "name": "زیست‌شناسی مصنوعی",
    "category": "🎓 مهارت‌های تخصصی بزرگ و مستقل (۶ مورد) — همه ⏳",
    "desc": "مهندسی سیستم‌های زیستی",
    "initHoursRaw": "150",
    "initHours": 150.0,
    "realHoursRaw": "153",
    "realHours": 153.0,
    "sourceStatus": null,
    "sourceLines": [
      8946
    ],
    "sourceRaw": [
      "| 254 | زیست‌شناسی مصنوعی | مهندسی سیستم‌های زیستی | 150 | 153 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 255,
    "name": "برنامه‌نویسی رقابتی",
    "category": "🎓 مهارت‌های تخصصی بزرگ و مستقل (۶ مورد) — همه ⏳",
    "desc": "حل مسئله‌ی الگوریتمی سریع",
    "initHoursRaw": "150",
    "initHours": 150.0,
    "realHoursRaw": "170",
    "realHours": 170.0,
    "sourceStatus": null,
    "sourceLines": [
      8947
    ],
    "sourceRaw": [
      "| 255 | برنامه‌نویسی رقابتی | حل مسئله‌ی الگوریتمی سریع | 150 | 170 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 256,
    "name": "نظریه اطلاعات",
    "category": "🎓 مهارت‌های تخصصی بزرگ و مستقل (۶ مورد) — همه ⏳",
    "desc": "آنتروپی شانون، فشرده‌سازی",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "75",
    "realHours": 75.0,
    "sourceStatus": null,
    "sourceLines": [
      8948
    ],
    "sourceRaw": [
      "| 256 | نظریه اطلاعات | آنتروپی شانون، فشرده‌سازی | 60 | 75 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 257,
    "name": "Psychometrics",
    "category": "🎓 مهارت‌های تخصصی بزرگ و مستقل (۶ مورد) — همه ⏳",
    "desc": "اندازه‌گیری روانی/شناختی",
    "initHoursRaw": "60",
    "initHours": 60.0,
    "realHoursRaw": "64",
    "realHours": 64.0,
    "sourceStatus": null,
    "sourceLines": [
      8949
    ],
    "sourceRaw": [
      "| 257 | Psychometrics | اندازه‌گیری روانی/شناختی | 60 | 64 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 258,
    "name": "معماری سیستم و سیستم‌های توزیع‌شده (Systems Design)",
    "category": "💻 دسته ۲۳ (جدید): مسیر «مغز کامپیوتری» — از مکالمه‌ی اخیر، با هرس‌کردن هم‌پوشانی‌ها",
    "desc": "مقیاس‌پذیری، پایگاه‌داده‌ی توزیع‌شده، کش، صف پیام، میکروسرویس",
    "initHoursRaw": "Undefined / Not Specified",
    "initHours": null,
    "realHoursRaw": "200",
    "realHours": 200.0,
    "sourceStatus": "✅ **تکمیل (ماه ۵۳)**",
    "sourceLines": [
      10090
    ],
    "sourceRaw": [
      "| 258 | معماری سیستم و سیستم‌های توزیع‌شده (Systems Design) | مقیاس‌پذیری، پایگاه‌داده‌ی توزیع‌شده، کش، صف پیام، میکروسرویس | 200 | ✅ **تکمیل (ماه ۵۳)** |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 259,
    "name": "CCNA / شبکه",
    "category": "💻 دسته ۲۳ (جدید): مسیر «مغز کامپیوتری» — از مکالمه‌ی اخیر، با هرس‌کردن هم‌پوشانی‌ها",
    "desc": "مبانی شبکه، روتینگ، VLAN، ساب‌نتینگ",
    "initHoursRaw": "Undefined / Not Specified",
    "initHours": null,
    "realHoursRaw": "350",
    "realHours": 350.0,
    "sourceStatus": "🔄 ~۲۳٪",
    "sourceLines": [
      10091
    ],
    "sourceRaw": [
      "| 259 | CCNA / شبکه | مبانی شبکه، روتینگ، VLAN، ساب‌نتینگ | 350 | 🔄 ~۲۳٪ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 260,
    "name": "Ruby",
    "category": "💻 دسته ۲۳ (جدید): مسیر «مغز کامپیوتری» — از مکالمه‌ی اخیر، با هرس‌کردن هم‌پوشانی‌ها",
    "desc": "زبان پویا، شیءگرا",
    "initHoursRaw": "Undefined / Not Specified",
    "initHours": null,
    "realHoursRaw": "200",
    "realHours": 200.0,
    "sourceStatus": "نگه داشته شد به درخواست صریح",
    "sourceLines": [
      10096
    ],
    "sourceRaw": [
      "| 260 | Ruby | زبان پویا، شیءگرا | 200 | نگه داشته شد به درخواست صریح |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 261,
    "name": "Security+ و CEH",
    "category": "💻 دسته ۲۳ (جدید): مسیر «مغز کامپیوتری» — از مکالمه‌ی اخیر، با هرس‌کردن هم‌پوشانی‌ها",
    "desc": "گواهی‌نامه‌ی امنیت پایه و اخلاقی",
    "initHoursRaw": "Undefined / Not Specified",
    "initHours": null,
    "realHoursRaw": "350",
    "realHours": 350.0,
    "sourceStatus": "جایگزین کل خوشه‌ی CEH/CHFI/OSCP/SANS/PWK/Red Team/CTF/SOC/Metasploit",
    "sourceLines": [
      10097
    ],
    "sourceRaw": [
      "| 261 | Security+ و CEH | گواهی‌نامه‌ی امنیت پایه و اخلاقی | 350 | جایگزین کل خوشه‌ی CEH/CHFI/OSCP/SANS/PWK/Red Team/CTF/SOC/Metasploit |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 262,
    "name": "MCSA",
    "category": "💻 دسته ۲۳ (جدید): مسیر «مغز کامپیوتری» — از مکالمه‌ی اخیر، با هرس‌کردن هم‌پوشانی‌ها",
    "desc": "مدیریت سرور ویندوز",
    "initHoursRaw": "Undefined / Not Specified",
    "initHours": null,
    "realHoursRaw": "250",
    "realHours": 250.0,
    "sourceStatus": "جایگزین MCSA/MCSE و MTA",
    "sourceLines": [
      10098
    ],
    "sourceRaw": [
      "| 262 | MCSA | مدیریت سرور ویندوز | 250 | جایگزین MCSA/MCSE و MTA |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 263,
    "name": "A+",
    "category": "💻 دسته ۲۳ (جدید): مسیر «مغز کامپیوتری» — از مکالمه‌ی اخیر، با هرس‌کردن هم‌پوشانی‌ها",
    "desc": "سخت‌افزار و مبانی IT",
    "initHoursRaw": "Undefined / Not Specified",
    "initHours": null,
    "realHoursRaw": "80",
    "realHours": 80.0,
    "sourceStatus": null,
    "sourceLines": [
      10099
    ],
    "sourceRaw": [
      "| 263 | A+ | سخت‌افزار و مبانی IT | 80 | |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 264,
    "name": "LPIC (لینوکس)",
    "category": "💻 دسته ۲۳ (جدید): مسیر «مغز کامپیوتری» — از مکالمه‌ی اخیر، با هرس‌کردن هم‌پوشانی‌ها",
    "desc": "مدیریت سیستم لینوکس، سطح ۱ تا ۳",
    "initHoursRaw": "Undefined / Not Specified",
    "initHours": null,
    "realHoursRaw": "350",
    "realHours": 350.0,
    "sourceStatus": null,
    "sourceLines": [
      10100
    ],
    "sourceRaw": [
      "| 264 | LPIC (لینوکس) | مدیریت سیستم لینوکس، سطح ۱ تا ۳ | 350 | |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 265,
    "name": "DevOps زیرساخت (Docker+Kubernetes/CKA+Ansible+Prometheus+VCP-DCV)",
    "category": "💻 دسته ۲۳ (جدید): مسیر «مغز کامپیوتری» — از مکالمه‌ی اخیر، با هرس‌کردن هم‌پوشانی‌ها",
    "desc": "کانتینر، ارکستراسیون، اتوماسیون زیرساخت",
    "initHoursRaw": "Undefined / Not Specified",
    "initHours": null,
    "realHoursRaw": "400",
    "realHours": 400.0,
    "sourceStatus": "ادغام ۵ مورد مشابه در یک بسته",
    "sourceLines": [
      10101
    ],
    "sourceRaw": [
      "| 265 | DevOps زیرساخت (Docker+Kubernetes/CKA+Ansible+Prometheus+VCP-DCV) | کانتینر، ارکستراسیون، اتوماسیون زیرساخت | 400 | ادغام ۵ مورد مشابه در یک بسته |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 266,
    "name": "React + Next.js",
    "category": "💻 دسته ۲۳ (جدید): مسیر «مغز کامپیوتری» — از مکالمه‌ی اخیر، با هرس‌کردن هم‌پوشانی‌ها",
    "desc": "فریم‌ورک فرانت‌اند مدرن",
    "initHoursRaw": "Undefined / Not Specified",
    "initHours": null,
    "realHoursRaw": "300",
    "realHours": 300.0,
    "sourceStatus": "جایگزین Vue و Angular",
    "sourceLines": [
      10102
    ],
    "sourceRaw": [
      "| 266 | React + Next.js | فریم‌ورک فرانت‌اند مدرن | 300 | جایگزین Vue و Angular |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 267,
    "name": "Django",
    "category": "💻 دسته ۲۳ (جدید): مسیر «مغز کامپیوتری» — از مکالمه‌ی اخیر، با هرس‌کردن هم‌پوشانی‌ها",
    "desc": "فریم‌ورک بک‌اند پایتونی",
    "initHoursRaw": "Undefined / Not Specified",
    "initHours": null,
    "realHoursRaw": "150",
    "realHours": 150.0,
    "sourceStatus": "جایگزین Flask/Laravel/PHP MVC",
    "sourceLines": [
      10103
    ],
    "sourceRaw": [
      "| 267 | Django | فریم‌ورک بک‌اند پایتونی | 150 | جایگزین Flask/Laravel/PHP MVC |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 268,
    "name": "HTML/CSS",
    "category": "💻 دسته ۲۳ (جدید): مسیر «مغز کامپیوتری» — از مکالمه‌ی اخیر، با هرس‌کردن هم‌پوشانی‌ها",
    "desc": "پایه‌ی وب",
    "initHoursRaw": "Undefined / Not Specified",
    "initHours": null,
    "realHoursRaw": "60",
    "realHours": 60.0,
    "sourceStatus": "تخفیف زیاد چون از قبل با ساخت وب‌سایت آشنایی داری",
    "sourceLines": [
      10104
    ],
    "sourceRaw": [
      "| 268 | HTML/CSS | پایه‌ی وب | 60 | تخفیف زیاد چون از قبل با ساخت وب‌سایت آشنایی داری |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 269,
    "name": "SQL",
    "category": "💻 دسته ۲۳ (جدید): مسیر «مغز کامپیوتری» — از مکالمه‌ی اخیر، با هرس‌کردن هم‌پوشانی‌ها",
    "desc": "زبان پایگاه‌داده‌ی رابطه‌ای",
    "initHoursRaw": "Undefined / Not Specified",
    "initHours": null,
    "realHoursRaw": "120",
    "realHours": 120.0,
    "sourceStatus": null,
    "sourceLines": [
      10105
    ],
    "sourceRaw": [
      "| 269 | SQL | زبان پایگاه‌داده‌ی رابطه‌ای | 120 | |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 270,
    "name": "SQL Server",
    "category": "💻 دسته ۲۳ (جدید): مسیر «مغز کامپیوتری» — از مکالمه‌ی اخیر، با هرس‌کردن هم‌پوشانی‌ها",
    "desc": "پایگاه‌داده‌ی مایکروسافتی",
    "initHoursRaw": "Undefined / Not Specified",
    "initHours": null,
    "realHoursRaw": "60",
    "realHours": 60.0,
    "sourceStatus": null,
    "sourceLines": [
      10106
    ],
    "sourceRaw": [
      "| 270 | SQL Server | پایگاه‌داده‌ی مایکروسافتی | 60 | |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 271,
    "name": "Git و GitHub",
    "category": "💻 دسته ۲۳ (جدید): مسیر «مغز کامپیوتری» — از مکالمه‌ی اخیر، با هرس‌کردن هم‌پوشانی‌ها",
    "desc": "کنترل نسخه",
    "initHoursRaw": "Undefined / Not Specified",
    "initHours": null,
    "realHoursRaw": "80",
    "realHours": 80.0,
    "sourceStatus": null,
    "sourceLines": [
      10107
    ],
    "sourceRaw": [
      "| 271 | Git و GitHub | کنترل نسخه | 80 | |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 272,
    "name": "API و REST",
    "category": "💻 دسته ۲۳ (جدید): مسیر «مغز کامپیوتری» — از مکالمه‌ی اخیر، با هرس‌کردن هم‌پوشانی‌ها",
    "desc": "طراحی و مصرف رابط برنامه‌نویسی",
    "initHoursRaw": "Undefined / Not Specified",
    "initHours": null,
    "realHoursRaw": "80",
    "realHours": 80.0,
    "sourceStatus": null,
    "sourceLines": [
      10108
    ],
    "sourceRaw": [
      "| 272 | API و REST | طراحی و مصرف رابط برنامه‌نویسی | 80 | |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 273,
    "name": "Web Hosting",
    "category": "💻 دسته ۲۳ (جدید): مسیر «مغز کامپیوتری» — از مکالمه‌ی اخیر، با هرس‌کردن هم‌پوشانی‌ها",
    "desc": "میزبانی و استقرار وب",
    "initHoursRaw": "Undefined / Not Specified",
    "initHours": null,
    "realHoursRaw": "50",
    "realHours": 50.0,
    "sourceStatus": null,
    "sourceLines": [
      10109
    ],
    "sourceRaw": [
      "| 273 | Web Hosting | میزبانی و استقرار وب | 50 | |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 274,
    "name": "PWA",
    "category": "💻 دسته ۲۳ (جدید): مسیر «مغز کامپیوتری» — از مکالمه‌ی اخیر، با هرس‌کردن هم‌پوشانی‌ها",
    "desc": "اپلیکیشن وب پیشرو",
    "initHoursRaw": "Undefined / Not Specified",
    "initHours": null,
    "realHoursRaw": "60",
    "realHours": 60.0,
    "sourceStatus": null,
    "sourceLines": [
      10110
    ],
    "sourceRaw": [
      "| 274 | PWA | اپلیکیشن وب پیشرو | 60 | |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 275,
    "name": "Web Scraping",
    "category": "💻 دسته ۲۳ (جدید): مسیر «مغز کامپیوتری» — از مکالمه‌ی اخیر، با هرس‌کردن هم‌پوشانی‌ها",
    "desc": "استخراج داده از وب",
    "initHoursRaw": "Undefined / Not Specified",
    "initHours": null,
    "realHoursRaw": "60",
    "realHours": 60.0,
    "sourceStatus": null,
    "sourceLines": [
      10111
    ],
    "sourceRaw": [
      "| 275 | Web Scraping | استخراج داده از وب | 60 | |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 276,
    "name": "PyQt5",
    "category": "💻 دسته ۲۳ (جدید): مسیر «مغز کامپیوتری» — از مکالمه‌ی اخیر، با هرس‌کردن هم‌پوشانی‌ها",
    "desc": "رابط کاربری دسکتاپ با پایتون",
    "initHoursRaw": "Undefined / Not Specified",
    "initHours": null,
    "realHoursRaw": "80",
    "realHours": 80.0,
    "sourceStatus": null,
    "sourceLines": [
      10112
    ],
    "sourceRaw": [
      "| 276 | PyQt5 | رابط کاربری دسکتاپ با پایتون | 80 | |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 277,
    "name": "C",
    "category": "💻 دسته ۲۳ (جدید): مسیر «مغز کامپیوتری» — از مکالمه‌ی اخیر، با هرس‌کردن هم‌پوشانی‌ها",
    "desc": "زبان پایه‌ی سیستمی",
    "initHoursRaw": "Undefined / Not Specified",
    "initHours": null,
    "realHoursRaw": "60",
    "realHours": 60.0,
    "sourceStatus": null,
    "sourceLines": [
      10113
    ],
    "sourceRaw": [
      "| 277 | C | زبان پایه‌ی سیستمی | 60 | |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 278,
    "name": "Rust",
    "category": "💻 دسته ۲۳ (جدید): مسیر «مغز کامپیوتری» — از مکالمه‌ی اخیر، با هرس‌کردن هم‌پوشانی‌ها",
    "desc": "زبان سیستمی مدرن و ایمن",
    "initHoursRaw": "Undefined / Not Specified",
    "initHours": null,
    "realHoursRaw": "200",
    "realHours": 200.0,
    "sourceStatus": null,
    "sourceLines": [
      10114
    ],
    "sourceRaw": [
      "| 278 | Rust | زبان سیستمی مدرن و ایمن | 200 | |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 279,
    "name": "Go",
    "category": "💻 دسته ۲۳ (جدید): مسیر «مغز کامپیوتری» — از مکالمه‌ی اخیر، با هرس‌کردن هم‌پوشانی‌ها",
    "desc": "زبان سیستمی سریع گوگل",
    "initHoursRaw": "Undefined / Not Specified",
    "initHours": null,
    "realHoursRaw": "150",
    "realHours": 150.0,
    "sourceStatus": null,
    "sourceLines": [
      10115
    ],
    "sourceRaw": [
      "| 279 | Go | زبان سیستمی سریع گوگل | 150 | |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 280,
    "name": "Swift / SwiftUI",
    "category": "💻 دسته ۲۳ (جدید): مسیر «مغز کامپیوتری» — از مکالمه‌ی اخیر، با هرس‌کردن هم‌پوشانی‌ها",
    "desc": "توسعه‌ی iOS",
    "initHoursRaw": "Undefined / Not Specified",
    "initHours": null,
    "realHoursRaw": "180",
    "realHours": 180.0,
    "sourceStatus": null,
    "sourceLines": [
      10116
    ],
    "sourceRaw": [
      "| 280 | Swift / SwiftUI | توسعه‌ی iOS | 180 | |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 281,
    "name": "Flutter + Dart",
    "category": "💻 دسته ۲۳ (جدید): مسیر «مغز کامپیوتری» — از مکالمه‌ی اخیر، با هرس‌کردن هم‌پوشانی‌ها",
    "desc": "توسعه‌ی موبایل چندسکویی",
    "initHoursRaw": "Undefined / Not Specified",
    "initHours": null,
    "realHoursRaw": "230",
    "realHours": 230.0,
    "sourceStatus": "ادغام Flutter و Dart",
    "sourceLines": [
      10117
    ],
    "sourceRaw": [
      "| 281 | Flutter + Dart | توسعه‌ی موبایل چندسکویی | 230 | ادغام Flutter و Dart |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 282,
    "name": "AR/VR",
    "category": "💻 دسته ۲۳ (جدید): مسیر «مغز کامپیوتری» — از مکالمه‌ی اخیر، با هرس‌کردن هم‌پوشانی‌ها",
    "desc": "واقعیت افزوده/مجازی",
    "initHoursRaw": "Undefined / Not Specified",
    "initHours": null,
    "realHoursRaw": "250",
    "realHours": 250.0,
    "sourceStatus": "هم‌پوشانی با توسعه‌ی بازی (#۱۳۱)",
    "sourceLines": [
      10118
    ],
    "sourceRaw": [
      "| 282 | AR/VR | واقعیت افزوده/مجازی | 250 | هم‌پوشانی با توسعه‌ی بازی (#۱۳۱) |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 283,
    "name": "بلاک‌چین پیشرفته (Solidity+NFT/DApp)",
    "category": "💻 دسته ۲۳ (جدید): مسیر «مغز کامپیوتری» — از مکالمه‌ی اخیر، با هرس‌کردن هم‌پوشانی‌ها",
    "desc": "قرارداد هوشمند و اپلیکیشن غیرمتمرکز",
    "initHoursRaw": "Undefined / Not Specified",
    "initHours": null,
    "realHoursRaw": "250",
    "realHours": 250.0,
    "sourceStatus": "تکمیلی به #۱۳۰",
    "sourceLines": [
      10119
    ],
    "sourceRaw": [
      "| 283 | بلاک‌چین پیشرفته (Solidity+NFT/DApp) | قرارداد هوشمند و اپلیکیشن غیرمتمرکز | 250 | تکمیلی به #۱۳۰ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 284,
    "name": "طراحی لوگو/لوگوتایپ",
    "category": "💻 دسته ۲۳ (جدید): مسیر «مغز کامپیوتری» — از مکالمه‌ی اخیر، با هرس‌کردن هم‌پوشانی‌ها",
    "desc": "هویت بصری برند",
    "initHoursRaw": "Undefined / Not Specified",
    "initHours": null,
    "realHoursRaw": "60",
    "realHours": 60.0,
    "sourceStatus": "تخفیف چون فتوشاپ/گرافیک بلدی",
    "sourceLines": [
      10120
    ],
    "sourceRaw": [
      "| 284 | طراحی لوگو/لوگوتایپ | هویت بصری برند | 60 | تخفیف چون فتوشاپ/گرافیک بلدی |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 285,
    "name": "ادیت صدا (Audacity/Logic Pro)",
    "category": "💻 دسته ۲۳ (جدید): مسیر «مغز کامپیوتری» — از مکالمه‌ی اخیر، با هرس‌کردن هم‌پوشانی‌ها",
    "desc": "ادیت و میکس حرفه‌ای صدا",
    "initHoursRaw": "Undefined / Not Specified",
    "initHours": null,
    "realHoursRaw": "40",
    "realHours": 40.0,
    "sourceStatus": "تخفیف چون طراحی صدا بلدی",
    "sourceLines": [
      10121
    ],
    "sourceRaw": [
      "| 285 | ادیت صدا (Audacity/Logic Pro) | ادیت و میکس حرفه‌ای صدا | 40 | تخفیف چون طراحی صدا بلدی |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": 286,
    "name": "نرم‌افزارهای اداری (PowerPoint/Slides/Word)",
    "category": "💻 دسته ۲۳ (جدید): مسیر «مغز کامپیوتری» — از مکالمه‌ی اخیر، با هرس‌کردن هم‌پوشانی‌ها",
    "desc": "ارائه و مستندسازی حرفه‌ای",
    "initHoursRaw": "Undefined / Not Specified",
    "initHours": null,
    "realHoursRaw": "60",
    "realHours": 60.0,
    "sourceStatus": null,
    "sourceLines": [
      10122
    ],
    "sourceRaw": [
      "| 286 | نرم‌افزارهای اداری (PowerPoint/Slides/Word) | ارائه و مستندسازی حرفه‌ای | 60 | |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": "104-110,112-119,123",
    "name": "کد مورس تا مدیریت لینوکس (متفرقه)",
    "category": "🔥 دسته ۱۱: مهارت‌های نادر و خاص (۲۰ مورد) — ✅ ۳/۲۰",
    "desc": "مطابق تعاریف قبلی",
    "initHoursRaw": "~600",
    "initHours": null,
    "realHoursRaw": "~1030",
    "realHours": null,
    "sourceStatus": "⏳",
    "sourceLines": [
      8830
    ],
    "sourceRaw": [
      "| 104-110,112-119,123 | کد مورس تا مدیریت لینوکس (متفرقه) | مطابق تعاریف قبلی | ~600 | ~1030 | ⏳ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": true
  },
  {
    "id": "124-138",
    "name": "ICDL تا علم داده (متفرقه)",
    "category": "🖥️ دسته ۱۲: کامپیوتر و برنامه‌نویسی پیشرفته (۱۸ مورد) — ✅ ۵/۱۸",
    "desc": "مطابق تعاریف قبلی",
    "initHoursRaw": "~1110",
    "initHours": null,
    "realHoursRaw": "~1748",
    "realHours": null,
    "sourceStatus": "⏳",
    "sourceLines": [
      8839
    ],
    "sourceRaw": [
      "| 124-138 | ICDL تا علم داده (متفرقه) | مطابق تعاریف قبلی | ~1110 | ~1748 | ⏳ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": true
  },
  {
    "id": "139-158",
    "name": "علوم پایه و مهندسی — بسته ۲۰ موردی",
    "category": "🔬 دسته ۱۳: علوم پایه و مهندسی (۲۰ مورد) — ⏳ هنوز شروع نشده (هم‌پوشانی طبیعی با دندانپزشکی)",
    "desc": "مجموع ۲۰ مورد (فیزیک تا تولید غذا): ساعت اولیه ~۳۴۳۰، ساعت واقعی ~۳۵۲۹ (هم‌پوشانی طبیعی با پایه‌ی دندانپزشکی)",
    "initHoursRaw": "~۳۴۳۰",
    "initHours": null,
    "realHoursRaw": "~۳۵۲۹",
    "realHours": null,
    "sourceStatus": "⏳ هنوز شروع نشده (هم‌پوشانی طبیعی با دندانپزشکی)",
    "sourceLines": [
      8845
    ],
    "sourceRaw": [
      "مجموع ۲۰ مورد (فیزیک تا تولید غذا): ساعت اولیه ~۳۴۳۰، ساعت واقعی ~۳۵۲۹ (هم‌پوشانی طبیعی با پایه‌ی دندانپزشکی)"
    ],
    "sourceFile": "eeje.txt",
    "undefined": true
  },
  {
    "id": "159, 161-180",
    "name": "استدلال استنتاجی تا روایت جایگزین (بقیه‌ی ۲۱ مورد)",
    "category": "🎬 دسته ۱۴: مهارت‌های الهام‌گرفته از انیمه (۲۲ مورد) — ⏳ هنوز شروع نشده",
    "desc": "مطابق تعاریف قبلی",
    "initHoursRaw": "~3620",
    "initHours": null,
    "realHoursRaw": "~7110",
    "realHours": null,
    "sourceStatus": "⏳",
    "sourceLines": [
      8851
    ],
    "sourceRaw": [
      "| 159, 161-180 | استدلال استنتاجی تا روایت جایگزین (بقیه‌ی ۲۱ مورد) | مطابق تعاریف قبلی | ~3620 | ~7110 | ⏳ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": true
  },
  {
    "id": "181, 190",
    "name": "آشپزی حرفه‌ای، فلسفه عملی",
    "category": "🎥 دسته ۱۵: مهارت‌های نهایی و خلاقیت (۱۲ مورد) — ✅ ۹/۱۲",
    "desc": "مطابق تعاریف قبلی",
    "initHoursRaw": "110",
    "initHours": 110.0,
    "realHoursRaw": "192",
    "realHours": 192.0,
    "sourceStatus": "⏳",
    "sourceLines": [
      8856
    ],
    "sourceRaw": [
      "| 181, 190 | آشپزی حرفه‌ای، فلسفه عملی | مطابق تعاریف قبلی | 110 | 192 | ⏳ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": "66-73,72",
    "name": "پارکور، شنا، دو استقامت، تیراندازی کمان، صخره‌نوردی، اسکیت، فری‌رانینگ، گیتار/سه‌تار",
    "category": "🥊 دسته ۷: بدنی و رزمی — اسکلت نهایی MMA",
    "desc": "متفرقه، هنوز شروع نشده",
    "initHoursRaw": "~490 (جمع)",
    "initHours": null,
    "realHoursRaw": "~873 (جمع)",
    "realHours": null,
    "sourceStatus": "⏳",
    "sourceLines": [
      8798
    ],
    "sourceRaw": [
      "| 66-73,72 | پارکور، شنا، دو استقامت، تیراندازی کمان، صخره‌نوردی، اسکیت، فری‌رانینگ، گیتار/سه‌تار | متفرقه، هنوز شروع نشده | ~490 (جمع) | ~873 (جمع) | ⏳ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": true
  },
  {
    "id": "74-83, 203",
    "name": "انگلیسی، فرانسه، روسی، اسپانیایی، عربی، آلمانی، چینی، ترکی، زبان اشاره، الفبای ناتو، آشنایی بین‌فرهنگی",
    "category": "🌍 دسته ۸: زبان و فرهنگ (۱۱ مورد) — ⏳ هنوز شروع نشده",
    "desc": "مطابق سطح‌های تعیین‌شده‌ی قبلی",
    "initHoursRaw": "2420",
    "initHours": 2420.0,
    "realHoursRaw": "2420",
    "realHours": 2420.0,
    "sourceStatus": null,
    "sourceLines": [
      8803
    ],
    "sourceRaw": [
      "| 74-83, 203 | انگلیسی، فرانسه، روسی، اسپانیایی، عربی، آلمانی، چینی، ترکی، زبان اشاره، الفبای ناتو، آشنایی بین‌فرهنگی | مطابق سطح‌های تعیین‌شده‌ی قبلی | 2420 | 2420 |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  },
  {
    "id": "94-101,103",
    "name": "خودآگاهی، مدیریت استرس، تاب‌آوری، حل تعارض، همدلی، مرزگذاری، خودهیپنوتیزم، روان‌شناسی فریب، فلسفه رواقی",
    "category": "🧘 دسته ۱۰: روان‌شناختی و خودرهبری (۱۲ مورد) — ✅ ۱/۱۲",
    "desc": "مطابق تعاریف قبلی",
    "initHoursRaw": "320",
    "initHours": 320.0,
    "realHoursRaw": "445",
    "realHours": 445.0,
    "sourceStatus": "⏳",
    "sourceLines": [
      8822
    ],
    "sourceRaw": [
      "| 94-101,103 | خودآگاهی، مدیریت استرس، تاب‌آوری، حل تعارض، همدلی، مرزگذاری، خودهیپنوتیزم، روان‌شناسی فریب، فلسفه رواقی | مطابق تعاریف قبلی | 320 | 445 | ⏳ |"
    ],
    "sourceFile": "eeje.txt",
    "undefined": false
  }
] as const

export type MasterSkill = typeof MASTER_SKILLS[number]

/** Numeric IDs represented by the source, including IDs covered by preserved range/bundle entries. */
export const MASTER_SOURCE_IDS = MASTER_SKILLS.flatMap((skill) => {
  if (typeof skill.id === 'number') return [skill.id]
  const values: number[] = []
  for (const token of skill.id.split(',')) {
    const clean = token.trim()
    if (/^\d+$/.test(clean)) values.push(Number(clean))
    else {
      const m = clean.match(/^(\d+)\s*-\s*(\d+)$/)
      if (m) for (let n = Number(m[1]); n <= Number(m[2]); n += 1) values.push(n)
    }
  }
  return values
})
export const MASTER_SOURCE_ID_SET = new Set(MASTER_SOURCE_IDS)
export const MASTER_SOURCE_COVERAGE_COUNT = MASTER_SOURCE_ID_SET.size
export const MASTER_MISSING_IDS = Object.freeze(Array.from({ length: 286 }, (_, i) => i + 1).filter((id) => !MASTER_SOURCE_ID_SET.has(id)))
export const MASTER_SKILL_COUNT = MASTER_SKILLS.length
export const MASTER_BUNDLE_COUNT = MASTER_SKILLS.filter((s) => typeof s.id === 'string').length
export const MASTER_NUMERIC_REAL_HOURS = MASTER_SKILLS.reduce((sum, s) => sum + (typeof s.realHours === 'number' ? s.realHours : 0), 0)
export const MASTER_NUMERIC_INITIAL_HOURS = MASTER_SKILLS.reduce((sum, s) => sum + (typeof s.initHours === 'number' ? s.initHours : 0), 0)
