export function MiniLineChart({ values, labels=[] }: { values:number[]; labels?:string[] }){
  if(!values.length) return <div className="chart-empty">No session data yet.</div>
  const max=Math.max(...values,1), min=Math.min(...values,0), w=700,h=230,p=20, dx=(w-p*2)/Math.max(values.length-1,1)
  const pts=values.map((v,i)=>`${p+i*dx},${h-p-20-((v-min)/(max-min||1))*150}`).join(' ')
  return <div className="chart"><svg className="svg-chart" viewBox={`0 0 ${w} ${h}`} role="img" aria-label="Line chart"><polyline points={pts} fill="none" stroke="var(--accent)" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>{values.map((v,i)=>{const [x,y]=pts.split(' ')[i].split(',');return <circle key={i} cx={x} cy={y} r="3.5" fill="var(--accent)"/>})}{labels.map((l,i)=>i%Math.max(1,Math.floor(labels.length/6))===0?<text key={i} x={p+i*dx} y={h-3} fill="var(--faint)" fontSize="9" textAnchor="middle">{l}</text>:null)}</svg></div>
}
export function SimpleBars({ data }: { data:{label:string;value:number}[] }){
  if(!data.length||data.every(x=>x.value===0)) return <div className="chart-empty">No logged hours yet.</div>
  const max=Math.max(...data.map(x=>x.value),1)
  return <div style={{display:'grid',gap:10,padding:'6px 0'}}>{data.map(x=><div key={x.label}><div style={{display:'flex',justifyContent:'space-between',fontSize:10,color:'var(--muted)',marginBottom:4}}><span>{x.label}</span><span className="mono">{x.value.toFixed(1)}h</span></div><div className="progress-track"><div className="progress-fill blue" style={{width:`${(x.value/max)*100}%`}}/></div></div>)}</div>
}
export function Donut({ segments }: { segments:{label:string;value:number}[] }){
  const total=segments.reduce((s,x)=>s+x.value,0)
  if(!total) return <div className="chart-empty">No distribution data yet.</div>
  let cursor=0; const r=62,c=80,circ=2*Math.PI*r
  return <div className="chart"><svg viewBox="0 0 160 160" width="180" role="img" aria-label="Distribution donut"><circle cx="80" cy="80" r={r} fill="none" stroke="var(--surface3)" strokeWidth="22"/>{segments.map((s,i)=>{const dash=(s.value/total)*circ;const offset=-cursor;cursor+=dash;return <circle key={s.label} cx="80" cy="80" r={r} fill="none" stroke={i===0?'var(--accent)':i===1?'var(--blue)':i===2?'var(--purple)':'var(--amber)'} strokeWidth="22" strokeDasharray={`${dash} ${circ-dash}`} strokeDashoffset={offset} transform="rotate(-90 80 80)"/>})}<text x="80" y="76" textAnchor="middle" fill="var(--text)" fontSize="16" fontWeight="800">{total.toFixed(1)}h</text><text x="80" y="92" textAnchor="middle" fill="var(--faint)" fontSize="8">logged</text></svg></div>
}
