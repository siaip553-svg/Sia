import { MASTER_SKILLS } from '../data/masterSkills'
import type { PersonalSkill, SkillId } from '../domain/types'

export function SkillSelect({ value, onChange, includeEmpty=true, personalSkills=[] }: { value:SkillId|''; onChange:(v:SkillId)=>void; includeEmpty?:boolean; personalSkills?:PersonalSkill[] }){
  return <select className="select" value={String(value)} onChange={e=>onChange(e.target.value)}><>{includeEmpty&&<option value="">Select skill…</option>}</><optgroup label="Master Checklist">{MASTER_SKILLS.map(s=><option key={s.id} value={s.id}>{s.id} · {s.name}</option>)}</optgroup>{personalSkills.length>0&&<optgroup label="Personal Skills">{personalSkills.filter(x=>!x.archived).map(s=><option key={s.id} value={s.id}>{s.name}</option>)}</optgroup>}</select>
}
