import { useEffect, useRef, useState } from 'react'
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom'
import { BarChart3, CalendarDays, Command, Crosshair, Database, FolderKanban, Gauge, Menu, Moon, Network, Settings, Sun, Target, Wrench, BriefcaseBusiness, Search, X } from 'lucide-react'
import { useApp } from '../store/AppStore'
import { MASTER_SKILLS } from '../data/masterSkills'
import { Button } from './ui'

const items = [
  {to:'/',label:'Command Center',icon:Gauge},
  {to:'/skills',label:'Skills',icon:Database},
  {to:'/roadmap',label:'Roadmap',icon:Network},
  {to:'/focus',label:'Focus',icon:Crosshair},
  {to:'/planner',label:'Planner',icon:CalendarDays},
  {to:'/progress',label:'Progress',icon:BarChart3},
  {to:'/projects',label:'Projects',icon:FolderKanban},
  {to:'/career',label:'Career',icon:BriefcaseBusiness},
  {to:'/maintenance',label:'Maintenance',icon:Wrench},
  {to:'/analytics',label:'Analytics',icon:BarChart3},
  {to:'/settings',label:'Settings',icon:Settings},
]

function CommandPalette({ onClose }: { onClose:()=>void }) {
  const navigate=useNavigate(); const inputRef=useRef<HTMLInputElement>(null); const [q,setQ]=useState('');
  const [cursor,setCursor]=useState(0)
  const actions=[
    {label:'Global Search',hint:'Search',path:'/search'},
    {label:'Open Skills',hint:'Skills',path:'/skills'},
    {label:'Start Focus',hint:'Focus',path:'/focus'},
    {label:'Log Session',hint:'Planner',path:'/planner?action=session'},
    {label:'Create Project',hint:'Projects',path:'/projects?action=create'},
    {label:'Open Analytics',hint:'Analytics',path:'/analytics'},
    {label:'Open Roadmap',hint:'Roadmap',path:'/roadmap'},
    {label:'Open Maintenance',hint:'Maintenance',path:'/maintenance'},
    ...MASTER_SKILLS.slice(0,40).map(s=>({label:`${s.id} · ${s.name}`,hint:s.category,path:`/skills?skill=${s.id}`})),
  ].filter(a=>a.label.toLowerCase().includes(q.toLowerCase())||a.hint.toLowerCase().includes(q.toLowerCase())).slice(0,12)
  useEffect(()=>{ inputRef.current?.focus() },[])
  useEffect(()=>{setCursor(0)},[q])
  const choose=(path:string)=>{onClose();navigate(path)}
  return <div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)onClose()}}>
    <div className="modal command" role="dialog" aria-modal="true" aria-label="Command palette">
      <div className="global-search"><Search size={17}/><input ref={inputRef} value={q} onChange={e=>setQ(e.target.value)} onKeyDown={e=>{if(e.key==='ArrowDown'){e.preventDefault();setCursor(i=>Math.min(actions.length-1,i+1))}else if(e.key==='ArrowUp'){e.preventDefault();setCursor(i=>Math.max(0,i-1))}else if(e.key==='Enter'&&actions[cursor])choose(actions[cursor].path);else if(e.key==='Escape')onClose()}} placeholder="Search command, skill, section…"/><span className="kbd">Ctrl K</span></div>
      <div className="command-list">{actions.map((a,i)=><button key={a.path+a.label} className={`command-item ${i===cursor?'active':''}`} onMouseEnter={()=>setCursor(i)} onClick={()=>choose(a.path)}><span>{a.label}</span><span className="badge">{a.hint}</span></button>)}</div>
      {!actions.length&&<div className="empty" style={{marginTop:10}}><div><strong>No commands</strong><p>Try a skill name, ID, or section.</p></div></div>}
    </div>
  </div>
}

export default function Layout(){
  const {data,setPreferences,saving,error}=useApp(); const navigate=useNavigate(); const location=useLocation(); const [palette,setPalette]=useState(false); const [mobileOpen,setMobileOpen]=useState(false); const [search,setSearch]=useState('')
  useEffect(()=>{const onKey=(e:KeyboardEvent)=>{if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k'){e.preventDefault();setPalette(true);return} if(!data.preferences.shortcutsEnabled||e.metaKey||e.ctrlKey||e.altKey) return; const tag=(e.target as HTMLElement)?.tagName; if(['INPUT','TEXTAREA','SELECT'].includes(tag)) return; const key=e.key.toLowerCase(); if(key==='/'){e.preventDefault();document.getElementById('global-search')?.focus()} if(key==='f')navigate('/focus'); if(key==='n')navigate('/planner?action=session'); if(key==='p')navigate('/planner'); if(key==='s')navigate('/skills'); if(key==='g')navigate('/planner?tab=goals')}; window.addEventListener('keydown',onKey);return()=>window.removeEventListener('keydown',onKey)},[data.preferences.shortcutsEnabled,navigate])
  useEffect(()=>{const timer=window.setTimeout(()=>{if(search.trim())navigate(`/search?q=${encodeURIComponent(search.trim())}`)},300);return()=>window.clearTimeout(timer)},[search,navigate])
  useEffect(()=>{document.documentElement.dataset.theme=data.preferences.theme;document.documentElement.dataset.accent=data.preferences.accent},[data.preferences.theme,data.preferences.accent])
  const mainNav=items.slice(0,6); const moreNav=items.slice(6)
  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark">S</div><div><h1>SIA SKILL OS</h1><small>Personal Skill Operating System</small></div></div>
      <nav className="nav" aria-label="Primary navigation">
        {mainNav.map(x=><NavLink key={x.to} to={x.to} end={x.to==='/' }>{<x.icon size={17}/>}<span>{x.label}</span></NavLink>)}
        <div style={{height:1,background:'var(--line2)',margin:'7px 3px'}} />
        {moreNav.map(x=><NavLink key={x.to} to={x.to}>{<x.icon size={17}/>}<span>{x.label}</span></NavLink>)}
      </nav>
      <div className="sidebar-foot"><div className="storage-line"><span><i className={`dot ${saving?'busy':''}`} />{saving?'Saving…':'Local-first'}</span><span className="mono">v{data.meta.appVersion}</span></div><Button size="sm" variant="soft" onClick={()=>setPalette(true)}><Command size={14}/> Command Palette</Button></div>
    </aside>
    <main className="main">
      <header className="topbar"><div className="topbar-inner"><button className="mobile-menu" onClick={()=>setMobileOpen(x=>!x)} aria-label="Open menu">{mobileOpen?<X size={18}/>:<Menu size={18}/>}</button><div className="global-search"><Search size={16}/><input id="global-search" value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search skills, IDs, categories, projects…" aria-label="Global search"/><span className="kbd">/</span></div><div className="top-actions"><button className="icon-button" title="Toggle theme" onClick={()=>setPreferences({theme:data.preferences.theme==='dark'?'light':'dark'})}>{data.preferences.theme==='dark'?<Sun size={17}/>:<Moon size={17}/>}</button><button className="icon-button" title="Command palette" onClick={()=>setPalette(true)}><Command size={17}/></button></div></div></header>
      {mobileOpen&&<div style={{position:'fixed',inset:0,zIndex:30}} onClick={()=>setMobileOpen(false)}><div className="card" style={{position:'absolute',top:62,right:12,left:12}} onClick={e=>e.stopPropagation()}><nav className="nav">{items.map(x=><NavLink key={x.to} to={x.to} onClick={()=>setMobileOpen(false)} end={x.to==='/' }><x.icon size={16}/>{x.label}</NavLink>)}</nav></div></div>}
      {error&&<div className="content" style={{paddingBottom:0}}><div className="alert danger-alert"><strong>Storage error.</strong> {error}</div></div>}
      <Outlet />
      <div className="mobile-nav">{items.slice(0,5).map(x=><NavLink key={x.to} to={x.to} end={x.to==='/' }><x.icon size={16}/><span>{x.label.replace('Command Center','Home')}</span></NavLink>)}</div>
    </main>
    {palette&&<CommandPalette onClose={()=>setPalette(false)}/>} 
  </div>
}
