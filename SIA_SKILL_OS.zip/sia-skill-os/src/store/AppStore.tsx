import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import { createInitialData, defaultSkillProgress, nowISO, type AppData, type ActiveTimer, type CareerProfile, type Evidence, type Goal, type PersonalSkill, type PortfolioItem, type Preferences, type Project, type Review, type Session, type SkillId, type PlanItem, type SkillRelation } from '../domain/types'
import { clearAppData, loadAppData, saveAppData } from '../lib/db'
import { uid } from '../lib/id'

interface StoreContextValue {
  data: AppData
  hydrated: boolean
  saving: boolean
  error: string | null
  patch: (fn: (draft: AppData) => AppData) => void
  setPreferences: (patch: Partial<Preferences>) => void
  getProgress: (skillId: SkillId) => ReturnType<typeof defaultSkillProgress>
  updateProgress: (skillId: SkillId, patch: Partial<ReturnType<typeof defaultSkillProgress>>) => void
  addSession: (session: Omit<Session, 'id'|'createdAt'>) => void
  addPlanItem: (item: Omit<PlanItem,'id'|'createdAt'>) => string
  updatePlanItem: (id: string, patch: Partial<PlanItem>) => void
  deletePlanItem: (id: string) => void
  addRelation: (relation: Omit<SkillRelation,'id'|'createdAt'>) => string
  deleteRelation: (id: string) => void
  updateSession: (id: string, patch: Partial<Session>) => void
  deleteSession: (id: string) => void
  addProject: (project: Omit<Project,'id'|'createdAt'|'updatedAt'>) => string
  updateProject: (id: string, patch: Partial<Project>) => void
  addEvidence: (evidence: Omit<Evidence,'id'|'createdAt'>) => string
  deleteEvidence: (id: string) => void
  addPortfolio: (item: Omit<PortfolioItem,'id'|'createdAt'>) => string
  addCareer: (profile: CareerProfile) => void
  addGoal: (goal: Omit<Goal,'id'|'createdAt'|'updatedAt'>) => string
  updateGoal: (id: string, patch: Partial<Goal>) => void
  saveReview: (review: Omit<Review,'id'|'updatedAt'> & { id?: string }) => void
  addPersonalSkill: (skill: Omit<PersonalSkill,'id'|'createdAt'>) => string
  deletePersonalSkill: (id: string) => void
  startTimer: (timer: Omit<ActiveTimer,'startedAt'|'accumulatedMinutes'>) => void
  pauseTimer: () => void
  resumeTimer: () => void
  stopTimer: (note?: string) => Session | null
  resetAll: () => Promise<void>
}

const StoreContext = createContext<StoreContextValue | null>(null)

function applySessionDelta(progress: ReturnType<typeof defaultSkillProgress>, durationMinutes: number, sessionType: Session['sessionType'], direction: 1 | -1) {
  const hours = Math.max(0, Number(durationMinutes) || 0) / 60 * direction
  return {
    ...progress,
    completedHours: Math.max(0, progress.completedHours + hours),
    maintenanceHours: Math.max(0, progress.maintenanceHours + (sessionType === 'Maintenance' ? hours : 0)),
    updatedAt: nowISO(),
  }
}

function migrate(data: AppData): AppData {
  const base = createInitialData(data?.meta?.appVersion || '1.0.0')
  const raw = data as Partial<AppData>
  const next: AppData = {
    ...base,
    ...raw,
    meta: { ...base.meta, ...(raw.meta || {}), schemaVersion: 1 },
    preferences: {
      ...base.preferences,
      ...(raw.preferences || {}),
      masteryWeights: { ...base.preferences.masteryWeights, ...(raw.preferences?.masteryWeights || {}) },
      dashboardWidgets: Array.isArray(raw.preferences?.dashboardWidgets) ? raw.preferences!.dashboardWidgets : base.preferences.dashboardWidgets,
      lifeStages: Array.isArray(raw.preferences?.lifeStages) ? raw.preferences!.lifeStages : base.preferences.lifeStages,
    },
    progress: raw.progress && typeof raw.progress === 'object' ? raw.progress : {},
    personalSkills: Array.isArray(raw.personalSkills) ? raw.personalSkills : [],
    sessions: Array.isArray(raw.sessions) ? raw.sessions : [],
    planItems: Array.isArray(raw.planItems) ? raw.planItems : [],
    relations: Array.isArray(raw.relations) ? raw.relations : [],
    projects: Array.isArray(raw.projects) ? raw.projects : [],
    evidence: Array.isArray(raw.evidence) ? raw.evidence : [],
    portfolio: Array.isArray(raw.portfolio) ? raw.portfolio : [],
    career: raw.career && typeof raw.career === 'object' ? raw.career : {},
    goals: Array.isArray(raw.goals) ? raw.goals : [],
    reviews: Array.isArray(raw.reviews) ? raw.reviews : [],
    activeTimer: raw.activeTimer ?? null,
  }

  // Logged hours are a derived ledger from Sessions, not a manually editable counter.
  const logged: Record<string, { completedHours: number; maintenanceHours: number; lastPractice?: string }> = {}
  for (const session of next.sessions) {
    const key = String(session.skillId)
    const bucket = logged[key] || { completedHours: 0, maintenanceHours: 0 }
    const hours = Math.max(0, Number(session.durationMinutes) || 0) / 60
    bucket.completedHours += hours
    if (session.sessionType === 'Maintenance') bucket.maintenanceHours += hours
    if (session.date <= new Date().toISOString().slice(0,10) && (!bucket.lastPractice || session.date > bucket.lastPractice)) bucket.lastPractice = session.date
    logged[key] = bucket
  }
  const progress = { ...next.progress }
  for (const [key, existing] of Object.entries(progress)) {
    const bucket = logged[key]
    progress[key] = { ...defaultSkillProgress(), ...existing, completedHours: bucket?.completedHours ?? 0, maintenanceHours: bucket?.maintenanceHours ?? 0, lastPractice: bucket?.lastPractice ?? existing.lastPractice, updatedAt: existing.updatedAt || nowISO() }
  }
  for (const [key, bucket] of Object.entries(logged)) {
    if (!progress[key]) progress[key] = { ...defaultSkillProgress(), ...bucket, updatedAt: nowISO() }
  }
  return { ...next, progress }
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<AppData>(() => createInitialData())
  const [hydrated, setHydrated] = useState(false)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let mounted = true
    loadAppData().then(found => {
      if (!mounted) return
      setData(found ? migrate(found) : createInitialData())
      setHydrated(true)
    }).catch(err => {
      if (!mounted) return
      setError(err instanceof Error ? err.message : 'Storage could not be opened.')
      setHydrated(true)
    })
    return () => { mounted = false }
  }, [])

  useEffect(() => {
    if (!hydrated) return
    let cancelled = false
    setSaving(true)
    const t = window.setTimeout(() => {
      saveAppData({ ...data, meta: { ...data.meta, updatedAt: nowISO() } })
        .catch(err => { if (!cancelled) setError(err instanceof Error ? err.message : 'Could not save data.') })
        .finally(() => { if (!cancelled) setSaving(false) })
    }, 140)
    return () => { cancelled = true; window.clearTimeout(t) }
  }, [data, hydrated])

  const patch = useCallback((fn: (draft: AppData) => AppData) => setData(prev => fn(structuredClone(prev))), [])

  const setPreferences = useCallback((p: Partial<Preferences>) => setData(prev => ({ ...prev, preferences: { ...prev.preferences, ...p } })), [])
  const getProgress = useCallback((skillId: SkillId) => data.progress[String(skillId)] ? { ...defaultSkillProgress(), ...data.progress[String(skillId)] } : defaultSkillProgress(), [data.progress])
  const updateProgress = useCallback((skillId: SkillId, p: Partial<ReturnType<typeof defaultSkillProgress>>) => {
    setData(prev => ({ ...prev, progress: { ...prev.progress, [String(skillId)]: { ...defaultSkillProgress(), ...(prev.progress[String(skillId)] || {}), ...p, updatedAt: nowISO() } } }))
  }, [])

  const addSession = useCallback((session: Omit<Session,'id'|'createdAt'>) => setData(prev => {
    const created: Session = { ...session, id: uid('ses'), createdAt: nowISO(), durationMinutes: Math.max(0, Number(session.durationMinutes) || 0) }
    const key = String(created.skillId)
    const old = prev.progress[key] || defaultSkillProgress()
    const canTouchMaintenance = created.date <= new Date().toISOString().slice(0,10)
    const d = old.maintenanceIntervalDays && canTouchMaintenance ? new Date(created.date) : null
    if (d && old.maintenanceIntervalDays) d.setDate(d.getDate() + old.maintenanceIntervalDays)
    const next = { ...applySessionDelta(old, created.durationMinutes, created.sessionType, 1), lastPractice: canTouchMaintenance && (!old.lastPractice || created.date >= old.lastPractice) ? created.date : old.lastPractice, nextReview: d ? d.toISOString().slice(0,10) : old.nextReview }
    return { ...prev, sessions: [...prev.sessions, created], progress: { ...prev.progress, [key]: next } }
  }), [])
  const addPlanItem = useCallback((item: Omit<PlanItem,'id'|'createdAt'>) => { const id=uid('plan'); setData(prev => ({ ...prev, planItems: [...prev.planItems, { ...item, id, createdAt: nowISO() }] })); return id }, [])
  const updatePlanItem = useCallback((id: string, p: Partial<PlanItem>) => setData(prev => ({ ...prev, planItems: prev.planItems.map(x=>x.id===id?{...x,...p}:x) })), [])
  const deletePlanItem = useCallback((id: string) => setData(prev => ({ ...prev, planItems: prev.planItems.filter(x=>x.id!==id) })), [])
  const addRelation = useCallback((relation: Omit<SkillRelation,'id'|'createdAt'>) => { const id=uid('rel'); setData(prev => ({ ...prev, relations: [...prev.relations, { ...relation, id, createdAt: nowISO() }] })); return id }, [])
  const deleteRelation = useCallback((id: string) => setData(prev => ({ ...prev, relations: prev.relations.filter(x=>x.id!==id) })), [])

  const updateSession = useCallback((id: string, p: Partial<Session>) => setData(prev => {
    const current = prev.sessions.find(s => s.id === id); if (!current) return prev
    const next: Session = { ...current, ...p, durationMinutes: Math.max(0, Number((p.durationMinutes ?? current.durationMinutes)) || 0) }
    const progress = { ...prev.progress }
    const oldKey = String(current.skillId); const newKey = String(next.skillId)
    const oldProgress = progress[oldKey] || defaultSkillProgress()
    progress[oldKey] = applySessionDelta(oldProgress, current.durationMinutes, current.sessionType, -1)
    const newProgress = progress[newKey] || defaultSkillProgress()
    progress[newKey] = applySessionDelta(newProgress, next.durationMinutes, next.sessionType, 1)
    return { ...prev, sessions: prev.sessions.map(s => s.id === id ? next : s), progress }
  }), [])
  const deleteSession = useCallback((id: string) => setData(prev => {
    const current = prev.sessions.find(s => s.id === id); if (!current) return prev
    const key = String(current.skillId); const old = prev.progress[key] || defaultSkillProgress()
    return { ...prev, sessions: prev.sessions.filter(s => s.id !== id), progress: { ...prev.progress, [key]: applySessionDelta(old, current.durationMinutes, current.sessionType, -1) } }
  }), [])

  const addProject = useCallback((project: Omit<Project,'id'|'createdAt'|'updatedAt'>) => { const id=uid('prj'); const now=nowISO(); setData(prev => ({ ...prev, projects: [...prev.projects, { ...project, id, createdAt: now, updatedAt: now }] })); return id }, [])
  const updateProject = useCallback((id: string, p: Partial<Project>) => setData(prev => ({ ...prev, projects: prev.projects.map(x => x.id === id ? { ...x, ...p, updatedAt: nowISO() } : x) })), [])
  const addEvidence = useCallback((evidence: Omit<Evidence,'id'|'createdAt'>) => { const id=uid('ev'); setData(prev => ({ ...prev, evidence: [...prev.evidence, { ...evidence, id, createdAt: nowISO() }], projects: evidence.projectId ? prev.projects.map(p => p.id === evidence.projectId ? { ...p, evidenceIds: Array.from(new Set([...p.evidenceIds, id])), updatedAt: nowISO() } : p) : prev.projects })); return id }, [])
  const deleteEvidence = useCallback((id: string) => setData(prev => ({ ...prev, evidence: prev.evidence.filter(e => e.id !== id), projects: prev.projects.map(p => p.evidenceIds.includes(id) ? { ...p, evidenceIds: p.evidenceIds.filter(eid => eid !== id), updatedAt: nowISO() } : p) })), [])
  const addPortfolio = useCallback((item: Omit<PortfolioItem,'id'|'createdAt'>) => { const id=uid('port'); setData(prev => ({ ...prev, portfolio: [...prev.portfolio, { ...item, id, createdAt: nowISO() }] })); return id }, [])
  const addCareer = useCallback((profile: CareerProfile) => setData(prev => ({ ...prev, career: { ...prev.career, [String(profile.skillId)]: profile } })), [])
  const addGoal = useCallback((goal: Omit<Goal,'id'|'createdAt'|'updatedAt'>) => { const id=uid('goal'); const now=nowISO(); setData(prev => ({ ...prev, goals: [...prev.goals, { ...goal, id, createdAt: now, updatedAt: now }] })); return id }, [])
  const updateGoal = useCallback((id: string, p: Partial<Goal>) => setData(prev => ({ ...prev, goals: prev.goals.map(x => x.id === id ? { ...x, ...p, updatedAt: nowISO() } : x) })), [])
  const saveReview = useCallback((review: Omit<Review,'id'|'updatedAt'> & { id?: string }) => setData(prev => {
    const now=nowISO(); const id=review.id || uid('review'); const next={...review, id, updatedAt: now}; const existing=prev.reviews.find(r=>r.id===id)
    return { ...prev, reviews: existing ? prev.reviews.map(r=>r.id===id?next:r) : [...prev.reviews,next] }
  }), [])
  const addPersonalSkill = useCallback((skill: Omit<PersonalSkill,'id'|'createdAt'>) => { const id=uid('ps'); setData(prev => ({ ...prev, personalSkills: [...prev.personalSkills, { ...skill, id, createdAt: nowISO() }] })); return id }, [])
  const deletePersonalSkill = useCallback((id:string) => setData(prev => ({ ...prev, personalSkills: prev.personalSkills.map(s=>s.id===id?{...s,archived:true}:s) })), [])

  const startTimer = useCallback((timer: Omit<ActiveTimer,'startedAt'|'accumulatedMinutes'>) => setData(prev => ({ ...prev, activeTimer: { ...timer, startedAt: nowISO(), accumulatedMinutes: 0 } })), [])
  const pauseTimer = useCallback(() => setData(prev => {
    if (!prev.activeTimer || prev.activeTimer.pausedAt) return prev
    const elapsed = Math.max(0, (Date.now() - new Date(prev.activeTimer.startedAt).getTime()) / 60000)
    return { ...prev, activeTimer: { ...prev.activeTimer, accumulatedMinutes: prev.activeTimer.accumulatedMinutes + elapsed, pausedAt: nowISO() } }
  }), [])
  const resumeTimer = useCallback(() => setData(prev => prev.activeTimer ? { ...prev, activeTimer: { ...prev.activeTimer, startedAt: nowISO(), pausedAt: undefined } } : prev), [])
  const stopTimer = useCallback((note?: string) => {
    let created: Session | null = null
    setData(prev => {
      const timer = prev.activeTimer; if (!timer) return prev
      const elapsed = timer.pausedAt ? 0 : Math.max(0, (Date.now() - new Date(timer.startedAt).getTime()) / 60000)
      const durationMinutes = Math.round(timer.accumulatedMinutes + elapsed); if (durationMinutes <= 0) return { ...prev, activeTimer: null }
      const now=nowISO(); const key=String(timer.skillId); const old=prev.progress[key]||defaultSkillProgress()
      created = { id: uid('ses'), skillId: timer.skillId, projectId: timer.projectId, date: new Date().toISOString().slice(0,10), startedAt: timer.startedAt, endedAt: now, durationMinutes, sessionType: timer.sessionType, note: note || undefined, source: 'timer', createdAt: now }
      const date=created.date; const canTouchMaintenance=date<=new Date().toISOString().slice(0,10); const updatedLast=canTouchMaintenance && (!old.lastPractice || date>=old.lastPractice) ? date : old.lastPractice
      let nextReview=old.nextReview; if(canTouchMaintenance && old.maintenanceIntervalDays){ const d=new Date(date); d.setDate(d.getDate()+old.maintenanceIntervalDays); nextReview=d.toISOString().slice(0,10) }
      return { ...prev, activeTimer: null, sessions: [...prev.sessions, created], progress: { ...prev.progress, [key]: { ...applySessionDelta(old, durationMinutes, timer.sessionType, 1), lastPractice:updatedLast, nextReview } } }
    })
    return created
  }, [])


  const resetAll = useCallback(async () => { await clearAppData(); setData(createInitialData()); }, [])

  const value = useMemo(() => ({ data, hydrated, saving, error, patch, setPreferences, getProgress, updateProgress, addSession, addPlanItem, updatePlanItem, deletePlanItem, addRelation, deleteRelation, updateSession, deleteSession, addProject, updateProject, addEvidence, deleteEvidence, addPortfolio, addCareer, addGoal, updateGoal, saveReview, addPersonalSkill, deletePersonalSkill, startTimer, pauseTimer, resumeTimer, stopTimer, resetAll }), [data, hydrated, saving, error, patch, setPreferences, getProgress, updateProgress, addSession, addPlanItem, updatePlanItem, deletePlanItem, addRelation, deleteRelation, updateSession, deleteSession, addProject, updateProject, addEvidence, deleteEvidence, addPortfolio, addCareer, addGoal, updateGoal, saveReview, addPersonalSkill, deletePersonalSkill, startTimer, pauseTimer, resumeTimer, stopTimer, resetAll])
  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>
}

export function useApp() {
  const ctx = useContext(StoreContext)
  if (!ctx) throw new Error('useApp must be used inside AppProvider')
  return ctx
}
