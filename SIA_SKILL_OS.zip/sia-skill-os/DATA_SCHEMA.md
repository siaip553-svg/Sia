# SIA SKILL OS — Data Schema v1

SIA SKILL OS separates immutable Master Data from mutable user data.

## MasterSkillRecord

The Master snapshot is compiled from `eeje.txt` and carries provenance such as source file/line/raw text. It preserves bundled/range definitions instead of silently expanding them.

Core source fields include:

```ts
interface MasterSkillRecord {
  id: string | null
  rawId: string
  name: string
  category: string
  subcategory?: string
  description?: string
  ability?: string
  initialHoursRaw?: string
  realisticHoursRaw?: string
  realisticHours?: number | null
  sourceStatus?: string
  sourceLines: [number, number]
  sourceRaw: string
}
```

No Master record is created for a missing source ID such as `218`.

## AppData

```ts
interface AppData {
  meta: { schemaVersion: 1; appVersion: string; createdAt: string; updatedAt: string }
  preferences: Preferences
  progress: Record<string, SkillProgress>
  personalSkills: PersonalSkill[]
  sessions: Session[]
  planItems: PlanItem[]
  relations: SkillRelation[]
  projects: Project[]
  evidence: Evidence[]
  portfolio: PortfolioItem[]
  career: Record<string, CareerProfile>
  goals: Goal[]
  reviews: Review[]
  activeTimer: ActiveTimer | null
}
```

## Separation of concerns

`progress`, `sessions`, `planItems`, `projects`, `evidence`, `portfolio`, `career`, `goals`, `reviews`, timer state and preferences are user-owned. They are never copied into the immutable Master snapshot.

A user-created Personal Skill lives in `personalSkills`; it does not modify the Master Checklist.

## Progress model

Time Progress and Skill Mastery are deliberately independent.

Time Progress:

```text
TimeProgress = clamp(LoggedHours / NumericRealisticHours, 0, 1)
RemainingHours = max(NumericRealisticHours - LoggedHours, 0)
```

When the source target is a range, approximate value, open-ended value, or undefined value, the raw source is preserved and numeric Time Progress is not fabricated.

Skill Mastery combines configurable, separately recorded components:
- Practice
- Projects / assessed project evidence
- Tests
- Self assessment
- Performance
- Consistency

Weights are normalized at calculation time, so changing weights does not mutate historical session data.

## Derived values

Logged Hours are derived/reconciled from real Session records. Planned Hours come from Plan Items and are not treated as actual learning time.

Remaining Hours, Time Progress, Maintenance Due, streaks, achievements, category distributions and focus recommendations are derived from actual stored data.

## Relationships

`SkillRelation` supports dependency and synergy edges without rewriting Master definitions. Relations reference stable string skill IDs so numeric and personal IDs can coexist.

Projects can reference skills. Evidence can reference projects and skills. Portfolio items can reference evidence/projects. Career profiles are keyed by skill ID.

## Versioning and migrations

`schemaVersion` is `1`. Future schema changes must add an explicit migration in the store layer instead of silently coercing unknown data.
